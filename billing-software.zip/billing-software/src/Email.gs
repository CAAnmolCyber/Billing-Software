/**
 * Yavira Billing System - Email.gs
 * Stage 8: emails each customer their bill(s) as PDF attachments.
 *
 * How it works
 *  - Issuing a bill never waits for Gmail. A bill with a customer email is saved with Email status "Queued".
 *  - runBackgroundJobs() runs every 5 minutes as the app owner: first it files PDFs in Drive (Stage 7),
 *    then processEmailQueue() sends one email per visit, with every PDF from that visit attached.
 *  - An email is only sent once all PDFs of the visit are in Drive, so the customer always gets the full set.
 *  - TEST_MODE = TRUE: every email goes to TEST_EMAIL_REDIRECT instead of the customer. No exceptions.
 *  - TEST_MODE = FALSE and CUSTOMER_EMAIL_ENABLED = FALSE: nothing is sent; bills stay "Queued".
 *  - A failed send stays "Queued", is logged, and is retried on the next run, up to EMAIL_MAX_ATTEMPTS times.
 *  - Email status values: Queued, Sent, Redirected (test), Failed, Not applicable (matches the sheet's dropdown).
 *  - Cancelled documents are never emailed. Medical details (service names) are never put in the email text.
 *
 * Changing the sending Gmail later (no code change needed):
 *  - Sender name / reply-to: edit EMAIL_SENDER_NAME and EMAIL_REPLY_TO in Application Settings.
 *  - Send "as" another address: add it in the owner's Gmail (Settings > Accounts > Send mail as),
 *    then put it in EMAIL_FROM_ALIAS.
 *  - Send from a different Google account entirely: that account runs installBackgroundJobs() once
 *    from the script editor (Stage 13 migration covers this).
 */

function isTrue_(v) { return v === true || String(v).trim().toUpperCase() === 'TRUE'; }

/** Who receives the email, decided only from settings. Pure function: easy to test. */
function decideDelivery_(s, customerEmail) {
  if (isTrue_(s.TEST_MODE)) {
    var redirect = String(s.TEST_EMAIL_REDIRECT || '').trim();
    if (!redirect) return {hold: true, reason: 'TEST_MODE is on but TEST_EMAIL_REDIRECT is empty'};
    return {to: redirect, redirected: true};
  }
  if (!isTrue_(s.CUSTOMER_EMAIL_ENABLED)) return {hold: true, reason: 'Customer emails are switched off (CUSTOMER_EMAIL_ENABLED = FALSE)'};
  if (!customerEmail) return {hold: true, reason: 'No customer email'};
  return {to: customerEmail, redirected: false};
}

function emailSettings_() {
  var s = getSettings_();
  return {
    raw: s,
    senderName: String(optionalSetting_('EMAIL_SENDER_NAME', '') || getBusinessProfile_()['Trade name'] || 'Yavira Billing'),
    fromAlias: String(optionalSetting_('EMAIL_FROM_ALIAS', '') || '').trim(),
    replyTo: String(optionalSetting_('EMAIL_REPLY_TO', '') || '').trim(),
    maxAttempts: Number(optionalSetting_('EMAIL_MAX_ATTEMPTS', 3)) || 3,
    maxAgeDays: Number(optionalSetting_('EMAIL_MAX_AGE_DAYS', 7)) || 7
  };
}

/** Builds subject, plain text and HTML for one visit. Amounts and numbers only - no treatment details. */
function buildEmail_(docs, business, delivery, customerEmail) {
  var name = docs[0]['Customer name'];
  var trade = business['Trade name'];
  var nums = docs.map(function (d) { return d['Document no.']; });
  var subject = (docs.length === 1 ? docs[0]['Document type'] + ' ' + nums[0] : 'Your bills ' + nums.join(', ')) + ' - ' + trade;
  if (delivery.redirected) subject = '[TEST] ' + subject;
  var total = docs.reduce(function (a, d) { return a + Number(d['Total payable']); }, 0);
  var dateStr = Utilities.formatDate(new Date(docs[0]['Document date']), TZ, 'dd MMM yyyy');
  var rows = docs.map(function (d) {
    return '<tr><td style="padding:6px 10px;border-bottom:1px solid #eee;">' + esc_(d['Document type']) + '</td>' +
      '<td style="padding:6px 10px;border-bottom:1px solid #eee;">' + esc_(d['Document no.']) + '</td>' +
      '<td style="padding:6px 10px;border-bottom:1px solid #eee;text-align:right;">&#8377; ' + money_(d['Total payable']) + '</td></tr>';
  }).join('');
  var testBanner = delivery.redirected ?
    '<div style="background:#fff3cd;border:1px solid #e0c36a;padding:8px 12px;margin-bottom:14px;font-size:13px;">' +
    'TEST MODE - this email was redirected. Intended recipient: <b>' + esc_(customerEmail) + '</b></div>' : '';
  var html = '<div style="font-family:Arial,sans-serif;font-size:14px;color:#2b2b2b;max-width:560px;">' + testBanner +
    '<p>Dear ' + esc_(name) + ',</p>' +
    '<p>Thank you for visiting ' + esc_(trade) + '. Your bill' + (docs.length > 1 ? 's' : '') + ' dated ' + dateStr +
    (docs.length > 1 ? ' are' : ' is') + ' attached as PDF.</p>' +
    '<table style="border-collapse:collapse;width:100%;margin:10px 0;">' + rows +
    '<tr><td colspan="2" style="padding:6px 10px;"><b>Total paid</b></td><td style="padding:6px 10px;text-align:right;"><b>&#8377; ' +
    money_(total) + '</b></td></tr></table>' +
    '<p>For any questions, please call us on ' + esc_(business['Phone']) + '.</p>' +
    '<p>Warm regards,<br>' + esc_(trade) + '<br><span style="color:#777;font-size:12px;">' + esc_(business['Address line 1']) + ', ' +
    esc_(business['Address line 2']) + ', Punjab - ' + esc_(business['PIN code']) + '</span></p>' +
    '<p style="color:#999;font-size:11px;">This is a computer-generated email. Please keep the attached bill for your records.</p></div>';
  var text = (delivery.redirected ? 'TEST MODE - intended recipient: ' + customerEmail + '\n\n' : '') +
    'Dear ' + name + ',\n\nThank you for visiting ' + trade + '. Your bill(s) dated ' + dateStr + ' are attached:\n' +
    docs.map(function (d) { return '- ' + d['Document type'] + ' ' + d['Document no.'] + ': Rs ' + money_(d['Total payable']); }).join('\n') +
    '\nTotal paid: Rs ' + money_(total) + '\n\nFor any questions, call ' + business['Phone'] + '.\n\n' + trade;
  return {subject: subject, html: html, text: text};
}

/** Counts earlier attempts for this email from the Email Delivery Log. */
function priorAttempts_(ref) {
  return readRecords_(SHEETS.EMAIL_LOG).filter(function (r) { return r['Document no. / report'] === ref; }).length;
}

/**
 * Background job: sends every queued bill email.
 * opts.forceError: test only - simulates a Gmail failure without sending anything.
 */
function processEmailQueue(opts) {
  opts = opts || {};
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(5000)) return {skipped: 'another run in progress'};
  var result = {sent: [], failed: [], held: [], waitingForPdf: [], tooOld: [], quota: null};
  try {
    refreshSettings();
    var es = emailSettings_(), business = getBusinessProfile_();
    var sh = getDb_().getSheetByName(SHEETS.INVOICE_REGISTER);
    var last = sh.getLastRow();
    if (last < 2) return result;
    var map = getHeaderMap_(SHEETS.INVOICE_REGISTER);
    var headers = Object.keys(map);
    var values = sh.getRange(2, 1, last - 1, sh.getLastColumn()).getValues();

    var groups = {}, order = [];
    values.forEach(function (r, i) {
      var status = String(r[map['Email status'] - 1]);
      if (status !== 'Queued') return;
      if (String(r[map['Document status'] - 1]) !== 'Issued' || !r[map['Email'] - 1]) return;
      var rec = {_row: i + 2};
      headers.forEach(function (h) { rec[h] = r[map[h] - 1]; });
      var key = rec['Visit ID'] || rec['Document no.'];
      if (!groups[key]) { groups[key] = []; order.push(key); }
      groups[key].push(rec);
    });

    var setStatus = function (docs, status) {
      docs.forEach(function (d) { sh.getRange(d._row, map['Email status']).setValue(status); });
    };

    result.quota = MailApp.getRemainingDailyQuota();
    order.forEach(function (key) {
      var docs = groups[key], ref = docs.map(function (d) { return d['Document no.']; }).join(', ');
      var customerEmail = String(docs[0]['Email']).trim();
      if (docs.some(function (d) { return !d['PDF file ID']; })) { result.waitingForPdf.push(ref); return; }
      var delivery = decideDelivery_(es.raw, customerEmail);
      if (delivery.hold) { result.held.push(ref + ' (' + delivery.reason + ')'); return; }
      var ageDays = (new Date() - new Date(docs[0]['Document date'])) / 86400000;
      if (!delivery.redirected && ageDays > es.maxAgeDays) {
        setStatus(docs, 'Not applicable');
        result.tooOld.push(ref);
        audit_('EMAIL_SKIPPED', 'Email', ref, 'Bill older than EMAIL_MAX_AGE_DAYS when customer emails were switched on', 'OK');
        return;
      }
      if (result.quota < 1) { result.held.push(ref + ' (daily Gmail limit reached; will send tomorrow)'); return; }

      var attempt = priorAttempts_(ref) + 1, now = new Date(), err = '';
      try {
        if (opts.forceError) throw new Error('Simulated Gmail failure (test) - nothing was sent');
        var msg = buildEmail_(docs, business, delivery, customerEmail);
        var files = docs.map(function (d) { return DriveApp.getFileById(String(d['PDF file ID'])).getBlob(); });
        var options = {htmlBody: msg.html, attachments: files, name: es.senderName};
        if (es.replyTo) options.replyTo = es.replyTo;
        if (es.fromAlias) options.from = es.fromAlias;
        GmailApp.sendEmail(delivery.to, msg.subject, msg.text, options);
        result.quota--;
        setStatus(docs, delivery.redirected ? 'Redirected (test)' : 'Sent');
        result.sent.push(ref + ' -> ' + delivery.to);
      } catch (e) {
        err = e.message;
        if (attempt >= es.maxAttempts) setStatus(docs, 'Failed');   // otherwise stays Queued and is retried next run
        result.failed.push(ref + ': ' + err);
      }
      appendRecord_(SHEETS.EMAIL_LOG, {
        'Email ID': 'EML-' + Utilities.formatDate(now, TZ, 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
        'Queued at': docs[0]['Created at'], 'Email type': 'Customer bill', 'Document no. / report': ref,
        'Recipient': delivery.to, 'Redirected (test mode)': delivery.redirected ? 'Yes' : 'No',
        'Status': err ? 'Failed' : 'Sent', 'Attempts': attempt, 'Last attempt at': now, 'Last error': err,
        'Notes': delivery.redirected ? 'Intended for ' + customerEmail : ''
      });
      audit_('EMAIL_SENT', 'Email', ref, err ? 'Attempt ' + attempt + ' failed: ' + err : 'Sent to ' + delivery.to, err ? 'FAIL' : 'OK');
    });
    SpreadsheetApp.flush();
    return result;
  } finally {
    lock.releaseLock();
  }
}

/** The 5-minute job: PDFs first, then emails. A failure in one never stops the other. */
function runBackgroundJobs() {
  var pause = Number(PropertiesService.getScriptProperties().getProperty('PAUSE_BACKGROUND_UNTIL') || 0);
  if (pause > Date.now()) return;      // paused for maintenance or a test run (pauses expire on their own)
  var errors = [];
  try { processPdfQueue(); } catch (e) { errors.push('processPdfQueue: ' + e.message); audit_('BACKGROUND_JOB', 'System', 'processPdfQueue', e.message, 'FAIL'); }
  try { processEmailQueue(); } catch (e) { errors.push('processEmailQueue: ' + e.message); audit_('BACKGROUND_JOB', 'System', 'processEmailQueue', e.message, 'FAIL'); }
  try { checkAfterBackgroundRun_(errors); } catch (e) { console.error('Alert check failed: ' + e.message); }   // Alerts.gs
}

/** Installs the single 5-minute background job (replaces the Stage 7 PDF-only trigger). Run once as the owner. */
function installBackgroundJobs() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    var h = t.getHandlerFunction();
    if (h === 'processPdfQueue' || h === 'runBackgroundJobs') ScriptApp.deleteTrigger(t);
  });
  ScriptApp.newTrigger('runBackgroundJobs').timeBased().everyMinutes(5).create();
  var who = Session.getEffectiveUser().getEmail();
  audit_('TRIGGER_INSTALLED', 'System', 'runBackgroundJobs', 'Every 5 minutes (PDFs, then emails), runs as ' + who, 'OK');
  Logger.log('Background jobs installed: every 5 minutes, PDFs then emails. Emails will be sent from ' + who);
}

/** Shows which account and settings the emails will use (for checking after any change). */
function emailSetupStatus() {
  refreshSettings();
  var es = emailSettings_(), s = es.raw;
  var out = [
    'Emails are sent from: ' + (es.fromAlias || Session.getEffectiveUser().getEmail()) + (es.fromAlias ? ' (alias)' : ''),
    'Sender name: ' + es.senderName,
    'Reply-to: ' + (es.replyTo || '(same as sender)'),
    'TEST_MODE: ' + s.TEST_MODE + (isTrue_(s.TEST_MODE) ? ' -> all emails go to ' + s.TEST_EMAIL_REDIRECT : ''),
    'CUSTOMER_EMAIL_ENABLED: ' + s.CUSTOMER_EMAIL_ENABLED,
    'Gmail sends left today: ' + MailApp.getRemainingDailyQuota()
  ];
  if (es.fromAlias) {
    var ok = GmailApp.getAliases().indexOf(es.fromAlias) !== -1;
    out.push((ok ? 'OK   ' : 'PROBLEM ') + 'alias ' + es.fromAlias + (ok ? ' is verified in Gmail' : ' is NOT set up in Gmail "Send mail as"'));
  }
  Logger.log(out.join('\n'));
  return out;
}

/**
 * Stage 8 test (TEST environment only). Sends email ONLY to TEST_EMAIL_REDIRECT.
 *  1. Recipient rules for every combination of TEST_MODE / CUSTOMER_EMAIL_ENABLED.
 *  2. Gmail failure: nothing sent, bills stay queued for retry, failure logged.
 *  3. Normal run: one email per visit, all redirected to the test inbox, with the PDFs attached.
 *  4. Second run sends nothing (no duplicates).
 */
function testEmailStage8() {
  if (getSetting('ENVIRONMENT') !== 'TEST') throw new Error('Tests run only in the TEST environment.');
  refreshSettings();
  var s = getSettings_(), redirect = String(s.TEST_EMAIL_REDIRECT), out = [];
  if (!isTrue_(s.TEST_MODE)) throw new Error('Stop: TEST_MODE must be TRUE to run this test.');

  var cases = [
    [{TEST_MODE: 'TRUE', TEST_EMAIL_REDIRECT: 'test@x.com', CUSTOMER_EMAIL_ENABLED: 'TRUE'}, 'test@x.com'],
    [{TEST_MODE: 'TRUE', TEST_EMAIL_REDIRECT: 'test@x.com', CUSTOMER_EMAIL_ENABLED: 'FALSE'}, 'test@x.com'],
    [{TEST_MODE: 'TRUE', TEST_EMAIL_REDIRECT: '', CUSTOMER_EMAIL_ENABLED: 'TRUE'}, 'HOLD'],
    [{TEST_MODE: 'FALSE', TEST_EMAIL_REDIRECT: 'test@x.com', CUSTOMER_EMAIL_ENABLED: 'FALSE'}, 'HOLD'],
    [{TEST_MODE: 'FALSE', TEST_EMAIL_REDIRECT: 'test@x.com', CUSTOMER_EMAIL_ENABLED: 'TRUE'}, 'cust@y.com']
  ];
  var rulesOk = cases.every(function (c) {
    var d = decideDelivery_(c[0], 'cust@y.com');
    return (d.hold ? 'HOLD' : d.to) === c[1];
  });
  out.push((rulesOk ? 'PASS ' : 'FAIL ') + 'Recipient rules (5 cases): test mode always redirects; customers only when TEST_MODE=FALSE and CUSTOMER_EMAIL_ENABLED=TRUE');

  var fail = processEmailQueue({forceError: true});
  var queued = fail.failed.length;
  var stillQueued = readRecords_(SHEETS.INVOICE_REGISTER).filter(function (r) { return r['Email status'] === 'Queued' && r['Email']; }).length;
  out.push((queued > 0 && fail.sent.length === 0 && stillQueued > 0 ? 'PASS ' : 'FAIL ') +
    'Gmail failure: sent 0, failed ' + queued + ' visit(s), ' + stillQueued + ' bill(s) kept for retry');

  var ok = processEmailQueue();
  var allRedirected = ok.sent.every(function (x) { return x.slice(-redirect.length) === redirect; });
  out.push((ok.sent.length === queued && ok.failed.length === 0 && allRedirected ? 'PASS ' : 'FAIL ') +
    'Normal run: sent ' + ok.sent.length + ' email(s), all to ' + redirect);
  ok.sent.forEach(function (x) { out.push('     ' + x); });

  var logs = readRecords_(SHEETS.EMAIL_LOG).filter(function (r) { return r['Status'] === 'Sent'; });
  var logOk = logs.length >= ok.sent.length && logs.every(function (r) { return r['Recipient'] === redirect && r['Redirected (test mode)'] === 'Yes'; });
  out.push((logOk ? 'PASS ' : 'FAIL ') + 'Email Delivery Log: every sent email shows the test inbox and "Redirected = Yes"');

  Utilities.sleep(3000);
  var threads = GmailApp.search('subject:"[TEST]" newer_than:1d');
  var withPdf = threads.filter(function (t) {
    return t.getMessages().some(function (m) { return m.getAttachments().some(function (a) { return a.getContentType() === 'application/pdf'; }); });
  }).length;
  out.push((withPdf >= ok.sent.length ? 'PASS ' : 'FAIL ') + 'Test inbox has ' + withPdf + ' [TEST] email(s) with PDF attachments');

  var again = processEmailQueue();
  out.push((again.sent.length === 0 ? 'PASS ' : 'FAIL ') + 'Second run sends nothing (sent ' + again.sent.length + ')');
  out.push('Gmail sends left today: ' + MailApp.getRemainingDailyQuota());
  Logger.log(out.join('\n'));
  return out;
}
