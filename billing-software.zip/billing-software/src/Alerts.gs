/**
 * Yavira Billing System - Alerts.gs
 * Stage 12B: failure alerts. When something keeps failing, an email goes to ALERT_EMAIL
 * (Application Settings; blank = the owner account that runs the app).
 *
 * What is watched
 *  - Every 5 minutes (end of runBackgroundJobs): a bill still without its PDF after 30 minutes; customer emails
 *    marked Failed; an error inside the PDF or email job; the daily report job not having run for 26 hours.
 *  - Immediately: a weekly/monthly report that could not be sent; a nightly backup or off-site backup that failed.
 *  - Every morning (~7 AM, inside runScheduledReports): health check of the last backup, the scheduled jobs,
 *    the 5-minute job's last run, the Gmail sending allowance and any failures in the Audit Log in the last 24 hours.
 *  - The same alert is not repeated within 6 hours (24 hours for the morning health check); every alert is logged.
 *  - Nothing is sent when all is well. Google also emails the owner its own "summary of failures" for scheduled jobs.
 */

var ALERT_REPEAT_HOURS_ = 6;

function alertRecipient_() {
  return String(optionalSetting_('ALERT_EMAIL', '') || '').trim() || Session.getEffectiveUser().getEmail();
}

/** Sends one alert unless the same key was sent within repeatHours. Never throws. Returns true if sent. */
function sendAlert_(key, subject, lines, repeatHours) {
  try {
    var props = PropertiesService.getScriptProperties(), pk = 'ALERT_' + String(key).replace(/[^A-Za-z0-9_]/g, '_').slice(0, 80);
    var last = Number(props.getProperty(pk) || 0), hours = repeatHours || ALERT_REPEAT_HOURS_;
    if (Date.now() - last < hours * 3600000) return false;
    if (MailApp.getRemainingDailyQuota() < 1) { console.error('Alert not sent, Gmail limit reached: ' + subject); return false; }
    var env = String(getSetting('ENVIRONMENT') || ''), to = alertRecipient_();
    var body = (lines || []).join('\n') + '\n\n' +
      'Checked at ' + Utilities.formatDate(new Date(), TZ, 'dd-MM-yyyy HH:mm') + ' IST (' + env + ').\n' +
      'What to do: see "Backups and recovery" in the Owner\'s Maintenance and Recovery Guide, or open the project at script.google.com > Executions.\n' +
      'This alert is not repeated for ' + hours + ' hours while the problem lasts.';
    GmailApp.sendEmail(to, '[Yavira Billing ' + (env === 'TEST' ? 'TEST' : 'ALERT') + '] ' + subject, body, {name: 'Yavira Billing alerts'});
    props.setProperty(pk, String(Date.now()));
    audit_('ALERT_SENT', 'System', key, subject + ' -> ' + to, 'OK');
    return true;
  } catch (e) {
    console.error('Alert failed: ' + e.message);
    try { audit_('ALERT_SENT', 'System', key, 'Could not send alert: ' + e.message, 'FAIL'); } catch (x) {}
    return false;
  }
}

/** Light checks after every 5-minute run. Problems found are returned (and alerted). */
function checkAfterBackgroundRun_(errors) {
  var problems = [], now = Date.now(), props = PropertiesService.getScriptProperties();
  props.setProperty('LAST_BACKGROUND_RUN', String(now));
  (errors || []).forEach(function (e) { problems.push(e); sendAlert_('JOB_' + e.split(':')[0], 'A background job failed', [e]); });

  var recs = readRecords_(SHEETS.INVOICE_REGISTER);
  var late = recs.filter(function (r) { return !r['PDF file ID'] && r['Created at'] && now - new Date(r['Created at']).getTime() > 30 * 60000; })
    .map(function (r) { return String(r['Document no.']); });
  if (late.length) {
    problems.push('PDF overdue: ' + late.join(', '));
    sendAlert_('PDF_OVERDUE', late.length + ' bill PDF(s) not filed after 30 minutes',
      ['These bills were issued but their PDF is not in Drive yet: ' + late.slice(0, 20).join(', ') + (late.length > 20 ? ' and more' : '') + '.',
       'The bills themselves are saved safely. Run pdfQueueStatus and look at Executions for the error.']);
  }
  var failed = recs.filter(function (r) { return r['Email status'] === 'Failed' && r['Created at'] && now - new Date(r['Created at']).getTime() < 7 * 86400000; })
    .map(function (r) { return String(r['Document no.']); });
  if (failed.length) {
    problems.push('Email failed: ' + failed.join(', '));
    sendAlert_('EMAIL_FAILED_' + failed.join('_').slice(-60), failed.length + ' customer bill email(s) failed',
      ['These bill emails failed after ' + (Number(optionalSetting_('EMAIL_MAX_ATTEMPTS', 3)) || 3) + ' tries: ' + failed.slice(0, 20).join(', ') + '.',
       'See the Email Delivery Log tab for the reason. To try again, set the Email status of the bill back to Queued.'], 24);
  }
  var lastDaily = Number(props.getProperty('LAST_DAILY_RUN') || 0);
  if (lastDaily && now - lastDaily > 26 * 3600000) {
    problems.push('Daily job has not run since ' + new Date(lastDaily));
    sendAlert_('DAILY_JOB_STOPPED', 'The daily report job has stopped running',
      ['runScheduledReports last ran ' + Utilities.formatDate(new Date(lastDaily), TZ, 'dd-MM-yyyy HH:mm') + '. Weekly/monthly reports and the morning health check depend on it.',
       'Fix: run installReportSchedule in the project, then listScheduledJobs.']);
  }
  return problems;
}

/** Morning health check (called from runScheduledReports). Sends one summary email only if something is wrong. */
function runHealthCheck_() {
  var problems = [], now = Date.now(), props = PropertiesService.getScriptProperties();
  props.setProperty('LAST_DAILY_RUN', String(now));
  var lastBg = Number(props.getProperty('LAST_BACKGROUND_RUN') || 0);
  var paused = Number(props.getProperty('PAUSE_BACKGROUND_UNTIL') || 0) > now;
  if (!paused && (!lastBg || now - lastBg > 30 * 60000)) problems.push('The 5-minute PDF and email job has not run since ' + (lastBg ? Utilities.formatDate(new Date(lastBg), TZ, 'dd-MM-yyyy HH:mm') : 'it was installed') + '. Fix: run installBackgroundJobs.');
  var lastBk = Number(props.getProperty('LAST_BACKUP_OK') || 0);
  if (!lastBk || now - lastBk > 30 * 3600000) problems.push('No successful nightly backup in the last 30 hours' + (lastBk ? ' (last: ' + Utilities.formatDate(new Date(lastBk), TZ, 'dd-MM-yyyy HH:mm') + ')' : '') + '. Fix: run runDailyBackup, then installBackupSchedule.');
  var jobs = ScriptApp.getProjectTriggers().map(function (t) { return t.getHandlerFunction(); });
  ['runBackgroundJobs', 'runScheduledReports', 'runDailyBackup'].forEach(function (j) { if (jobs.indexOf(j) === -1) problems.push('Scheduled job missing: ' + j + '. Fix: run setupNewInstallation.'); });
  var quota = MailApp.getRemainingDailyQuota();
  if (quota < 10) problems.push('Only ' + quota + ' Gmail sends left today; customer emails will wait until tomorrow.');
  var ignore = /^(LOGIN_FAILED|USER_LOCKED|PASSWORD_RESET_REQUEST|PASSWORD_RESET_FAILED|ALERT_SENT|HEALTH_CHECK)$/;
  var fails = readRecords_(SHEETS.AUDIT_LOG).filter(function (r) {
    return String(r['Result']) === 'FAIL' && !ignore.test(String(r['Action'])) && now - new Date(r['Timestamp']).getTime() < 24 * 3600000;
  });
  if (fails.length) problems.push(fails.length + ' failure(s) in the Audit Log in the last 24 hours, for example: ' +
    fails.slice(-5).map(function (r) { return r['Action'] + ' ' + r['Reference'] + ' (' + String(r['Details']).slice(0, 80) + ')'; }).join('; '));
  var locks = readRecords_(SHEETS.AUDIT_LOG).filter(function (r) { return r['Action'] === 'USER_LOCKED' && now - new Date(r['Timestamp']).getTime() < 24 * 3600000; }).length;
  if (locks >= 3) problems.push(locks + ' user IDs were locked for wrong passwords in the last 24 hours. Check that nobody is guessing passwords.');
  if (problems.length) sendAlert_('HEALTH_' + istDate_(new Date()), 'Morning health check: ' + problems.length + ' problem(s)', problems.map(function (p, i) { return (i + 1) + '. ' + p; }), 24);
  audit_('HEALTH_CHECK', 'System', istDate_(new Date()), problems.length ? problems.join(' | ').slice(0, 900) : 'All checks passed', problems.length ? 'FAIL' : 'OK');
  return problems;
}

/** Run from the editor any time: the morning health check now (alerts only if something is wrong). */
function healthCheckNow() { asSystem_(); var p = runHealthCheck_(); Logger.log(p.length ? p.join('\n') : 'All checks passed'); return p; }

/** Stage 12B test (TEST only): alert throttling, PDF-overdue detection, health check and its email. */
function testAlertsStage12B() {
  if (getSetting('ENVIRONMENT') !== 'TEST') throw new Error('Tests run only in the TEST environment.');
  asSystem_();
  var out = [], ok = function (c, m) { out.push((c ? 'PASS ' : 'FAIL ') + m); }, props = PropertiesService.getScriptProperties();
  props.setProperty('PAUSE_BACKGROUND_UNTIL', String(Date.now() + 10 * 60000));   // keep the 5-minute job away while a test row is changed
  try {
  var key = 'SELFTEST_' + Date.now();
  ok(sendAlert_(key, 'Test alert (please ignore)', ['This is a test of the Yavira Billing alert email.']) === true, 'An alert email is sent to ' + alertRecipient_());
  ok(sendAlert_(key, 'Test alert (please ignore)', ['Repeat']) === false, 'The same alert is not repeated within 6 hours');
  props.deleteProperty('ALERT_' + key);

  var sh = getDb_().getSheetByName(SHEETS.INVOICE_REGISTER), map = getHeaderMap_(SHEETS.INVOICE_REGISTER);
  var row = 2, saved = sh.getRange(row, map['PDF file ID']).getValue(), savedAt = sh.getRange(row, map['Created at']).getValue();
  var doc = String(sh.getRange(row, map['Document no.']).getValue());
  props.setProperty('ALERT_PDF_OVERDUE', String(Date.now()));          // detect without emailing
  try {
    sh.getRange(row, map['PDF file ID']).setValue('');
    sh.getRange(row, map['Created at']).setValue(new Date(Date.now() - 3600000));
    var p = checkAfterBackgroundRun_([]);
    ok(p.some(function (x) { return x.indexOf('PDF overdue') === 0 && x.indexOf(doc) !== -1; }), 'A bill without its PDF after 30 minutes is detected (' + doc + ')');
  } finally {
    sh.getRange(row, map['PDF file ID']).setValue(saved);
    sh.getRange(row, map['Created at']).setValue(savedAt);
    props.deleteProperty('ALERT_PDF_OVERDUE');
  }
  ok(!checkAfterBackgroundRun_([]).some(function (x) { return x.indexOf('PDF overdue') === 0; }), 'Once the PDF is there, no alert');

  var keepBk = props.getProperty('LAST_BACKUP_OK');
  props.setProperty('LAST_BACKUP_OK', String(Date.now() - 40 * 3600000));
  var today = 'ALERT_HEALTH_' + istDate_(new Date()).replace(/-/g, '_'), keepHealth = props.getProperty(today);
  props.deleteProperty(today);
  var h = runHealthCheck_();
  ok(h.some(function (x) { return /No successful nightly backup/.test(x); }), 'Morning health check notices a missing backup and emails a summary');
  if (keepBk) props.setProperty('LAST_BACKUP_OK', keepBk); else props.deleteProperty('LAST_BACKUP_OK');
  if (keepHealth) props.setProperty(today, keepHealth);
  var h2 = runHealthCheck_();
  ok(!h2.some(function (x) { return /backup|job missing|has not run/.test(x); }), 'With a recent backup and all jobs installed, those checks pass' + (h2.length ? ' (other notes: ' + h2.join(' / ').slice(0, 200) + ')' : ''));
  } finally {
    props.deleteProperty('PAUSE_BACKGROUND_UNTIL');
  }
  Logger.log(out.join('\n'));
  return out;
}
