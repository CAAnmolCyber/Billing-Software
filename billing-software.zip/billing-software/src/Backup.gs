/**
 * Yavira Billing System - Backup.gs
 * Stage 12: a full copy of the database every night, kept in Drive under Backups / yyyy-MM.
 * Stage 12B: plus a weekly off-site Excel copy emailed to OFFSITE_BACKUP_EMAIL (another Google account), and failure alerts.
 *
 *  - runDailyBackup() runs at about 11 PM IST (installBackupSchedule installs it) as the owner.
 *  - Each backup is a complete Google Sheets copy of every tab (invoices, customers, registers, logs, users).
 *  - Nothing is ever deleted automatically. Each copy is small (well under 1 MB); remove old ones by hand if wanted.
 *  - Invoice PDFs need no separate backup: they already live in Drive under Invoices / FY / month.
 *  - To restore: see the Owner's Maintenance and Recovery Guide (open the backup, make a copy, point the app at it).
 */

function runDailyBackup() {
  var src = DriveApp.getFileById(getDb_().getId());
  var root = DriveApp.getFolderById(String(getSetting('BACKUP_FOLDER_ID')));
  var now = new Date();
  var folder = getOrCreateFolder_(root, Utilities.formatDate(now, TZ, 'yyyy-MM'));
  var name = 'Backup - ' + src.getName() + ' - ' + Utilities.formatDate(now, TZ, 'yyyy-MM-dd HHmm');
  try {
    var copy = src.makeCopy(name, folder);
    audit_('BACKUP', 'System', copy.getName(), 'Saved in Backups / ' + folder.getName() + ' (' + copy.getId() + ')', 'OK');
    PropertiesService.getScriptProperties().setProperty('LAST_BACKUP_OK', String(Date.now()));
  } catch (e) {
    audit_('BACKUP', 'System', name, 'Failed: ' + e.message, 'FAIL');
    sendAlert_('BACKUP_FAILED', 'Nightly backup failed', ['The nightly copy of the database could not be saved: ' + e.message,
      'Your data is still safe in the database itself. Run runDailyBackup to try again.']);
    throw e;
  }
  var day = String(optionalSetting_('OFFSITE_BACKUP_DAY', 'SUNDAY')).trim().toUpperCase();
  if (String(optionalSetting_('OFFSITE_BACKUP_EMAIL', '') || '').trim() && (day === 'DAILY' || Utilities.formatDate(now, TZ, 'EEEE').toUpperCase() === day)) {
    try { sendOffsiteBackup_(); } catch (e) { /* logged and alerted inside */ }
  }
  return {name: copy.getName(), id: copy.getId(), folder: folder.getName()};
}

/**
 * Off-site copy: the whole database as an Excel file, emailed to OFFSITE_BACKUP_EMAIL (a different Google account),
 * so the data survives even if the owner account is lost. Weekly by default (OFFSITE_BACKUP_DAY = SUNDAY, or DAILY).
 * Password hashes are left out. TEST_MODE sends it to TEST_EMAIL_REDIRECT instead.
 */
function sendOffsiteBackup_() {
  var s = getSettings_(), to = String(optionalSetting_('OFFSITE_BACKUP_EMAIL', '') || '').trim(), env = String(s.ENVIRONMENT);
  if (isTrue_(s.TEST_MODE)) to = String(s.TEST_EMAIL_REDIRECT || '').trim();
  if (!to) throw new Error('OFFSITE_BACKUP_EMAIL is empty');
  try {
    var db = getDb_(), stamp = Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd'), rows = 0;
    var sheets = db.getSheets().map(function (sh) {
      var values = sh.getDataRange().getValues(), drop = [];
      if (sh.getName() === SHEETS.USERS) values[0].forEach(function (h, i) { if (h === 'Password hash' || h === 'Salt') drop.push(i); });
      rows += Math.max(0, values.length - 1);
      var out = values.map(function (r) {
        return r.filter(function (_, i) { return drop.indexOf(i) === -1; }).map(function (v) {
          return v instanceof Date ? Utilities.formatDate(v, TZ, 'dd-MM-yyyy HH:mm:ss') : v;
        });
      });
      var ints = (out[0] || []).map(function (_, c) { return c; }).filter(function (c) {      // whole-number columns (mobiles, counts) without decimals
        return out.slice(1).every(function (r) { return typeof r[c] !== 'number' || r[c] % 1 === 0; });
      });
      return {name: sh.getName(), header: 0, rows: out, intCols: ints};
    });
    var file = 'Yavira Billing ' + (env === 'TEST' ? 'TEST ' : '') + 'database backup ' + stamp + '.xlsx';
    var blob = buildXlsxBlob_(sheets, file);
    GmailApp.sendEmail(to, (isTrue_(s.TEST_MODE) ? '[TEST] ' : '') + 'Yavira Billing - database backup ' + stamp,
      'Attached: a full copy of the Yavira Billing database (' + sheets.length + ' tabs, ' + rows + ' rows) as of ' + stamp + '.\n\n' +
      'Keep this email. It is the off-site copy in case the main Google account is ever lost.\n' +
      'To restore: upload the file to Google Drive, open it with Google Sheets and follow "Backups and recovery" in the owner\'s guide.\n' +
      'Login passwords are not included; after a restore the owner resets the admin login with ownerResetAdmin.\n',
      {attachments: [blob], name: 'Yavira Billing backups'});
    PropertiesService.getScriptProperties().setProperty('LAST_OFFSITE_BACKUP_OK', String(Date.now()));
    audit_('OFFSITE_BACKUP', 'System', file, 'Emailed to ' + maskEmail_(to) + ' (' + Math.round(blob.getBytes().length / 1024) + ' KB)', 'OK');
    return {to: to, file: file, rows: rows, kb: Math.round(blob.getBytes().length / 1024)};
  } catch (e) {
    audit_('OFFSITE_BACKUP', 'System', to, 'Failed: ' + e.message, 'FAIL');
    sendAlert_('OFFSITE_BACKUP_FAILED', 'Off-site backup email failed', ['The weekly Excel copy of the database could not be emailed: ' + e.message,
      'The nightly backup inside Drive is not affected. Run offsiteBackupNow to try again.']);
    throw e;
  }
}

/** Run from the editor any time: emails the off-site Excel backup now. */
function offsiteBackupNow() { asSystem_(); var r = sendOffsiteBackup_(); Logger.log('Off-site backup sent: ' + r.file + ' to ' + r.to + ' (' + r.rows + ' rows, ' + r.kb + ' KB)'); return r; }

/** Installs the nightly backup (about 11 PM IST). Run once as the owner. */
function installBackupSchedule() {
  ScriptApp.getProjectTriggers().forEach(function (t) { if (t.getHandlerFunction() === 'runDailyBackup') ScriptApp.deleteTrigger(t); });
  ScriptApp.newTrigger('runDailyBackup').timeBased().everyDays(1).atHour(23).inTimezone(TZ).create();
  audit_('TRIGGER_INSTALLED', 'System', 'runDailyBackup', 'Nightly backup at about 11 PM IST, runs as ' + Session.getEffectiveUser().getEmail(), 'OK');
  Logger.log('Nightly backup installed (about 11 PM IST), running as ' + Session.getEffectiveUser().getEmail());
}

/** Owner check after setup or migration: every scheduled job, its timing and the account it runs as. */
function listScheduledJobs() {
  var out = ScriptApp.getProjectTriggers().map(function (t) { return t.getHandlerFunction() + ' (' + t.getEventType() + ')'; });
  out.push('All jobs run as: ' + Session.getEffectiveUser().getEmail());
  out.push('Environment: ' + getSetting('ENVIRONMENT') + ' | TEST_MODE ' + getSetting('TEST_MODE') + ' | Customer emails ' + getSetting('CUSTOMER_EMAIL_ENABLED'));
  Logger.log(out.join('\n'));
  return out;
}

/** Backup test: makes one backup and checks it is a complete copy (same tabs, same number of invoice rows). */
function testBackup() {
  var r = runDailyBackup();
  var copy = SpreadsheetApp.openById(r.id), live = getDb_();
  var count = function (ss) { return ss.getSheets().map(function (s) { return s.getName() + ':' + (s.getName() === SHEETS.AUDIT_LOG ? 'log' : s.getLastRow()); }).join(', '); };
  var tabs = count(live), copyTabs = count(copy);   // the Audit Log keeps growing (the backup itself writes to it), so only its presence is compared
  var out = [(tabs === copyTabs ? 'PASS ' : 'FAIL ') + 'Backup "' + r.name + '" in Backups / ' + r.folder + ' has every tab and row: ' + copyTabs];
  Logger.log(out.join('\n'));
  return out;
}

/**
 * One-click setup for a new installation (LIVE now, the clinic's own account later). Run once as the owner,
 * after setupProject(). Installs every scheduled job, creates the first admin (temporary password in the log),
 * makes the first backup and checks the database. Safe to run again: jobs are replaced, never duplicated.
 */
function setupNewInstallation() {
  asSystem_();
  var out = [];
  installBackgroundJobs(); installReportSchedule(); installBackupSchedule();
  out.push('Scheduled jobs installed: PDFs + emails every 5 min, reports daily ~7 AM (sent Mondays and the 1st), backup nightly ~11 PM (+ weekly off-site Excel copy by email), failure alerts to ' + alertRecipient_() + '');
  try { createFirstAdmin(); out.push('First admin created: see the "Temporary password" line above'); }
  catch (e) { out.push('First admin: ' + e.message); }
  var b = runDailyBackup(); out.push('First backup saved: ' + b.name);
  out = out.concat(verifySchema()).concat(testConnection()).concat(listScheduledJobs());
  Logger.log(out.join('\n'));
  return out;
}
