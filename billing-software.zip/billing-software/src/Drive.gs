/**
 * Yavira Billing System - Drive.gs
 * Stage 7: files every issued document as a PDF in Google Drive:
 *   Invoices / FY 2026-27 / 2026-11 November / TI-26-27-0001.pdf
 *
 * How it works
 *  - Issuing a bill never waits for Drive. The bill is saved to the Sheet first; its "PDF file ID" is left blank.
 *  - processPdfQueue() runs every 5 minutes as the app owner (installed by installPdfWorker). It finds documents
 *    without a PDF, creates the PDF in the right financial-year and month folder, and writes the file ID and link
 *    back to the Invoice Register. Because it runs as the owner, every PDF is owned by the owner account.
 *  - If Drive fails, the error goes to the Audit Log and the document is simply tried again on the next run.
 *  - Running it twice never creates a second copy: an existing file with the same name is reused.
 */

var PDF_BATCH_LIMIT = 20;     // documents per run (keeps each run well inside Apps Script's 6-minute limit)

/** TI-26-27-0001.pdf, or TI-26-27-0001 CANCELLED.pdf for the copy filed after a cancellation (the original is kept). */
function pdfFileName_(docNo, cancelled) { return String(docNo).replace(/\//g, '-') + (cancelled ? ' CANCELLED' : '') + '.pdf'; }

function getOrCreateFolder_(parent, name) {
  var it = parent.getFoldersByName(name);
  return it.hasNext() ? it.next() : parent.createFolder(name);
}

/** Invoices / FY yyyy-yy / yyyy-MM MonthName, created on first use. */
function monthFolderFor_(date, rootOverride) {
  var root = DriveApp.getFolderById(String(rootOverride || getSetting('INVOICE_FOLDER_ID')));
  var fy = financialYearLabel_(date);                                // '26-27'
  var fyName = 'FY 20' + fy.split('-')[0] + '-' + fy.split('-')[1];  // 'FY 2026-27'
  var monthName = Utilities.formatDate(date, TZ, 'yyyy-MM MMMM');    // '2026-11 November'
  return getOrCreateFolder_(getOrCreateFolder_(root, fyName), monthName);
}

/** Saves one document's PDF (or finds the one already saved). Returns the Drive file. */
function filePdf_(docNo, business, settings, logo, rootOverride) {
  var d = loadDoc_(docNo);
  var folder = monthFolderFor_(new Date(d.head['Document date']), rootOverride);
  var name = pdfFileName_(docNo, d.head['Document status'] === 'Cancelled');
  var existing = folder.getFilesByName(name);
  if (existing.hasNext()) return existing.next();
  var html = renderDocHtml_(d, business, settings, logo);
  var blob = HtmlService.createHtmlOutput(html).getBlob().getAs('application/pdf').setName(name);
  return folder.createFile(blob);
}

/**
 * Background job: files every issued document that has no PDF yet.
 * opts.rootOverride is only used by the failure test.
 */
function processPdfQueue(opts) {
  opts = (opts && opts.rootOverride) ? opts : {};
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(5000)) return {skipped: 'another run in progress'};
  var result = {filed: [], failed: [], pending: 0};
  try {
    var sh = getDb_().getSheetByName(SHEETS.INVOICE_REGISTER);
    var last = sh.getLastRow();
    if (last < 2) return result;
    var map = getHeaderMap_(SHEETS.INVOICE_REGISTER);
    var values = sh.getRange(2, 1, last - 1, sh.getLastColumn()).getValues();
    var todo = [];
    values.forEach(function (r, i) {
      if (r[map['Document no.'] - 1] && !r[map['PDF file ID'] - 1]) todo.push({row: i + 2, docNo: String(r[map['Document no.'] - 1])});
    });
    result.pending = todo.length;
    if (!todo.length) return result;

    var settings = engineSettings_(), business = getBusinessProfile_(), logo = getLogoDataUrl_();
    todo.slice(0, PDF_BATCH_LIMIT).forEach(function (t) {
      try {
        var f = filePdf_(t.docNo, business, settings, logo, opts.rootOverride);
        sh.getRange(t.row, map['PDF file ID']).setValue("'" + f.getId());
        sh.getRange(t.row, map['PDF link']).setValue(f.getUrl());
        result.filed.push(t.docNo);
        audit_('PDF_FILED', 'Drive', t.docNo, f.getName() + ' in ' + f.getParents().next().getName(), 'OK');
      } catch (e) {
        result.failed.push(t.docNo + ': ' + e.message);
        audit_('PDF_FILED', 'Drive', t.docNo, 'Will retry on next run. Error: ' + e.message, 'FAIL');
      }
    });
    SpreadsheetApp.flush();
    result.pending = todo.length - result.filed.length;
    return result;
  } finally {
    lock.releaseLock();
  }
}

/** Kept for Stage 7 compatibility: now installs the combined PDF + email job (see Email.gs). */
function installPdfWorker() { installBackgroundJobs(); }

/** How many documents are still waiting for a PDF (for the CA / troubleshooting). */
function pdfQueueStatus() {
  var pending = readRecords_(SHEETS.INVOICE_REGISTER).filter(function (r) { return r['Document no.'] && !r['PDF file ID']; })
    .map(function (r) { return r['Document no.']; });
  Logger.log('Waiting for PDF: ' + (pending.length ? pending.join(', ') : 'none'));
  return pending;
}

/**
 * Stage 7 test (TEST environment only):
 *  1. Drive failure: a run pointed at an invalid folder files nothing, logs the errors, and loses no bill.
 *  2. Normal run: every waiting document is filed in the right FY / month folder and linked in the register.
 *  3. Second run: nothing new is created (no duplicates).
 */
function testDriveStage7() {
  if (getSetting('ENVIRONMENT') !== 'TEST') throw new Error('Tests run only in the TEST environment.');
  var out = [];
  var before = pdfQueueStatus();
  out.push('Waiting before test: ' + before.length + ' (' + before.join(', ') + ')');

  var fail = processPdfQueue({rootOverride: 'INVALID_FOLDER_ID_FOR_TEST'});
  var afterFail = pdfQueueStatus();
  out.push((fail.filed.length === 0 && fail.failed.length === before.length && afterFail.length === before.length ? 'PASS ' : 'FAIL ') +
    'Drive failure: filed ' + fail.filed.length + ', failed ' + fail.failed.length + ', still waiting ' + afterFail.length + ' (nothing lost)');

  var ok = processPdfQueue();
  var afterOk = pdfQueueStatus();
  out.push((ok.filed.length === before.length && afterOk.length === 0 ? 'PASS ' : 'FAIL ') +
    'Normal run: filed ' + ok.filed.length + ', still waiting ' + afterOk.length);

  var checks = readRecords_(SHEETS.INVOICE_REGISTER).filter(function (r) { return r['PDF file ID']; }).map(function (r) {
    var f = DriveApp.getFileById(String(r['PDF file ID']));
    var month = f.getParents().next(), fy = month.getParents().next();
    var good = f.getName() === pdfFileName_(r['Document no.'], r['Document status'] === 'Cancelled') && f.getSize() > 1000 && f.getMimeType() === 'application/pdf' &&
      /^FY 20\d\d-\d\d$/.test(fy.getName()) && /^\d{4}-\d{2} [A-Za-z]+$/.test(month.getName());
    return (good ? 'PASS ' : 'FAIL ') + r['Document no.'] + ' -> ' + fy.getName() + ' / ' + month.getName() + ' / ' + f.getName() +
      ' (' + Math.round(f.getSize() / 1024) + ' KB, owner ' + f.getOwner().getEmail() + ')';
  });
  out = out.concat(checks);

  var again = processPdfQueue();
  out.push((again.filed.length === 0 ? 'PASS ' : 'FAIL ') + 'Second run creates no duplicates (filed ' + again.filed.length + ')');
  Logger.log(out.join('\n'));
  return out;
}
