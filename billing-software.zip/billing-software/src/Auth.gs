/**
 * Yavira Billing System - Auth.gs
 * Stage 12: the app's own login (user ID + password), so staff never need access to the Sheet or Drive.
 * Stage 12A: email address per user, login with ID or email, "Forgot password" by emailed code, Developer role.
 *
 * How it works
 *  - The web app runs as the owner account. Staff open the link (signed in to any Google account), then log in
 *    with the user ID (or email) and password an admin gave them. First login forces a new password.
 *  - Passwords are never stored: only a salted, repeated SHA-256 hash in the "Users" tab (owner-only).
 *  - A login creates a random session token kept for 6 hours of inactivity (Apps Script cache). Every server
 *    call from the screen must carry it; without a valid token nothing is returned.
 *  - 5 wrong passwords lock that user ID for 15 minutes. Messages never reveal whether the ID exists.
 *  - Roles: Developer (everything, protected: clinic admins cannot change, reset or switch it off),
 *    Admin (billing, customers, reports, cancellations, user management) and Staff (billing, customers).
 *  - Forgot password: a 6-digit code is emailed to the address on file, valid 15 minutes, 5 tries,
 *    at most 3 codes per user per hour. Only a scrambled (hashed) copy of the code is kept.
 *  - Scheduled jobs and editor-run tests use a "system" identity that a web visitor can never obtain.
 */

var APP_USER_ = null;                          // the logged-in user for this execution only
var SESSION_SECONDS_ = 6 * 3600;               // Apps Script cache maximum
var MAX_FAILED_ = 5, LOCK_MINUTES_ = 15, HASH_ROUNDS_ = 300, MIN_PASSWORD_ = 8;
var RESET_MINUTES_ = 15, RESET_MAX_TRIES_ = 5, RESET_MAX_PER_HOUR_ = 3, RESET_MAX_ALL_PER_HOUR_ = 30;
var ROLES_ = ['Developer', 'Admin', 'Staff'];

/** Marks the current execution as the system (editor-run tests and scheduled jobs). Never reachable from the web. */
function asSystem_() { APP_USER_ = {id: 'system', name: 'System (' + Session.getEffectiveUser().getEmail() + ')', role: 'Admin', system: true}; return APP_USER_; }
function asGuest_() { APP_USER_ = {id: 'guest', name: 'Not logged in', role: 'None'}; return APP_USER_; }

function hashPassword_(password, salt) {
  var h = salt + '|' + password;
  for (var i = 0; i < HASH_ROUNDS_; i++) {
    h = Utilities.base64Encode(Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, h, Utilities.Charset.UTF_8));
  }
  return h;
}
function newSalt_() { return Utilities.getUuid().replace(/-/g, ''); }
function isAdminRole_(role) { return role === 'Admin' || role === 'Developer'; }
function validEmail_(e) { return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e); }
function maskEmail_(e) { var p = String(e).split('@'); return p[0].slice(0, 2) + '***@' + (p[1] || ''); }

/** Users tab helpers. */
function usersSheet_() { return getDb_().getSheetByName(SHEETS.USERS); }
function findUserWhere_(test) {
  var sh = usersSheet_(), last = sh.getLastRow();
  if (last < 2) return null;
  var map = getHeaderMap_(SHEETS.USERS);
  var values = sh.getRange(2, 1, last - 1, sh.getLastColumn()).getValues();
  for (var i = 0; i < values.length; i++) {
    var u = {_row: i + 2};
    Object.keys(map).forEach(function (h) { u[h] = values[i][map[h] - 1]; });
    if (String(u['User ID']).trim() && test(u)) return u;
  }
  return null;
}
function findUser_(userId) {
  var id = String(userId || '').trim().toLowerCase();
  if (!id) return null;
  return findUserWhere_(function (u) { return String(u['User ID']).trim().toLowerCase() === id; });
}
/** Accepts either the user ID or the email address on file. */
function findUserByLogin_(idOrEmail) {
  var s = String(idOrEmail || '').trim().toLowerCase();
  if (!s) return null;
  if (s.indexOf('@') === -1) return findUser_(s);
  return findUserWhere_(function (u) { return String(u['Email'] || '').trim().toLowerCase() === s; });
}
function updateUser_(row, fields) {
  var sh = usersSheet_(), map = getHeaderMap_(SHEETS.USERS);
  Object.keys(fields).forEach(function (k) { sh.getRange(row, map[k]).setValue(fields[k]); });
}
function publicUser_(u) {
  return {id: String(u['User ID']), name: String(u['Name']), role: String(u['Role']), mustChange: isTrue_(u['Must change password'])};
}

/* ---------------- Login and sessions ---------------- */

/** Business name and logo for the login screen (no private data). */
function getLoginInfo() {
  var p = getBusinessProfile_();
  return {tradeName: p['Trade name'], logo: getLogoDataUrl_(), testMode: isTrue_(getSetting('TEST_MODE'))};
}

function login(userId, password) {
  var lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    var u = findUserByLogin_(userId), now = new Date(), generic = 'User ID or password is wrong.';
    if (!u || !isTrue_(u['Active'])) {
      Utilities.sleep(800);
      asGuest_();
      audit_('LOGIN_FAILED', 'User', String(userId || '').slice(0, 40), 'Unknown or inactive user ID', 'FAIL');
      throw new Error(generic);
    }
    if (u['Locked until'] && new Date(u['Locked until']) > now) {
      throw new Error('Too many wrong attempts. This ID is locked until ' + Utilities.formatDate(new Date(u['Locked until']), TZ, 'hh:mm a') +
        '. You can also use "Forgot password?" to unlock it.');
    }
    if (hashPassword_(String(password || ''), String(u['Salt'])) !== String(u['Password hash'])) {
      var failed = Number(u['Failed attempts'] || 0) + 1;
      asGuest_();
      if (failed >= MAX_FAILED_) {
        updateUser_(u._row, {'Failed attempts': 0, 'Locked until': new Date(now.getTime() + LOCK_MINUTES_ * 60000)});
        audit_('USER_LOCKED', 'User', u['User ID'], MAX_FAILED_ + ' wrong passwords; locked for ' + LOCK_MINUTES_ + ' minutes', 'FAIL');
      } else {
        updateUser_(u._row, {'Failed attempts': failed});
        audit_('LOGIN_FAILED', 'User', u['User ID'], 'Wrong password (' + failed + ' of ' + MAX_FAILED_ + ')', 'FAIL');
      }
      Utilities.sleep(800);
      throw new Error(generic);
    }
    updateUser_(u._row, {'Failed attempts': 0, 'Locked until': '', 'Last login': now});
    var user = publicUser_(u), token = Utilities.getUuid() + Utilities.getUuid();
    CacheService.getScriptCache().put('S_' + token, JSON.stringify(user), SESSION_SECONDS_);
    CacheService.getScriptCache().remove('REVOKED_' + user.id.toLowerCase());
    APP_USER_ = user;
    audit_('LOGIN', 'User', user.id, 'Logged in (' + user.role + ')', 'OK');
    return {token: token, user: user};
  } finally {
    lock.releaseLock();
  }
}

function logout(token) {
  if (!token) return true;
  var cache = CacheService.getScriptCache(), s = cache.get('S_' + token);
  if (s) { APP_USER_ = JSON.parse(s); audit_('LOGOUT', 'User', APP_USER_.id, 'Logged out', 'OK'); }
  cache.remove('S_' + token);
  return true;
}

/**
 * Every screen-facing function calls this first. Returns the logged-in user or throws.
 * opts.allowMustChange lets changePassword run before the first password change.
 */
function checkAccess_(token, opts) {
  if (!token && APP_USER_ && APP_USER_.system) return APP_USER_;
  if (!token) throw new Error('LOGIN_REQUIRED: Please log in.');
  var cache = CacheService.getScriptCache(), s = cache.get('S_' + token);
  if (!s) throw new Error('LOGIN_REQUIRED: Your session has ended. Please log in again.');
  var user = JSON.parse(s);
  if (cache.get('REVOKED_' + user.id.toLowerCase())) { cache.remove('S_' + token); throw new Error('LOGIN_REQUIRED: Your access was changed. Please log in again.'); }
  if (user.mustChange && !(opts && opts.allowMustChange)) throw new Error('PASSWORD_CHANGE_REQUIRED: Please set a new password first.');
  cache.put('S_' + token, s, SESSION_SECONDS_);           // sliding 6-hour window
  APP_USER_ = user;
  return user;
}

function checkAdmin_(token) {
  var u = checkAccess_(token);
  if (!isAdminRole_(u.role)) throw new Error('Only an admin can do this.');
  return u;
}

function isAdmin_() { return !!(APP_USER_ && isAdminRole_(APP_USER_.role)); }

/** Name recorded in "Created by", the Audit Log and cancellation notes. */
function currentUser_() {
  return APP_USER_ ? (APP_USER_.system ? APP_USER_.name : APP_USER_.name + ' [' + APP_USER_.id + ']')
    : (Session.getEffectiveUser().getEmail() || 'unknown');
}

function checkPasswordRules_(userId, password) {
  var p = String(password || '');
  if (p.length < MIN_PASSWORD_) throw new Error('Password must be at least ' + MIN_PASSWORD_ + ' characters.');
  if (p.toLowerCase().indexOf(String(userId).toLowerCase()) !== -1) throw new Error('Password must not contain the user ID.');
  if (!/[a-zA-Z]/.test(p) || !/\d/.test(p)) throw new Error('Password must contain letters and numbers.');
}

function changePassword(token, oldPassword, newPassword) {
  var me = checkAccess_(token, {allowMustChange: true});
  var u = findUser_(me.id);
  if (!u || hashPassword_(String(oldPassword || ''), String(u['Salt'])) !== String(u['Password hash'])) throw new Error('Current password is wrong.');
  checkPasswordRules_(me.id, newPassword);
  if (newPassword === oldPassword) throw new Error('Choose a password different from the current one.');
  var salt = newSalt_();
  updateUser_(u._row, {'Password hash': hashPassword_(newPassword, salt), 'Salt': salt, 'Must change password': false});
  me.mustChange = false;
  CacheService.getScriptCache().put('S_' + token, JSON.stringify(me), SESSION_SECONDS_);
  audit_('PASSWORD_CHANGED', 'User', me.id, 'Changed own password', 'OK');
  return me;
}

/* ---------------- Forgot password (emailed code) ---------------- */

var RESET_SENT_MSG_ = 'If this ID or email belongs to an active user with an email address on file, a 6-digit code has been sent to that email. ' +
  'It is valid for 15 minutes. No email? Check spam, or ask the clinic admin to reset your password.';
var RESET_BAD_MSG_ = 'This code is wrong or has expired. Check the code, or ask for a new one.';

function newResetCode_() {
  var b = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, Utilities.getUuid() + Utilities.getUuid());
  var n = ((b[0] & 0xff) * 16777216 + (b[1] & 0xff) * 65536 + (b[2] & 0xff) * 256 + (b[3] & 0xff)) % 1000000;
  return ('000000' + n).slice(-6);
}

/** Called from the login screen. Always answers with the same message, so it never reveals which IDs exist. */
function requestPasswordReset(idOrEmail) { return requestPasswordReset_(idOrEmail, {}); }

/** opts.noSend / opts.returnCode are for editor-run tests only (functions ending in _ cannot be called from the web). */
function requestPasswordReset_(idOrEmail, opts) {
  opts = opts || {};
  asGuest_();
  var lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    var cache = CacheService.getScriptCache(), u = findUserByLogin_(idOrEmail), ref = String(idOrEmail || '').slice(0, 40);
    var email = u ? String(u['Email'] || '').trim() : '';
    Utilities.sleep(opts.noSend ? 0 : 600);
    if (!u || !isTrue_(u['Active']) || !validEmail_(email)) {
      audit_('PASSWORD_RESET_REQUEST', 'User', ref, !u ? 'Unknown ID or email' : !isTrue_(u['Active']) ? 'User is inactive' : 'No email on file', 'FAIL');
      return {message: RESET_SENT_MSG_};
    }
    var id = String(u['User ID']).toLowerCase();
    var count = Number(cache.get('RC_' + id) || 0), all = Number(cache.get('RC_ALL') || 0);
    if (count >= RESET_MAX_PER_HOUR_ || all >= RESET_MAX_ALL_PER_HOUR_) {
      audit_('PASSWORD_RESET_REQUEST', 'User', id, 'Too many codes requested in the last hour; none sent', 'FAIL');
      return {message: RESET_SENT_MSG_};
    }
    cache.put('RC_' + id, String(count + 1), 3600);
    cache.put('RC_ALL', String(all + 1), 3600);
    var code = newResetCode_(), salt = newSalt_();
    cache.put('RST_' + id, JSON.stringify({h: hashPassword_(code, salt), s: salt, tries: 0, exp: Date.now() + RESET_MINUTES_ * 60000}), RESET_MINUTES_ * 60);
    var sent = opts.noSend ? {to: email, skipped: true} : sendResetEmail_(email, String(u['Name']), id, code);
    audit_('PASSWORD_RESET_REQUEST', 'User', id, 'Code ' + (opts.noSend ? 'created (test, not emailed)' : 'emailed to ' + maskEmail_(sent.to)), 'OK');
    var out = {message: RESET_SENT_MSG_};
    if (opts.returnCode) out.code = code;
    return out;
  } finally {
    lock.releaseLock();
  }
}

/** Sends the code. TEST_MODE sends it to TEST_EMAIL_REDIRECT instead, like every other email. */
function sendResetEmail_(email, name, id, code) {
  var s = getSettings_(), es = emailSettings_(), to = email, subject = 'Your Yavira Billing password reset code: ' + code;
  if (isTrue_(s.TEST_MODE)) {
    to = String(s.TEST_EMAIL_REDIRECT || '').trim();
    if (!to) throw new Error('TEST_MODE is on but TEST_EMAIL_REDIRECT is empty');
    subject = '[TEST] ' + subject + ' (for ' + email + ')';
  }
  if (MailApp.getRemainingDailyQuota() < 1) throw new Error('Daily email limit reached. Ask the clinic admin to reset your password.');
  var text = 'Hello ' + name + ',\n\nYour code to set a new Yavira Billing password is: ' + code + '\n\n' +
    'Enter it on the login screen within ' + RESET_MINUTES_ + ' minutes. User ID: ' + id + '\n\n' +
    'If you did not ask for this, ignore this email. Your password has not changed.\n';
  var html = '<div style="font-family:Arial,sans-serif;font-size:14px;color:#222">Hello ' + esc_(name) + ',<br><br>' +
    'Your code to set a new Yavira Billing password is:<div style="font-size:28px;letter-spacing:6px;font-weight:bold;margin:14px 0">' + code + '</div>' +
    'Enter it on the login screen within ' + RESET_MINUTES_ + ' minutes. User ID: <b>' + esc_(id) + '</b><br><br>' +
    '<span style="color:#777">If you did not ask for this, ignore this email. Your password has not changed.</span></div>';
  var options = {htmlBody: html, name: es.senderName};
  if (es.replyTo) options.replyTo = es.replyTo;
  if (es.fromAlias) options.from = es.fromAlias;
  GmailApp.sendEmail(to, subject, text, options);
  return {to: to};
}
function esc_(s) { return String(s).replace(/[&<>"]/g, function (c) { return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;'}[c]; }); }

/** Called from the login screen with the emailed code and the new password. Also unlocks a locked ID. */
function confirmPasswordReset(idOrEmail, code, newPassword) {
  asGuest_();
  var lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    var cache = CacheService.getScriptCache(), u = findUserByLogin_(idOrEmail);
    var id = u ? String(u['User ID']).toLowerCase() : '', raw = id ? cache.get('RST_' + id) : null;
    var entry = raw ? JSON.parse(raw) : null;
    if (!u || !isTrue_(u['Active']) || !entry || Date.now() > entry.exp) { Utilities.sleep(600); throw new Error(RESET_BAD_MSG_); }
    if (hashPassword_(String(code || '').trim(), entry.s) !== entry.h) {
      entry.tries++;
      if (entry.tries >= RESET_MAX_TRIES_) {
        cache.remove('RST_' + id);
        audit_('PASSWORD_RESET_FAILED', 'User', id, RESET_MAX_TRIES_ + ' wrong codes; code cancelled', 'FAIL');
        throw new Error('Too many wrong codes. This code no longer works. Ask for a new one.');
      }
      cache.put('RST_' + id, JSON.stringify(entry), Math.max(1, Math.round((entry.exp - Date.now()) / 1000)));
      audit_('PASSWORD_RESET_FAILED', 'User', id, 'Wrong code (' + entry.tries + ' of ' + RESET_MAX_TRIES_ + ')', 'FAIL');
      Utilities.sleep(600);
      throw new Error(RESET_BAD_MSG_);
    }
    checkPasswordRules_(id, newPassword);                     // code stays valid if only the password is too weak
    var salt = newSalt_();
    updateUser_(u._row, {'Password hash': hashPassword_(newPassword, salt), 'Salt': salt, 'Must change password': false,
      'Failed attempts': 0, 'Locked until': ''});
    cache.remove('RST_' + id);
    cache.put('REVOKED_' + id, '1', SESSION_SECONDS_);       // any open session elsewhere ends
    audit_('PASSWORD_RESET_BY_EMAIL', 'User', id, 'New password set with the emailed code', 'OK');
    return {message: 'Your password has been changed. Log in with your new password.', id: id};
  } finally {
    lock.releaseLock();
  }
}

/* ---------------- User management (admins) ---------------- */

function listUsers(token) {
  checkAdmin_(token);
  var order = {Developer: 0, Admin: 1, Staff: 2};
  return readRecords_(SHEETS.USERS).filter(function (u) { return String(u['User ID']).trim(); }).map(function (u) {
    return {
      id: String(u['User ID']), name: String(u['Name']), role: String(u['Role']), email: String(u['Email'] || ''),
      active: isTrue_(u['Active']), mustChange: isTrue_(u['Must change password']),
      locked: !!(u['Locked until'] && new Date(u['Locked until']) > new Date()),
      protect: String(u['Role']) === 'Developer',
      lastLogin: u['Last login'] ? Utilities.formatDate(new Date(u['Last login']), TZ, 'dd-MM-yyyy HH:mm') : 'never'
    };
  }).sort(function (a, b) { return (order[a.role] || 9) - (order[b.role] || 9); });
}

/**
 * Adds or updates a user. u = {id, name, email, role, active, tempPassword}. A new user needs a temporary password;
 * giving one to an existing user resets the password. Either way the user must change it at next login.
 * The Developer account can only be changed by the developer (and never switched off or demoted from the app).
 */
function saveUser(token, u) {
  var admin = checkAdmin_(token);
  var lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    var id = String(u.id || '').trim().toLowerCase(), name = String(u.name || '').trim(), email = String(u.email || '').trim().toLowerCase();
    if (u.role === 'Developer' && admin.role !== 'Developer') throw new Error('The Developer role can only be set up by the developer from the script editor.');
    var role = u.role === 'Admin' ? 'Admin' : 'Staff', active = u.active !== false;
    if (!/^[a-z0-9._-]{3,30}$/.test(id)) throw new Error('User ID: 3 to 30 characters, letters, numbers, dot, dash or underscore.');
    if (!name) throw new Error('Enter the person\'s name.');
    if (email && !validEmail_(email)) throw new Error('That email address does not look right.');
    if (email) {
      var clash = findUserWhere_(function (x) { return String(x['Email'] || '').trim().toLowerCase() === email && String(x['User ID']).toLowerCase() !== id; });
      if (clash) throw new Error('Another user (' + clash['User ID'] + ') already has this email address.');
    }
    var existing = findUser_(id), fields = {'Name': name, 'Role': role, 'Active': active, 'Email': email};
    if (existing && String(existing['Role']) === 'Developer') {
      if (admin.role !== 'Developer') throw new Error('This is the developer account. Only the developer can change it.');
      fields['Role'] = 'Developer'; fields['Active'] = true; role = 'Developer'; active = true;   // never demoted or switched off from the app
    }
    if (u.tempPassword) {
      checkPasswordRules_(id, u.tempPassword);
      var salt = newSalt_();
      fields['Password hash'] = hashPassword_(u.tempPassword, salt); fields['Salt'] = salt;
      fields['Must change password'] = true; fields['Failed attempts'] = 0; fields['Locked until'] = '';
    }
    if (existing) {
      var demoting = String(existing['Role']) === 'Admin' && (role !== 'Admin' || !active);
      if (demoting) {
        if (id === admin.id.toLowerCase()) throw new Error('You cannot remove your own admin access or deactivate yourself.');
        var admins = readRecords_(SHEETS.USERS).filter(function (x) { return x['Role'] === 'Admin' && isTrue_(x['Active']); });
        if (admins.length <= 1) throw new Error('There must always be at least one active clinic admin.');
      }
      updateUser_(existing._row, fields);
      if (!active || u.tempPassword || String(existing['Role']) !== role) CacheService.getScriptCache().put('REVOKED_' + id, '1', SESSION_SECONDS_);
      audit_(u.tempPassword ? 'PASSWORD_RESET' : 'USER_UPDATED', 'User', id, {name: name, email: email, role: role, active: active, by: admin.id}, 'OK');
    } else {
      if (!u.tempPassword) throw new Error('Give the new user a temporary password.');
      fields['User ID'] = id; fields['Created at'] = new Date(); fields['Created by'] = currentUser_(); fields['Failed attempts'] = 0;
      appendRecord_(SHEETS.USERS, fields);
      audit_('USER_CREATED', 'User', id, {name: name, email: email, role: role, by: admin.id}, 'OK');
    }
    return listUsers(token);
  } finally {
    lock.releaseLock();
  }
}

/**
 * Run ONCE from the editor (as the owner) to create the first admin. Refuses if any user already exists.
 * The temporary password appears in the execution log and must be changed at first login.
 */
function createFirstAdmin() {
  asSystem_();
  if (readRecords_(SHEETS.USERS).length) throw new Error('Users already exist. Use the Users tab in the app (as an admin) to add or reset users.');
  var temp = 'Yavira' + Math.floor(100000 + Math.random() * 900000);
  var salt = newSalt_();
  appendRecord_(SHEETS.USERS, {'User ID': 'admin', 'Name': 'Administrator', 'Role': 'Admin', 'Active': true,
    'Password hash': hashPassword_(temp, salt), 'Salt': salt, 'Must change password': true, 'Failed attempts': 0,
    'Created at': new Date(), 'Created by': currentUser_()});
  audit_('USER_CREATED', 'User', 'admin', 'First admin created from the script editor', 'OK');
  Logger.log('First admin created. User ID: admin   Temporary password: ' + temp + '   (must be changed at first login)');
}

/**
 * Developer only, run from the script editor: creates (or resets) the protected 'developer' login.
 * Its email is the account running this function, so "Forgot password" codes go to the developer.
 * Clinic admins can see it in the Users tab but cannot change, reset or switch it off.
 */
function setupDeveloperAccount() {
  asSystem_();
  var temp = 'Dev' + Math.floor(100000 + Math.random() * 900000) + 'x', salt = newSalt_();
  var fields = {'Name': 'Developer', 'Role': 'Developer', 'Active': true, 'Email': Session.getEffectiveUser().getEmail().toLowerCase(),
    'Password hash': hashPassword_(temp, salt), 'Salt': salt, 'Must change password': true, 'Failed attempts': 0, 'Locked until': ''};
  var u = findUser_('developer');
  if (u) updateUser_(u._row, fields);
  else { fields['User ID'] = 'developer'; fields['Created at'] = new Date(); fields['Created by'] = currentUser_(); appendRecord_(SHEETS.USERS, fields); }
  CacheService.getScriptCache().put('REVOKED_developer', '1', SESSION_SECONDS_);
  audit_(u ? 'PASSWORD_RESET' : 'USER_CREATED', 'User', 'developer', 'Developer login set up from the script editor', 'OK');
  Logger.log('Developer login ready. User ID: developer   Temporary password: ' + temp + '   Email: ' + fields['Email'] + '   (must be changed at first login)');
}

/* ---------------- Stage 12 test ---------------- */

/** Login, lockout, roles, sessions and password rules (TEST environment only; uses throw-away user IDs). */
function testAuthStage12() {
  if (getSetting('ENVIRONMENT') !== 'TEST') throw new Error('Tests run only in the TEST environment.');
  var out = [], ok = function (c, m) { out.push((c ? 'PASS ' : 'FAIL ') + m); };
  var err = function (fn) { try { fn(); return ''; } catch (e) { return e.message; } };
  var stamp = String(Date.now()).slice(-6), aId = 'tadmin' + stamp, sId = 'tstaff' + stamp;

  asSystem_();
  var salt = newSalt_();
  appendRecord_(SHEETS.USERS, {'User ID': aId, 'Name': 'Test Admin', 'Role': 'Admin', 'Active': true, 'Password hash': hashPassword_('Admin1234', salt),
    'Salt': salt, 'Must change password': false, 'Failed attempts': 0, 'Created at': new Date(), 'Created by': 'testAuthStage12'});
  APP_USER_ = null;

  ok(/LOGIN_REQUIRED/.test(err(function () { getAppData(); })) && /LOGIN_REQUIRED/.test(err(function () { searchCustomers('987'); })) &&
    /LOGIN_REQUIRED/.test(err(function () { generateInvoice({lines: []}); })) && /LOGIN_REQUIRED/.test(err(function () { getReport('2026-11-01', '2026-11-30', 'fake-token'); })),
    'Without a valid login nothing is returned (app data, customer search, billing, reports, fake token)');

  var a = login(aId, 'Admin1234');
  ok(a.token && a.token.length > 60 && a.user.role === 'Admin', 'Admin logs in; random session token issued');
  var users = saveUser(a.token, {id: sId, name: 'Test Staff', role: 'Staff', tempPassword: 'Temp12345'});
  ok(users.some(function (u) { return u.id === sId && u.mustChange; }), 'Admin creates a staff user with a temporary password (must change at first login)');

  APP_USER_ = null;
  var s = login(sId, 'Temp12345');
  ok(/PASSWORD_CHANGE_REQUIRED/.test(err(function () { getAppData(s.token); })), 'Staff cannot use the app until the temporary password is changed');
  ok(/at least 8/.test(err(function () { changePassword(s.token, 'Temp12345', 'short1'); })) && /letters and numbers/.test(err(function () { changePassword(s.token, 'Temp12345', 'onlyletters'); })),
    'Password rules enforced (8+ characters, letters and numbers)');
  changePassword(s.token, 'Temp12345', 'Staff98765');
  var appData = getAppData(s.token);
  ok(appData.isAdmin === false && appData.user === 'Test Staff', 'After changing the password, staff get the billing screen (not admin)');
  ok(/Only an admin/.test(err(function () { getReport('2026-11-01', '2026-11-30', s.token); })) && /Only an admin/.test(err(function () { cancelDocument('TI/26-27/0001', 'staff should not', s.token); })) &&
    /Only an admin/.test(err(function () { listUsers(s.token); })), 'Staff cannot open reports, cancel bills or manage users');
  ok(searchCustomers('Test Patient', s.token).length > 0, 'Staff can search customers');

  APP_USER_ = null;
  var msgs = [];
  for (var i = 0; i < 5; i++) msgs.push(err(function () { login(sId, 'WrongPass1'); }));
  var locked = err(function () { login(sId, 'Staff98765'); });
  ok(msgs.every(function (m) { return m === 'User ID or password is wrong.'; }) && /locked/.test(locked), '5 wrong passwords lock the ID for 15 minutes (even the right password is refused meanwhile)');
  ok(err(function () { login('no-such-user', 'Whatever123'); }) === 'User ID or password is wrong.', 'Unknown IDs get the same message (does not reveal which IDs exist)');

  saveUser(a.token, {id: sId, name: 'Test Staff', role: 'Staff', active: false});
  ok(/LOGIN_REQUIRED/.test(err(function () { getAppData(s.token); })) && /wrong/.test(err(function () { login(sId, 'Staff98765'); })),
    'Deactivating a user ends their open session at once and blocks new logins');
  ok(/own admin access/.test(err(function () { saveUser(a.token, {id: aId, name: 'Test Admin', role: 'Staff'}); })), 'An admin cannot remove their own admin access');
  logout(a.token);
  ok(/LOGIN_REQUIRED/.test(err(function () { getAppData(a.token); })), 'Logout ends the session');
  var row = findUser_(sId);
  ok(row && String(row['Password hash']).indexOf('Staff98765') === -1 && String(row['Password hash']).length >= 40, 'Passwords are stored only as salted hashes');

  // Clean up the throw-away users (test environment only)
  [aId, sId].forEach(function (id) { var r = findUser_(id); if (r) usersSheet_().deleteRow(r._row); });
  Logger.log(out.join('\n'));
  return out;
}

/* ---------------- Stage 12A test ---------------- */

/**
 * Email per user, login with email, forgot password by code, and the protected Developer role.
 * TEST environment only; throw-away users; one real reset email goes to TEST_EMAIL_REDIRECT.
 */
function testStage12A() {
  if (getSetting('ENVIRONMENT') !== 'TEST') throw new Error('Tests run only in the TEST environment.');
  var out = [], ok = function (c, m) { out.push((c ? 'PASS ' : 'FAIL ') + m); };
  var err = function (fn) { try { fn(); return ''; } catch (e) { return e.message; } };
  var cache = CacheService.getScriptCache();
  var st = String(Date.now()).slice(-6), aId = 'qadmin' + st, sId = 'qstaff' + st, nId = 'qnomail' + st, dId = 'qdev' + st;
  var sMail = 'qstaff' + st + '@example.com';

  asSystem_();
  var add = function (id, role, pw, email) {
    var salt = newSalt_();
    appendRecord_(SHEETS.USERS, {'User ID': id, 'Name': 'Test ' + role, 'Role': role, 'Active': true, 'Password hash': hashPassword_(pw, salt), 'Salt': salt,
      'Must change password': false, 'Failed attempts': 0, 'Created at': new Date(), 'Created by': 'testStage12A', 'Email': email || ''});
  };
  add(aId, 'Admin', 'Admin1234', 'qadmin' + st + '@example.com');
  add(dId, 'Developer', 'Devel1234', 'qdev' + st + '@example.com');
  APP_USER_ = null;

  try {
    var a = login(aId, 'Admin1234');
    // 1. Admin manages access by email
    var list = saveUser(a.token, {id: sId, name: 'Test Staff', email: sMail.toUpperCase(), role: 'Staff', tempPassword: 'Temp12345'});
    ok(list.some(function (u) { return u.id === sId && u.email === sMail; }), 'Admin adds a staff user with an email address (stored in lower case)');
    saveUser(a.token, {id: nId, name: 'No Mail', role: 'Staff', tempPassword: 'Temp12345'});
    ok(/does not look right/.test(err(function () { saveUser(a.token, {id: 'qbad' + st, name: 'Bad', email: 'not-an-email', role: 'Staff', tempPassword: 'Temp12345'}); })),
      'A wrong-looking email address is refused');
    ok(/already has this email/.test(err(function () { saveUser(a.token, {id: 'qdup' + st, name: 'Dup', email: sMail, role: 'Staff', tempPassword: 'Temp12345'}); })),
      'Two users cannot share one email address');
    APP_USER_ = null;
    var s = login(sMail, 'Temp12345');
    ok(s.user.id === sId, 'A user can log in with their email address instead of the user ID');

    // 2. Forgot password
    var unknown = requestPasswordReset_('nobody' + st + '@example.com', {noSend: true, returnCode: true});
    var noMail = requestPasswordReset_(nId, {noSend: true, returnCode: true});
    var r1 = requestPasswordReset_(sId, {noSend: true, returnCode: true});
    ok(!unknown.code && !noMail.code && r1.code && /^\d{6}$/.test(r1.code) && unknown.message === r1.message && noMail.message === r1.message,
      'Forgot password: a 6-digit code is made only for a real active user with an email; the screen message is identical in every case');
    var raw = cache.get('RST_' + sId);
    ok(raw && raw.indexOf(r1.code) === -1, 'Only a scrambled copy of the code is stored, never the code itself');
    ok(err(function () { confirmPasswordReset(sId, r1.code, 'short1'); }).indexOf('at least 8') !== -1 &&
       err(function () { confirmPasswordReset(sId, r1.code, 'GoodPass2'); }) === '',
      'Right code + weak password is refused (code still works); right code + good password sets the new password');
    ok(/session has ended|access was changed/.test(err(function () { getAppData(s.token); })), 'Resetting the password ends any session that was open elsewhere');
    APP_USER_ = null;
    ok(login(sId, 'GoodPass2').user.id === sId && /wrong or has expired/.test(err(function () { confirmPasswordReset(sId, r1.code, 'Another12'); })),
      'The new password works and the same code cannot be used twice');

    var r2 = requestPasswordReset_(sMail, {noSend: true, returnCode: true});
    var wrong = r2.code === '000000' ? '111111' : '000000', m = [];
    for (var i = 0; i < 5; i++) m.push(err(function () { confirmPasswordReset(sId, wrong, 'Another12'); }));
    ok(/wrong or has expired/.test(m[0]) && /Too many wrong codes/.test(m[4]) && /wrong or has expired/.test(err(function () { confirmPasswordReset(sId, r2.code, 'Another12'); })),
      '5 wrong codes cancel the code (even the right code is refused afterwards)');
    var r3 = requestPasswordReset_(sId, {noSend: true, returnCode: true}), r3b = requestPasswordReset_(sId, {noSend: true, returnCode: true});
    ok(r3.code && !r3b.code, 'At most 3 codes per user per hour (the 4th request sends nothing)');

    cache.remove('RC_' + sId);
    var r4 = requestPasswordReset_(sId, {noSend: true, returnCode: true});
    var e4 = JSON.parse(cache.get('RST_' + sId)); e4.exp = Date.now() - 1000; cache.put('RST_' + sId, JSON.stringify(e4), 60);
    ok(/wrong or has expired/.test(err(function () { confirmPasswordReset(sId, r4.code, 'Another12'); })), 'An expired code (older than 15 minutes) is refused');

    APP_USER_ = null;
    for (var j = 0; j < 5; j++) err(function () { login(sId, 'WrongPass1'); });
    var r5 = requestPasswordReset_(sId, {noSend: true, returnCode: true});
    confirmPasswordReset(sId, r5.code, 'Unlock123');
    APP_USER_ = null;
    ok(login(sId, 'Unlock123').user.id === sId, 'A locked ID is unlocked by resetting the password with an emailed code');

    a = login(aId, 'Admin1234');
    saveUser(a.token, {id: sId, name: 'Test Staff', email: sMail, role: 'Staff', active: false});
    cache.remove('RC_' + sId);
    ok(!requestPasswordReset_(sId, {noSend: true, returnCode: true}).code, 'A deactivated user cannot get a reset code');

    // 3. Developer role
    ok(/Only the developer/.test(err(function () { saveUser(a.token, {id: dId, name: 'Test Developer', role: 'Admin', active: false}); })) &&
       /Only the developer/.test(err(function () { saveUser(a.token, {id: dId, name: 'Test Developer', role: 'Admin', tempPassword: 'Hack12345'}); })),
      'A clinic admin cannot switch off, demote or reset the developer account');
    ok(/script editor/.test(err(function () { saveUser(a.token, {id: 'qnewdev' + st, name: 'X', role: 'Developer', tempPassword: 'Temp12345'}); })),
      'A clinic admin cannot give anyone the Developer role');
    APP_USER_ = null;
    var d = login(dId, 'Devel1234');
    var dd = getAppData(d.token);
    ok(dd.isAdmin === true && listUsers(d.token).length > 0 && getReport('2026-11-01', '2026-11-30', d.token), 'The developer has full admin access (reports, users)');
    var lu = listUsers(a.token).filter(function (u) { return u.id === dId; })[0];
    ok(lu && lu.protect === true && lu.role === 'Developer', 'Clinic admins can see the developer account, marked as protected');
    saveUser(d.token, {id: dId, name: 'Test Developer', email: 'qdev' + st + '@example.com', role: 'Staff', active: false});
    var dRow = findUser_(dId);
    ok(dRow['Role'] === 'Developer' && isTrue_(dRow['Active']), 'Even from the app, the developer account stays Developer and active');

    // 4. One real email (goes to TEST_EMAIL_REDIRECT because TEST_MODE is on)
    a = login(aId, 'Admin1234');
    saveUser(a.token, {id: sId, name: 'Test Staff', email: sMail, role: 'Staff', active: true});
    cache.remove('RC_' + sId);
    requestPasswordReset(sId);
    ok(cache.get('RST_' + sId) !== null, 'Real reset email sent (TEST mode: to ' + getSetting('TEST_EMAIL_REDIRECT') + ', subject "[TEST] Your Yavira Billing password reset code")');
  } catch (e) {
    ok(false, 'Unexpected error: ' + e.message);
  } finally {
    asSystem_();
    [aId, sId, nId, dId].forEach(function (id) {
      var r = findUser_(id); if (r) usersSheet_().deleteRow(r._row);
      ['RST_', 'RC_', 'REVOKED_'].forEach(function (k) { cache.remove(k + id); });
    });
  }
  Logger.log(out.join('\n'));
  return out;
}

/**
 * Owner-only recovery, run from the script editor: if every admin is locked out or has forgotten the password,
 * this resets (or recreates) the 'admin' ID with a new temporary password shown in the execution log.
 */
function ownerResetAdmin() {
  asSystem_();
  var temp = 'Yavira' + Math.floor(100000 + Math.random() * 900000), salt = newSalt_();
  var fields = {'Name': 'Administrator', 'Role': 'Admin', 'Active': true, 'Password hash': hashPassword_(temp, salt), 'Salt': salt,
    'Must change password': true, 'Failed attempts': 0, 'Locked until': ''};
  var u = findUser_('admin');
  if (u) updateUser_(u._row, fields);
  else { fields['User ID'] = 'admin'; fields['Created at'] = new Date(); fields['Created by'] = currentUser_(); appendRecord_(SHEETS.USERS, fields); }
  CacheService.getScriptCache().put('REVOKED_admin', '1', SESSION_SECONDS_);
  audit_('PASSWORD_RESET', 'User', 'admin', 'Owner reset from the script editor', 'OK');
  Logger.log('Admin reset. User ID: admin   Temporary password: ' + temp + '   (must be changed at first login)');
}
