/**
 * Yavira Billing System - Invoice.gs
 * Stage 6: the GST engine. Everything that decides an amount, a number or a document
 * happens here on the server; the screen's own totals are only a preview.
 *
 * Rules applied (approved by the CA):
 *  - Exempt services -> Bill of Supply (BS series); taxable services -> Tax Invoice (TI series).
 *    A visit with both gets two separate documents.
 *  - Discount is a percentage of each line's gross amount; GST is charged on the value after discount.
 *  - CGST and SGST are worked out once per SAC and rate on each document and rounded under
 *    Section 170, CGST Act (nearest rupee; 50 paise or more up). TAX_ROUNDING = PAISE switches this off.
 *  - Every bill is collected in full at the time of billing.
 */

var TZ = 'Asia/Kolkata';

function r2_(n) { return Math.round((Number(n) + Number.EPSILON) * 100) / 100; }
/** Section 170: nearest rupee, 50 paise or more rounds up. Works on the exact amount (no rounding to paise first,
 *  which would wrongly turn e.g. 25.495 into 25.50 and then 26). 1e-6 only absorbs floating-point noise. */
function sec170_(n) { var x = Math.round(Number(n) * 1e6) / 1e6; var f = Math.floor(x); return Math.round((x - f) * 1e6) >= 500000 ? f + 1 : f; }

/** Works out every document for a bill. Used by generateInvoice and by the tests. */
function computeDocs_(payload, settings) {
  var svcMap = {};
  getActiveServices().forEach(function (s) { svcMap[s.id] = s; });
  var roundTax = String(settings.taxRounding) === 'PAISE' ? r2_ : sec170_;
  var docs = {};
  (payload.lines || []).forEach(function (raw, i) {
    var svc = svcMap[raw.serviceId];
    if (!svc) throw new Error('Line ' + (i + 1) + ': service is not active or not approved.');
    var qty = Number(raw.qty), rate = Number(raw.rate), pct = Number(raw.discPct || 0);
    var gross = r2_(qty * rate);
    var disc = r2_(gross * pct / 100);
    var line = {svc: svc, qty: qty, rate: rate, discPct: pct, gross: gross, disc: disc,
      taxable: r2_(gross - disc), gstRate: svc.taxClass === 'Taxable' ? svc.gstRate : 0};
    var d = docs[svc.docType] = docs[svc.docType] ||
      {type: svc.docType, lines: [], gross: 0, disc: 0, taxable: 0, cgst: 0, sgst: 0, groups: {}};
    d.lines.push(line);
    d.gross = r2_(d.gross + line.gross); d.disc = r2_(d.disc + line.disc); d.taxable = r2_(d.taxable + line.taxable);
    var k = svc.sac + '|' + line.gstRate;
    var g = d.groups[k] = d.groups[k] || {sac: svc.sac, rate: line.gstRate, taxable: 0, lines: []};
    g.taxable = r2_(g.taxable + line.taxable); g.lines.push(line);
  });
  return ['Bill of Supply', 'Tax Invoice'].filter(function (t) { return docs[t]; }).map(function (t) {
    var d = docs[t];
    Object.keys(d.groups).forEach(function (k) {
      var g = d.groups[k];
      g.cgst = g.rate ? roundTax(g.taxable * g.rate / 2) : 0;
      g.sgst = g.rate ? roundTax(g.taxable * g.rate / 2) : 0;
      d.cgst = r2_(d.cgst + g.cgst); d.sgst = r2_(d.sgst + g.sgst);
      // Spread the group's tax over its lines for the line register; the last line takes any remainder.
      var cLeft = g.cgst, sLeft = g.sgst;
      g.lines.forEach(function (l, i) {
        var last = i === g.lines.length - 1;
        l.cgst = last ? r2_(cLeft) : r2_(g.taxable ? g.cgst * l.taxable / g.taxable : 0);
        l.sgst = last ? r2_(sLeft) : r2_(g.taxable ? g.sgst * l.taxable / g.taxable : 0);
        cLeft = r2_(cLeft - l.cgst); sLeft = r2_(sLeft - l.sgst);
      });
    });
    var raw = r2_(d.taxable + d.cgst + d.sgst);
    d.total = settings.roundOff ? sec170_(raw) : raw;
    d.roundOff = r2_(d.total - raw);
    d.isTI = t === 'Tax Invoice';
    return d;
  });
}

/** Server-side checks. The screen checks the same things, but the server never trusts it. */
function validatePayload_(p, docs, settings) {
  var e = [];
  var c = p.customer || {};
  if (!String(c.name || '').trim()) e.push('Customer name is missing.');
  if (!/^[6-9]\d{9}$/.test(String(c.mobile || ''))) e.push('Mobile number must be 10 digits.');
  if (c.email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(c.email)) e.push('Email address looks wrong.');
  if (!(p.lines || []).length) e.push('Add at least one service.');
  (p.lines || []).forEach(function (l, i) {
    var n = 'Line ' + (i + 1) + ': ';
    if (!(Number(l.qty) >= 1) || Number(l.qty) % 1) e.push(n + 'quantity must be a whole number of 1 or more.');
    if (!(Number(l.rate) > 0)) e.push(n + 'rate must be more than zero.');
    var pct = Number(l.discPct || 0);
    if (!(pct >= 0 && pct <= 100)) e.push(n + 'discount must be between 0% and 100%.');
  });
  var ti = docs.filter(function (d) { return d.isTI; })[0];
  if (ti && ti.taxable >= settings.addressRequiredAbove && !String(c.address || '').trim())
    e.push('Address is required when the taxable value is ' + settings.addressRequiredAbove + ' or more.');
  var modes = ['Cash', 'UPI', 'Debit/Credit card', 'Bank transfer', 'Other'];
  if (modes.indexOf(p.paymentMode) === -1) e.push('Choose a valid payment mode.');
  if (e.length) throw new Error(e.join(' '));
}

function engineSettings_() {
  refreshSettings();
  return {
    tiPrefix: getSetting('TAX_INVOICE_PREFIX'), bsPrefix: getSetting('BILL_OF_SUPPLY_PREFIX'),
    padding: Number(getSetting('NUMBER_PADDING')) || 4,
    placeOfSupply: getSetting('DEFAULT_PLACE_OF_SUPPLY'),
    addressRequiredAbove: Number(getSetting('ADDRESS_REQUIRED_ABOVE')) || 50000,
    roundOff: getSetting('ROUND_OFF_TO_RUPEE') === true,
    taxRounding: String(optionalSetting_('TAX_ROUNDING', 'SECTION_170')),
    showReverseCharge: optionalSetting_('SHOW_REVERSE_CHARGE_LINE', false) === true,
    environment: getSetting('ENVIRONMENT')
  };
}

/** Next number in a series for this financial year, e.g. TI/26-27/0007. Call only while holding the lock. */
function nextDocNo_(prefix, fy, padding) {
  var sh = getDb_().getSheetByName(SHEETS.INVOICE_REGISTER);
  var last = sh.getLastRow();
  var max = 0;
  if (last > 1) {
    var re = new RegExp('^' + prefix + '/' + fy + '/(\\d+)$');
    sh.getRange(2, 1, last - 1, 1).getValues().forEach(function (r) {
      var m = String(r[0]).match(re);
      if (m) max = Math.max(max, Number(m[1]));
    });
  }
  var n = String(max + 1);
  while (n.length < padding) n = '0' + n;
  return prefix + '/' + fy + '/' + n;
}

/** Finds documents already issued for a request (duplicate-click guard). */
function findByRequestId_(requestId) {
  if (!requestId) return [];
  return readRecords_(SHEETS.INVOICE_REGISTER).filter(function (r) { return r['Request ID'] === requestId; });
}

/** Adds a new customer or updates the existing one (matched on mobile). Returns the Customer ID. */
function upsertCustomer_(c, docDate, billTotal, docCount) {
  var sh = getDb_().getSheetByName(SHEETS.CUSTOMER_MASTER);
  var map = getHeaderMap_(SHEETS.CUSTOMER_MASTER);
  var values = sh.getDataRange().getValues();
  var emailPref = c.emailDeclined ? 'Declined' : (c.email ? 'Provided' : 'Not asked');
  for (var i = 1; i < values.length; i++) {
    if (String(values[i][map['Mobile'] - 1]) === String(c.mobile)) {
      var row = values[i];
      row[map['Customer name'] - 1] = c.name;
      if (c.email) row[map['Email'] - 1] = c.email;
      if (c.emailDeclined) row[map['Email'] - 1] = '';
      row[map['Email preference'] - 1] = emailPref;
      if (c.address) row[map['Address'] - 1] = c.address;
      row[map['State'] - 1] = c.state || 'Punjab';
      row[map['Last visit date'] - 1] = docDate;
      row[map['No. of documents'] - 1] = Number(row[map['No. of documents'] - 1] || 0) + docCount;
      row[map['Total billed'] - 1] = r2_(Number(row[map['Total billed'] - 1] || 0) + billTotal);
      row[map['Mobile'] - 1] = "'" + c.mobile;
      sh.getRange(i + 1, 1, 1, row.length).setValues([row]);
      return {id: row[map['Customer ID'] - 1], isNew: false};
    }
  }
  var maxId = 0;
  for (var j = 1; j < values.length; j++) {
    var m = String(values[j][map['Customer ID'] - 1]).match(/^CUS(\d+)$/);
    if (m) maxId = Math.max(maxId, Number(m[1]));
  }
  var id = 'CUS' + ('00000' + (maxId + 1)).slice(-5);
  appendRecord_(SHEETS.CUSTOMER_MASTER, {
    'Customer ID': id, 'Customer name': c.name, 'Mobile': "'" + c.mobile, 'Email': c.email || '',
    'Email preference': emailPref, 'Address': c.address || '', 'State': c.state || 'Punjab',
    'First visit date': docDate, 'Last visit date': docDate, 'No. of documents': docCount,
    'Total billed': billTotal, 'Created at': new Date()
  });
  return {id: id, isNew: true};
}

/**
 * Called by the Generate Invoice button.
 * 1. Validates and calculates on the server.
 * 2. Under a lock: checks for a duplicate click, assigns numbers, writes every register.
 * 3. Only after the data is saved: builds the PDFs (Drive filing comes in Stage 7, email in Stage 8).
 */
function generateInvoice(payload) {
  checkAccess_(payload && payload.token);
  var settings = engineSettings_();
  var docs = computeDocs_(payload, settings);
  validatePayload_(payload, docs, settings);

  var lock = LockService.getScriptLock();
  if (!lock.tryLock(30000)) throw new Error('The system is busy issuing another bill. Please try again in a few seconds.');
  var issued;
  try {
    var existing = findByRequestId_(payload.requestId);
    if (existing.length) {
      lock.releaseLock();
      audit_('DUPLICATE_BLOCKED', 'Invoice', existing.map(function (r) { return r['Document no.']; }).join(', '),
        'Same request received again; no new number used', 'OK');
      return buildResult_(existing.map(function (r) { return r['Document no.']; }), true);
    }
    issued = saveDocs_(payload, docs, settings);
    SpreadsheetApp.flush();
  } finally {
    try { lock.releaseLock(); } catch (e) {}
  }
  return buildResult_(issued, false);
}

/** Writes all registers for a new bill. Returns the document numbers. */
function saveDocs_(p, docs, settings) {
  var now = new Date();
  var fy = financialYearLabel_(now);
  var fyFull = '20' + fy.split('-')[0] + '-' + fy.split('-')[1];
  var month = Utilities.formatDate(now, TZ, 'yyyy-MM');
  var visitId = 'V' + Utilities.formatDate(now, TZ, 'yyyyMMddHHmmss') + Math.floor(Math.random() * 90 + 10);
  var user = currentUser_();
  var c = p.customer;
  var billTotal = docs.reduce(function (a, d) { return a + d.total; }, 0);
  var cust = upsertCustomer_(c, now, r2_(billTotal), docs.length);
  var numbers = [];

  docs.forEach(function (d) {
    var docNo = nextDocNo_(d.isTI ? settings.tiPrefix : settings.bsPrefix, fy, settings.padding);
    numbers.push(docNo);
    appendRecord_(SHEETS.INVOICE_REGISTER, {
      'Document no.': "'" + docNo, 'Document type': d.type, 'Document date': now, 'Financial year': "'" + fyFull,
      'Month': "'" + month, 'Visit ID': visitId, 'Customer ID': cust.id, 'Customer name': c.name,
      'Mobile': "'" + c.mobile, 'Email': c.emailDeclined ? '' : (c.email || ''), 'Customer GSTIN': '',
      'Place of supply': settings.placeOfSupply, 'Gross amount': d.gross, 'Discount': d.disc,
      'Taxable value': d.isTI ? d.taxable : 0, 'Exempt value': d.isTI ? 0 : d.taxable,
      'CGST': d.cgst, 'SGST': d.sgst, 'IGST': 0, 'Total tax': r2_(d.cgst + d.sgst), 'Round off': d.roundOff,
      'Total payable': d.total, 'Amount received': d.total, 'Balance due': 0, 'Payment mode': p.paymentMode,
      'Payment status': 'Paid', 'Document status': 'Issued',
      'Email status': c.email && !c.emailDeclined ? 'Queued' : 'Not applicable',
      'Created by': user, 'Created at': now, 'Request ID': p.requestId
    });
    appendRecords_(SHEETS.INVOICE_LINES, d.lines.map(function (l, i) {
      return {
        'Line ID': docNo + '-' + (i + 1), 'Document no.': "'" + docNo, 'Line no.': i + 1, 'Document date': now,
        'Service ID': l.svc.id, 'Service name': l.svc.name, 'SAC': "'" + l.svc.sac, 'Tax classification': l.svc.taxClass,
        'Quantity': l.qty, 'Rate': l.rate, 'Gross amount': l.gross, 'Discount %': l.discPct / 100, 'Discount': l.disc,
        'Taxable value': l.taxable, 'GST rate': l.gstRate, 'CGST': l.cgst, 'SGST': l.sgst, 'IGST': 0,
        'Line total': r2_(l.taxable + l.cgst + l.sgst), 'Document status': 'Issued'
      };
    }));
    appendRecord_(SHEETS.PAYMENT_REGISTER, {
      'Payment ID': 'PAY-' + docNo, 'Document no.': "'" + docNo, 'Payment date': now, 'Amount': d.total,
      'Payment mode': p.paymentMode, 'Reference (UPI / card / cheque no.)': p.paymentRef || '',
      'Recorded by': user, 'Recorded at': now, 'Payment status': 'Paid'
    });
    appendRecords_(SHEETS.GST_REGISTER, Object.keys(d.groups).map(function (k) {
      var g = d.groups[k];
      return {
        'Document no.': "'" + docNo, 'Document date': now, 'Document type': d.type, 'Financial year': "'" + fyFull,
        'Month': "'" + month, 'Customer name': c.name, 'Customer GSTIN': '', 'Place of supply': settings.placeOfSupply,
        'SAC': "'" + g.sac, 'Tax classification': g.rate ? 'Taxable' : 'Exempt', 'GST rate': g.rate,
        'Taxable value': g.rate ? g.taxable : 0, 'Exempt value': g.rate ? 0 : g.taxable,
        'CGST': g.cgst, 'SGST': g.sgst, 'IGST': 0, 'Total value': r2_(g.taxable + g.cgst + g.sgst),
        'Document status': 'Issued'
      };
    }));
    audit_('INVOICE_ISSUED', d.type, docNo, {customer: cust.id, total: d.total, visit: visitId,
      env: settings.environment}, 'OK');
  });
  return numbers;
}

/* ---------------- Reading a saved document back (for PDF / print / reprint) ---------------- */

function loadDoc_(docNo) {
  var head = readRecords_(SHEETS.INVOICE_REGISTER).filter(function (r) { return r['Document no.'] === docNo; })[0];
  if (!head) throw new Error('Document not found: ' + docNo);
  var lines = readRecords_(SHEETS.INVOICE_LINES).filter(function (r) { return r['Document no.'] === docNo; });
  var gst = readRecords_(SHEETS.GST_REGISTER).filter(function (r) { return r['Document no.'] === docNo; });
  var cust = readRecords_(SHEETS.CUSTOMER_MASTER).filter(function (r) { return r['Customer ID'] === head['Customer ID']; })[0] || {};
  return {head: head, lines: lines, gst: gst, cust: cust};
}

/** Issued documents (numbers, totals, PDF as base64, printable HTML) for the screen. */
function buildResult_(numbers, duplicate) {
  var settings = engineSettings_();
  var business = getBusinessProfile_();
  var logo = getLogoDataUrl_();
  return {
    duplicate: duplicate,
    docs: numbers.map(function (no) {
      var d = loadDoc_(no);
      var html = renderDocHtml_(d, business, settings, logo);
      var pdf = HtmlService.createHtmlOutput(html).getBlob().getAs('application/pdf')
        .setName(no.replace(/\//g, '-') + '.pdf');
      return {
        docNo: no, type: d.head['Document type'], total: Number(d.head['Total payable']),
        html: html, pdfBase64: Utilities.base64Encode(pdf.getBytes()), fileName: pdf.getName()
      };
    })
  };
}

/** Reprint any issued document by its number (used by later stages and for checks). */
function getDocumentForPrint(docNo, token) {
  checkAccess_(token);
  return buildResult_([docNo], false).docs[0];
}

/* ---------------- Invoice layout (tables only: Google's PDF converter ignores flex/grid) ---------------- */

function money_(n) {
  var x = r2_(n).toFixed(2).split('.');
  var s = x[0], last3 = s.slice(-3), rest = s.slice(0, -3);
  if (rest) last3 = ',' + last3;
  return rest.replace(/\B(?=(\d{2})+(?!\d))/g, ',') + last3 + '.' + x[1];
}
function esc_(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
    return {'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c];
  });
}
function amountInWords_(n) {
  var a = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve',
    'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  var b = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
  function two(x) { return x < 20 ? a[x] : b[Math.floor(x / 10)] + (x % 10 ? '-' + a[x % 10] : ''); }
  function three(x) { return (x >= 100 ? a[Math.floor(x / 100)] + ' Hundred' + (x % 100 ? ' ' : '') : '') + (x % 100 ? two(x % 100) : ''); }
  var rupees = Math.floor(n), paise = Math.round((n - rupees) * 100), parts = [];
  var cr = Math.floor(rupees / 1e7), lk = Math.floor(rupees / 1e5) % 100, th = Math.floor(rupees / 1e3) % 100, rest = rupees % 1000;
  if (cr) parts.push(three(cr) + ' Crore'); if (lk) parts.push(two(lk) + ' Lakh');
  if (th) parts.push(two(th) + ' Thousand'); if (rest) parts.push(three(rest));
  var s = 'Rupees ' + (parts.join(' ') || 'Zero');
  if (paise) s += ' and ' + two(paise) + ' Paise';
  return s + ' Only';
}
function pctLabel_(p) { return (Math.round(Number(p) * 10000) / 100) + '%'; }

function renderDocHtml_(d, b, settings, logo) {
  var h = d.head, isTI = h['Document type'] === 'Tax Invoice';
  var date = Utilities.formatDate(new Date(h['Document date']), TZ, 'dd-MM-yyyy');
  var email = d.cust['Email preference'] === 'Declined' ? '' : (h['Email'] || '');
  var C = 'border-collapse:collapse;width:100%;';
  var th = 'background:#8a7a6d;color:#ffffff;font-weight:bold;padding:6px;font-size:10.5px;text-align:left;';
  var thr = th + 'text-align:right;';
  var td = 'padding:6px;border-bottom:1px solid #d9d4cf;font-size:10.5px;';
  var tdr = td + 'text-align:right;';
  var box = 'border:1px solid #d9d4cf;background:#f6f3f0;padding:8px 10px;vertical-align:top;width:50%;';
  function kv(k, v, bold) {
    return '<tr><td style="font-size:10.5px;padding:1px 0;color:#444;">' + k + '</td><td style="font-size:10.5px;padding:1px 0;text-align:right;' +
      (bold ? 'font-weight:bold;' : '') + '">' + v + '</td></tr>';
  }
  var rows = d.lines.map(function (l, i) {
    var disc = Number(l['Discount']) ? money_(l['Discount']) + ' (' + pctLabel_(l['Discount %']) + ')' : '0.00';
    return '<tr><td style="' + td + '">' + (i + 1) + '</td><td style="' + td + '">' + esc_(l['Service name']) + '</td><td style="' + td + '">' +
      esc_(l['SAC']) + '</td><td style="' + tdr + '">' + l['Quantity'] + '</td><td style="' + tdr + '">' + money_(l['Rate']) + '</td><td style="' +
      tdr + '">' + disc + '</td><td style="' + tdr + '">' + money_(l['Taxable value']) + '</td>' +
      (isTI ? '<td style="' + tdr + '">' + pctLabel_(l['GST rate']) + '</td>' : '') + '</tr>';
  }).join('');
  var gstRows = d.gst.map(function (g) {
    return '<tr><td style="' + td + '">' + esc_(g['SAC']) + '</td><td style="' + tdr + '">' + money_(g['Taxable value']) + '</td><td style="' + tdr + '">' +
      money_(g['CGST']) + ' (' + pctLabel_(Number(g['GST rate']) / 2) + ')</td><td style="' + tdr + '">' + money_(g['SGST']) + ' (' +
      pctLabel_(Number(g['GST rate']) / 2) + ')</td></tr>';
  }).join('');
  var thGst = 'background:#efe9e3;color:#2b2b2b;font-weight:bold;padding:5px;font-size:10px;';
  var left = isTI
    ? '<table style="' + C + '"><tr><td style="' + thGst + '">SAC</td><td style="' + thGst + 'text-align:right;">Taxable</td><td style="' + thGst +
      'text-align:right;">CGST</td><td style="' + thGst + 'text-align:right;">SGST</td></tr>' + gstRows + '</table>'
    : '<p style="font-size:10.5px;"><b>Exempt supply - no GST charged.</b><br>Health care service exempt under Sl. No. 74, Notification 12/2017-Central Tax (Rate).</p>';
  var tot = kv('Gross amount', money_(h['Gross amount'])) +
    (Number(h['Discount']) ? kv('Less: discount', '-' + money_(h['Discount'])) : '') +
    (isTI ? kv('Taxable value', money_(h['Taxable value'])) + kv('CGST', money_(h['CGST'])) + kv('SGST', money_(h['SGST'])) : '') +
    (Number(h['Round off']) ? kv('Round off', (Number(h['Round off']) > 0 ? '+' : '') + money_(h['Round off'])) : '') +
    '<tr><td style="border-top:2px solid #2b2b2b;padding-top:5px;font-weight:bold;font-size:13px;">Total Payable</td>' +
    '<td style="border-top:2px solid #2b2b2b;padding-top:5px;font-weight:bold;font-size:13px;text-align:right;">Rs. ' + money_(h['Total payable']) + '</td></tr>' +
    kv('Amount received', money_(h['Amount received']));
  var test = settings.environment === 'TEST'
    ? '<div style="border:1px dashed #d8b65a;background:#fff8e1;color:#6b5414;text-align:center;font-size:10px;padding:4px;margin-bottom:8px;">TEST DOCUMENT - not a valid tax document</div>' : '';
  var cancelled = h['Document status'] === 'Cancelled'
    ? '<div style="border:2px solid #a33;color:#a33;text-align:center;font-weight:bold;padding:4px;margin-bottom:8px;">CANCELLED' +
      (h['Cancelled at'] ? ' on ' + Utilities.formatDate(new Date(h['Cancelled at']), TZ, 'dd-MM-yyyy') : '') +
      (h['Cancellation reason'] ? '<div style="font-weight:normal;font-size:10px;">Reason: ' + esc_(h['Cancellation reason']) + '</div>' : '') +
      '</div>' : '';

  return '<html><head><meta charset="utf-8"><style>@page{size:A4;margin:14mm}body{font-family:Arial,Helvetica,sans-serif;color:#2b2b2b;margin:0;}</style></head><body>' +
    test + cancelled +
    '<table style="' + C + 'border-bottom:2px solid #8a7a6d;"><tr>' +
    '<td style="width:90px;vertical-align:middle;padding-bottom:10px;">' + (logo ? '<img src="' + logo + '" style="width:80px;height:80px;">' : '') + '</td>' +
    '<td style="vertical-align:middle;padding-bottom:10px;"><div style="font-family:Georgia,serif;font-size:18px;">' + esc_(b['Trade name']) + '</div>' +
    '<div style="font-size:9.5px;letter-spacing:2px;color:#6b6b6b;">SKIN · HAIR · LASER · AESTHETICS</div>' +
    '<div style="font-size:10.5px;">Prop.: <b>' + esc_(b['Legal name']) + '</b></div></td>' +
    '<td style="text-align:right;vertical-align:middle;font-size:10.5px;line-height:1.5;padding-bottom:10px;">' +
    '<b>' + esc_(b['Address line 1']) + ',<br>' + esc_(b['Address line 2']) + ', Punjab - ' + esc_(b['PIN code']) + '</b><br>' +
    'Ph: ' + esc_(b['Phone']) + ' · ' + esc_(b['Website']) + '<br><b>GSTIN: ' + esc_(b['GSTIN']) + '</b><br>' +
    'State: Punjab | State Code: 03<br>' + esc_(b['Practitioner line']) + '</td></tr></table>' +
    '<div style="text-align:center;font-weight:bold;letter-spacing:2px;font-size:15px;margin:12px 0 2px;">' + h['Document type'].toUpperCase() + '</div>' +
    '<div style="text-align:center;font-size:9.5px;color:#6b6b6b;margin-bottom:10px;">ORIGINAL FOR RECIPIENT</div>' +
    '<table style="' + C + '"><tr><td style="' + box + '"><div style="font-size:9.5px;letter-spacing:1.4px;color:#8a7a6d;margin-bottom:4px;">BILLED TO</div>' +
    '<table style="' + C + '">' + kv('Name', esc_(h['Customer name']), true) + kv('Mobile', esc_(h['Mobile'])) + kv('Email', esc_(email)) +
    (d.cust['Address'] ? kv('Address', esc_(d.cust['Address'])) : '') + kv('State', esc_(d.cust['State'] || 'Punjab')) + '</table></td>' +
    '<td style="width:10px;"></td>' +
    '<td style="' + box + '"><div style="font-size:9.5px;letter-spacing:1.4px;color:#8a7a6d;margin-bottom:4px;">DOCUMENT DETAILS</div>' +
    '<table style="' + C + '">' + kv('Document No.', esc_(h['Document no.']), true) + kv('Date', date) +
    kv('Place of Supply', esc_(h['Place of supply'])) +
    (settings.showReverseCharge && isTI ? kv('Reverse Charge', 'No') : '') +
    kv('Payment', esc_(h['Payment mode']) + ' · Paid') + '</table></td></tr></table>' +
    '<table style="' + C + 'margin-top:12px;"><tr><td style="' + th + '">#</td><td style="' + th + '">Description of Service</td><td style="' + th +
    '">SAC</td><td style="' + thr + '">Qty</td><td style="' + thr + '">Rate</td><td style="' + thr + '">Discount</td><td style="' + thr + '">' +
    (isTI ? 'Taxable Value' : 'Value') + '</td>' + (isTI ? '<td style="' + thr + '">GST</td>' : '') + '</tr>' + rows + '</table>' +
    '<table style="' + C + 'margin-top:12px;"><tr><td style="width:55%;vertical-align:top;padding-right:14px;">' + left +
    '<p style="font-size:10.5px;font-style:italic;">Amount in words: ' + amountInWords_(Number(h['Total payable'])) + '</p></td>' +
    '<td style="width:45%;vertical-align:top;"><table style="' + C + '">' + tot + '</table></td></tr></table>' +
    '<table style="' + C + 'margin-top:28px;"><tr><td style="font-size:10px;color:#6b6b6b;vertical-align:bottom;">Thank you for visiting Yavira.<br>' +
    esc_(b['Footer note']) + '</td><td style="text-align:center;font-size:10.5px;vertical-align:bottom;width:220px;">For ' +
    esc_(String(b['Trade name']).toUpperCase()) + '<div style="border-top:1px solid #2b2b2b;width:180px;margin:36px auto 4px;"></div>Authorised Signatory</td></tr></table>' +
    '</body></html>';
}

/* ---------------- Stage 6 tests (run from the editor; TEST environment only) ---------------- */

function testScenarios() {
  if (getSetting('ENVIRONMENT') !== 'TEST') throw new Error('Tests run only in the TEST environment.');
  asSystem_();
  var out = [];
  function run(name, payload, expect) {
    try {
      var r = generateInvoice(payload);
      var got = r.docs.map(function (d) { return d.docNo + ' = ' + d.total.toFixed(2); }).join(' | ');
      out.push((expect(r) ? 'PASS ' : 'FAIL ') + name + ': ' + got + (r.duplicate ? ' (duplicate, no new number)' : ''));
      return r;
    } catch (e) {
      out.push((expect(null, e) ? 'PASS ' : 'FAIL ') + name + ': ' + e.message);
    }
  }
  var cust = {name: 'Test Patient A', mobile: '9876500001', email: '', emailDeclined: true, address: '', state: 'Punjab'};
  var cust2 = {name: 'Test Patient B', mobile: '9876500002', email: 'test.b@example.com', emailDeclined: false, address: '', state: 'Punjab'};
  // 1. Exempt only
  run('Exempt only (medical treatment 1500)', {requestId: 'T1-' + Date.now(), customer: cust, paymentMode: 'Cash',
    lines: [{serviceId: 'SRV038', qty: 1, rate: 1500, discPct: 0}]},
    function (r) { return r && r.docs.length === 1 && r.docs[0].docNo.indexOf('BS/') === 0 && r.docs[0].total === 1500; });
  // 2. Taxable only, Section 170 round up: 4999 -> 124.975 -> 125 each
  run('Taxable, tax rounds up (Hydrafacial 2500 + LHR 2499)', {requestId: 'T2-' + Date.now(), customer: cust2, paymentMode: 'UPI',
    lines: [{serviceId: 'SRV013', qty: 1, rate: 2500, discPct: 0}, {serviceId: 'SRV025', qty: 1, rate: 2499, discPct: 0}]},
    function (r) { return r && r.docs[0].docNo.indexOf('TI/') === 0 && r.docs[0].total === 5249; });
  // 3. Taxable, tax rounds down: 1010 -> 25.25 -> 25 each -> 1060
  run('Taxable, tax rounds down (LHR 1010)', {requestId: 'T3-' + Date.now(), customer: cust, paymentMode: 'Debit/Credit card',
    lines: [{serviceId: 'SRV025', qty: 1, rate: 1010, discPct: 0}]},
    function (r) { return r && r.docs[0].total === 1060; });
  // 4. Mixed visit with 10% discount: BS 2000 less 10% = 1800; TI 3000 less 10% = 2700 + 67.5->68 x2 = 2836
  var mixedId = 'T4-' + Date.now();
  var mixed = {requestId: mixedId, customer: cust, paymentMode: 'UPI', paymentRef: 'UPI-TEST-123',
    lines: [{serviceId: 'SRV015', qty: 1, rate: 2000, discPct: 10}, {serviceId: 'SRV013', qty: 1, rate: 3000, discPct: 10}]};
  run('Mixed visit, 10% discount (repeat customer)', mixed,
    function (r) { return r && r.docs.length === 2 && r.docs[0].total === 1800 && r.docs[1].total === 2836; });
  // 5. Duplicate click: same request again must not use new numbers
  run('Duplicate click (same request)', mixed, function (r) { return r && r.duplicate === true && r.docs.length === 2; });
  // 6. Validation: bad mobile and 120% discount are rejected
  run('Validation rejects bad data', {requestId: 'T6-' + Date.now(), customer: {name: 'X', mobile: '123'}, paymentMode: 'Cash',
    lines: [{serviceId: 'SRV013', qty: 1, rate: 100, discPct: 120}]}, function (r, e) { return !r && e; });
  // 7. Inactive / unclassified service is rejected
  run('Unclassified service rejected', {requestId: 'T7-' + Date.now(), customer: cust, paymentMode: 'Cash',
    lines: [{serviceId: 'SRV029', qty: 1, rate: 100, discPct: 0}]}, function (r, e) { return !r && e; });
  Logger.log(out.join('\n'));
  return out;
}
