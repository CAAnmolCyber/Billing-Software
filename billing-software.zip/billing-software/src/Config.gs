/**
 * Yavira Billing System - Config.gs
 * Stage 3: central configuration.
 *
 * The ONLY hardcoded value in the whole project is the database spreadsheet ID,
 * and even that is stored in Script Properties by setupProject().
 * Every other value (emails, folder IDs, prefixes) is read from the
 * "Application Settings" tab, so it can be changed without touching code.
 */

// Used only once, by setupProject(). After migration, run setupProject() again
// with the clinic's spreadsheet ID.
var INITIAL_SPREADSHEET_ID = '1hu2RQReViRq98jUHvEhEPn-bejbGqkHfBYK-vDC6QhE';

var SHEETS = {
  BUSINESS_PROFILE: 'Business Profile',
  SERVICE_MASTER: 'Service Master',
  CUSTOMER_MASTER: 'Customer Master',
  INVOICE_REGISTER: 'Invoice Register',
  INVOICE_LINES: 'Invoice Line Items',
  PAYMENT_REGISTER: 'Payment Register',
  GST_REGISTER: 'GST Sales Register',
  SETTINGS: 'Application Settings',
  AUDIT_LOG: 'Audit Log',
  EMAIL_LOG: 'Email Delivery Log',
  USERS: 'Users'
};

/** Run once: stores the database ID in Script Properties. */
function setupProject() {
  PropertiesService.getScriptProperties().setProperty('SPREADSHEET_ID', INITIAL_SPREADSHEET_ID);
  Logger.log('SPREADSHEET_ID saved: ' + INITIAL_SPREADSHEET_ID);
}

/** Returns the database spreadsheet. */
function getDb_() {
  var id = PropertiesService.getScriptProperties().getProperty('SPREADSHEET_ID');
  if (!id) throw new Error('SPREADSHEET_ID not set. Run setupProject() first.');
  return SpreadsheetApp.openById(id);
}

/** Reads all settings from the Application Settings tab into an object. Cached for 5 minutes. */
function getSettings_() {
  var cache = CacheService.getScriptCache();
  var cached = cache.get('SETTINGS');
  if (cached) return JSON.parse(cached);
  var rows = getDb_().getSheetByName(SHEETS.SETTINGS).getDataRange().getValues();
  var settings = {};
  for (var i = 1; i < rows.length; i++) {
    var key = String(rows[i][0]).trim();
    if (key) settings[key] = rows[i][1];
  }
  cache.put('SETTINGS', JSON.stringify(settings), 300);
  return settings;
}

/** Returns one setting; throws if it is missing so problems surface early. */
function getSetting(key) {
  var s = getSettings_();
  if (!(key in s)) throw new Error('Missing setting in Application Settings: ' + key);
  return s[key];
}

/** Clears the settings cache after editing the Application Settings tab. */
function refreshSettings() {
  CacheService.getScriptCache().remove('SETTINGS');
}

/** Reads the Business Profile tab into an object. */
function getBusinessProfile_() {
  var rows = getDb_().getSheetByName(SHEETS.BUSINESS_PROFILE).getDataRange().getValues();
  var p = {};
  for (var i = 1; i < rows.length; i++) p[String(rows[i][0]).trim()] = rows[i][1];
  return p;
}

/**
 * Stage 3 check: confirms the script can reach the spreadsheet, every tab,
 * every Drive folder and the logo. Sends NO email.
 */
function testConnection() {
  var report = [];
  var db = getDb_();
  report.push('Spreadsheet: ' + db.getName());

  Object.keys(SHEETS).forEach(function (k) {
    var ok = db.getSheetByName(SHEETS[k]) !== null;
    report.push((ok ? 'OK   ' : 'MISSING ') + 'tab: ' + SHEETS[k]);
  });

  refreshSettings();
  ['DRIVE_ROOT_FOLDER_ID', 'INVOICE_FOLDER_ID', 'REPORTS_FOLDER_ID', 'BACKUP_FOLDER_ID'].forEach(function (k) {
    try {
      report.push('OK   folder ' + k + ': ' + DriveApp.getFolderById(String(getSetting(k))).getName());
    } catch (e) {
      report.push('FAIL folder ' + k + ': ' + e.message);
    }
  });
  try {
    report.push('OK   logo: ' + DriveApp.getFileById(String(getSetting('LOGO_FILE_ID'))).getName());
  } catch (e) {
    report.push('FAIL logo: ' + e.message);
  }

  var p = getBusinessProfile_();
  report.push('Business: ' + p['Trade name'] + ' | GSTIN ' + p['GSTIN']);
  report.push('Environment: ' + getSetting('ENVIRONMENT') + ' | TEST_MODE ' + getSetting('TEST_MODE'));
  report.push('Executing account: ' + Session.getEffectiveUser().getEmail());

  Logger.log(report.join('\n'));
  return report;
}
