/**
 * Yavira Billing System - WebApp.gs
 * Stage 5: serves the billing screen and the data it needs.
 * Invoice generation (numbering, saving, PDF) is added in Stage 6.
 */

/** Entry point when staff open the app link. */
function doGet() {                      // login happens inside the page (Auth.gs)
  return HtmlService.createTemplateFromFile('Index').evaluate()
    .setTitle('Yavira Billing')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.DEFAULT);
}

/** Inserts another HTML file into the page (used for the Customers and Reports tabs). */
function include_(name) { return HtmlService.createHtmlOutputFromFile(name).getContent(); }

/* Access control: see Auth.gs (app login with user ID and password; checkAccess_ / checkAdmin_). */

/** Everything the screen needs on load, in one call. */
function getAppData(token) {
  var me = checkAccess_(token);
  refreshSettings();
  var p = getBusinessProfile_();
  return {
    business: {
      tradeName: p['Trade name'], legalName: p['Legal name'], gstin: p['GSTIN'],
      address1: p['Address line 1'], address2: p['Address line 2'], pin: String(p['PIN code']),
      stateLine: p['State / State code'], phone: String(p['Phone']), website: p['Website'],
      practitioner: p['Practitioner line'], footer: p['Footer note']
    },
    settings: {
      environment: getSetting('ENVIRONMENT'),
      testMode: getSetting('TEST_MODE') === true,
      tiPrefix: getSetting('TAX_INVOICE_PREFIX'),
      bsPrefix: getSetting('BILL_OF_SUPPLY_PREFIX'),
      placeOfSupply: getSetting('DEFAULT_PLACE_OF_SUPPLY'),
      addressRequiredAbove: Number(getSetting('ADDRESS_REQUIRED_ABOVE')) || 50000,
      roundOff: getSetting('ROUND_OFF_TO_RUPEE') === true,
      showReverseCharge: optionalSetting_('SHOW_REVERSE_CHARGE_LINE', false) === true,
      taxRounding: String(optionalSetting_('TAX_ROUNDING', 'SECTION_170'))
    },
    services: getActiveServices(),
    logo: getLogoDataUrl_(),
    fy: financialYearLabel_(new Date()),
    today: Utilities.formatDate(new Date(), 'Asia/Kolkata', 'dd-MM-yyyy'),
    user: me.name, userId: me.id, role: me.role,
    isAdmin: isAdmin_(),
    presets: reportPresets_()
  };
}

/** Reads a setting that may not exist yet, returning a default instead of failing. */
function optionalSetting_(key, fallback) {
  var s = getSettings_();
  return key in s ? s[key] : fallback;
}

/** Logo as a data URL so the preview and PDF never depend on a public link. Cached for 6 hours. */
function getLogoDataUrl_() {
  var cache = CacheService.getScriptCache();
  var hit = cache.get('LOGO');
  if (hit) return hit;
  try {
    var blob = DriveApp.getFileById(String(getSetting('LOGO_FILE_ID'))).getBlob();
    var url = 'data:' + blob.getContentType() + ';base64,' + Utilities.base64Encode(blob.getBytes());
    if (url.length < 95000) cache.put('LOGO', url, 21600);
    return url;
  } catch (e) {
    return '';
  }
}

/** '26-27' for any date between 1 Apr 2026 and 31 Mar 2027. */
function financialYearLabel_(d) {
  var tz = 'Asia/Kolkata';
  var y = Number(Utilities.formatDate(d, tz, 'yyyy'));
  var m = Number(Utilities.formatDate(d, tz, 'M'));
  var start = m >= Number(getSetting('FY_START_MONTH') || 4) ? y : y - 1;
  return String(start).slice(2) + '-' + String(start + 1).slice(2);
}

/** Customer search by mobile number or name (top 10 matches). */
function searchCustomers(query, token) {
  checkAccess_(token);
  var q = String(query || '').trim().toLowerCase();
  if (q.length < 3) return [];
  var digits = q.replace(/\D/g, '');
  return readRecords_(SHEETS.CUSTOMER_MASTER).filter(function (c) {
    var mobile = String(c['Mobile']);
    var name = String(c['Customer name']).toLowerCase();
    return (digits.length >= 3 && mobile.indexOf(digits) !== -1) || name.indexOf(q) !== -1;
  }).slice(0, 10).map(function (c) {
    return {
      id: c['Customer ID'], name: c['Customer name'], mobile: String(c['Mobile']), email: c['Email'],
      emailPref: c['Email preference'], address: c['Address'], state: c['State'],
      visits: c['No. of documents'], lastVisit: c['Last visit date'] ?
        Utilities.formatDate(new Date(c['Last visit date']), 'Asia/Kolkata', 'dd-MM-yyyy') : ''
    };
  });
}

/** Stage 5 check, run from the editor: confirms the screen's data loads. */
function testAppData() {
  asSystem_();
  var d = getAppData();
  var out = [
    'Business: ' + d.business.tradeName + ' | ' + d.business.gstin,
    'Services in dropdown: ' + d.services.length,
    'Logo loaded: ' + (d.logo ? 'yes (' + d.logo.length + ' chars)' : 'NO'),
    'Financial year: ' + d.fy + ' | Today: ' + d.today,
    'Test mode: ' + d.settings.testMode + ' | Round off: ' + d.settings.roundOff,
    'Customer search (empty DB) returns: ' + searchCustomers('987').length
  ];
  Logger.log(out.join('\n'));
  return out;
}
