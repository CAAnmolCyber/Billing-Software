/**
 * Yavira Billing System - Tests.gs
 * Stage 11: complete application test and reconciliation (TEST environment only).
 *
 * runStage11Tests() issues a small set of dummy bills covering every scenario in the brief, runs the background
 * jobs, checks each result, then reconciles EVERY document in the database across all registers and reports.
 * Emails go only to TEST_EMAIL_REDIRECT. Dummy customers use mobiles 98765000xx and example.com emails.
 */

function runStage11Tests() {
  if (getSetting('ENVIRONMENT') !== 'TEST') throw new Error('Tests run only in the TEST environment.');
  var props = PropertiesService.getScriptProperties();
  props.setProperty('PAUSE_BACKGROUND_UNTIL', String(Date.now() + 8 * 60000));   // keep the 5-minute job out of the way
  try { return runStage11Tests_(); } finally { props.deleteProperty('PAUSE_BACKGROUND_UNTIL'); }
}

function runStage11Tests_() {
  refreshSettings();
  asSystem_();
  if (!isTrue_(getSetting('TEST_MODE'))) throw new Error('Stop: TEST_MODE must be TRUE to run this test.');
  var out = [], fails = 0;
  var ok = function (id, c, msg) { if (!c) fails++; out.push((c ? 'PASS ' : 'FAIL ') + id + '  ' + msg); return c; };
  var eq = function (a, b) { return Math.abs(Number(a) - Number(b)) < 0.005; };
  var reg = function () { return readRecords_(SHEETS.INVOICE_REGISTER); };
  var doc = function (no) { return reg().filter(function (r) { return r['Document no.'] === no; })[0]; };
  var rows = function () { return getDb_().getSheetByName(SHEETS.INVOICE_REGISTER).getLastRow(); };
  var run = Date.now().toString(36);
  var bill = function (cust, lines, mode, extra) {
    var p = {requestId: 'S11-' + run + '-' + Math.random().toString(36).slice(2, 8), paymentMode: mode || 'Cash', paymentRef: '',
      customer: cust, lines: lines.map(function (l) { return {serviceId: l[0], qty: l[1], rate: l[2], discPct: l[3] || 0}; })};
    Object.keys(extra || {}).forEach(function (k) { p[k] = extra[k]; });
    var res = generateInvoice(p);
    res.payload = p;
    return res;
  };
  var C = function (n, mobile, email, state, address) {
    return {id: '', name: 'Test Patient ' + n, mobile: mobile, email: email || '', emailDeclined: !email, address: address || '', state: state || 'Punjab'};
  };

  /* ---------- 1. Normal paid invoice (taxable, customer with email) ---------- */
  var s1 = bill(C('D', '9876500004', 'test.d@example.com'), [['SRV013', 1, 3000]], 'UPI');
  var d1 = doc(s1.docs[0].docNo);
  ok('S1', s1.docs.length === 1 && /^TI\/\d\d-\d\d\/\d{4}$/.test(d1['Document no.']) && d1['Document type'] === 'Tax Invoice' &&
    eq(d1['Taxable value'], 3000) && eq(d1['CGST'], 75) && eq(d1['SGST'], 75) && eq(d1['Total payable'], 3150) &&
    d1['Payment status'] === 'Paid' && d1['Email status'] === 'Queued',
    'Normal paid invoice ' + d1['Document no.'] + ': Rs 3,000 + CGST 75 + SGST 75 = Rs 3,150, Paid, email queued');

  /* ---------- 2 & 3. Partial / unpaid: the screen cannot send them; the server ignores any such field ---------- */
  var s2 = bill(C('H', '9876500008'), [['SRV014', 1, 2000]], 'Cash', {amountReceived: 500, paymentStatus: 'Unpaid', balanceDue: 1600});
  var d2 = doc(s2.docs[0].docNo);
  ok('S2/S3', d2['Payment status'] === 'Paid' && eq(d2['Amount received'], 2100) && eq(d2['Balance due'], 0),
    'Partial / unpaid bills cannot be created: a request claiming Rs 500 paid / "Unpaid" was saved as Paid in full (Rs 2,100 received, balance 0)');

  /* ---------- 4 & 8. Discounted invoice, customer without email ---------- */
  var s4 = bill(C('E', '9876500005'), [['SRV025', 2, 2500, 10], ['SRV016', 1, 1800, 12.5]], 'Debit/Credit card');
  var d4 = doc(s4.docs[0].docNo);
  ok('S4', eq(d4['Gross amount'], 6800) && eq(d4['Discount'], 725) && eq(d4['Taxable value'], 6075) && eq(d4['CGST'], 152) && eq(d4['SGST'], 152) && eq(d4['Total payable'], 6379),
    'Discounted invoice ' + d4['Document no.'] + ': gross 6,800 - discount 725 (10% and 12.5%) = 6,075; CGST/SGST 151.875 -> 152 each (Sec. 170); total 6,379');
  ok('S8', d4['Email'] === '' && d4['Email status'] === 'Not applicable', 'Customer without email: email left blank, Email status "Not applicable", nothing queued');

  /* ---------- 5 & 10. Different GST classifications in one visit; repeat customer ---------- */
  var before5 = readRecords_(SHEETS.CUSTOMER_MASTER).filter(function (c) { return String(c['Mobile']) === '9876500004'; })[0];
  var s5 = bill(C('D', '9876500004', 'test.d@example.com'), [['SRV038', 1, 800], ['SRV022', 1, 12000]], 'UPI');
  var bs5 = s5.docs.filter(function (x) { return x.type === 'Bill of Supply'; })[0], ti5 = s5.docs.filter(function (x) { return x.type === 'Tax Invoice'; })[0];
  var b5 = bs5 && doc(bs5.docNo), t5 = ti5 && doc(ti5.docNo);
  ok('S5', s5.docs.length === 2 && b5 && t5 && /^BS\//.test(b5['Document no.']) && eq(b5['Exempt value'], 800) && eq(b5['CGST'], 0) && eq(b5['Total payable'], 800) &&
    /^TI\//.test(t5['Document no.']) && eq(t5['Taxable value'], 12000) && eq(t5['CGST'], 300) && eq(t5['Total payable'], 12600) && b5['Visit ID'] === t5['Visit ID'],
    'Exempt + taxable in one visit: separate ' + (b5 ? b5['Document no.'] : '?') + ' (exempt Rs 800, no GST) and ' + (t5 ? t5['Document no.'] : '?') + ' (Rs 12,000 + 5% GST = Rs 12,600)');
  var after5 = readRecords_(SHEETS.CUSTOMER_MASTER).filter(function (c) { return String(c['Mobile']) === '9876500004'; });
  ok('S10', after5.length === 1 && after5[0]['Customer ID'] === before5['Customer ID'] && d1['Customer ID'] === t5['Customer ID'] &&
    Number(after5[0]['No. of documents']) === Number(before5['No. of documents']) + 2 && eq(after5[0]['Total billed'], r2_(Number(before5['Total billed']) + 13400)),
    'Repeat customer: same Customer ID ' + before5['Customer ID'] + ' reused (matched on mobile); documents +2, total billed +13,400');

  /* ---------- 6 & 7. Intra-state and inter-state customer ---------- */
  ok('S6', d2['Place of supply'] === 'Punjab (03)' && eq(d2['CGST'], 50) && eq(d2['SGST'], 50) && eq(d2['IGST'], 0), 'Intra-state (Punjab customer): CGST 50 + SGST 50, IGST 0');
  var s7 = bill(C('F', '9876500006', '', 'Haryana', '12 Test Road, Panchkula'), [['SRV021', 1, 6000]], 'Bank transfer');
  var d7 = doc(s7.docs[0].docNo);
  ok('S7', d7['Place of supply'] === 'Punjab (03)' && eq(d7['CGST'], 150) && eq(d7['SGST'], 150) && eq(d7['IGST'], 0),
    'Customer from Haryana: service performed at the clinic, so place of supply stays Punjab (IGST Act s.12(4)) -> CGST + SGST, no IGST');

  /* ---------- 9. Cancelled invoice ---------- */
  var s9 = bill(C('G', '9876500007'), [['SRV001', 1, 500]], 'Cash');
  var no9 = s9.docs[0].docNo;
  cancelDocument(no9, 'Stage 11 test - billed to the wrong patient');
  var d9 = doc(no9);
  var lines9 = readRecords_(SHEETS.INVOICE_LINES).filter(function (r) { return r['Document no.'] === no9; });
  ok('S9', d9['Document status'] === 'Cancelled' && d9['Cancellation reason'] && lines9.length && lines9.every(function (l) { return l['Document status'] === 'Cancelled'; }),
    'Cancelled ' + no9 + ': kept with reason; lines, GST and payment rows marked Cancelled; number not reused');

  /* ---------- 11. Duplicate clicks ---------- */
  var n0 = rows();
  var dup = generateInvoice(s1.payload), dup2 = generateInvoice(s5.payload);
  ok('S11', dup.duplicate === true && dup2.duplicate === true && dup.docs[0].docNo === s1.docs[0].docNo &&
    dup2.docs.map(function (x) { return x.docNo; }).join() === s5.docs.map(function (x) { return x.docNo; }).join() && rows() === n0,
    'Duplicate clicks: the same request sent again returns the same numbers (' + dup.docs[0].docNo + ', ' + dup2.docs.map(function (x) { return x.docNo; }).join(' + ') + '); no new rows');

  /* ---------- 12. Drive failure ---------- */
  var newNos = [].concat(s1.docs, s2.docs, s4.docs, s5.docs, s7.docs, s9.docs).map(function (x) { return x.docNo; });
  var pending = function () { return reg().filter(function (r) { return newNos.indexOf(r['Document no.']) !== -1 && !r['PDF file ID']; }).length; };
  var p0 = pending();
  var fail = processPdfQueue({rootOverride: 'INVALID_FOLDER_ID_FOR_TEST'});
  var p1 = pending();
  var okRun = processPdfQueue();
  var p2 = pending();
  ok('S12', p0 > 0 && fail.filed.length === 0 && p1 === p0 && p2 === 0 && okRun.failed.length === 0,
    'Drive failure: ' + p0 + ' new documents waiting, a run against an unreachable folder filed 0 and lost nothing; the next run filed all (' + okRun.filed.length + ')');

  /* ---------- 13. Gmail failure ---------- */
  var mailFail = processEmailQueue({forceError: true});
  var stillQ = reg().filter(function (r) { return newNos.indexOf(r['Document no.']) !== -1 && r['Email status'] === 'Queued'; }).length;
  var mailOk = processEmailQueue();
  var sentNow = reg().filter(function (r) { return newNos.indexOf(r['Document no.']) !== -1 && r['Email status'] === 'Redirected (test)'; }).length;
  ok('S13', mailFail.sent.length === 0 && mailFail.failed.length >= 2 && stillQ === 3 && mailOk.sent.length >= 2 && sentNow === 3 &&
    mailOk.sent.every(function (x) { return /c\.anmol1997@gmail\.com$/.test(x) || x.indexOf(String(getSetting('TEST_EMAIL_REDIRECT'))) !== -1; }),
    'Gmail failure: nothing sent, 3 bills stayed queued; next run sent 2 emails (1 per visit, both PDFs together for the mixed visit), only to the test inbox');

  /* ---------- 14. Weekly and monthly reports ---------- */
  var today = istDate_(new Date()), wk = lastCompleteWeek_(addDays_(today, 7 - isoWeekday_(today) + 1)), p = reportPresets_();
  var wRep = buildReport_(wk.from, wk.to), mRep = buildReport_(p.month[0], p.month[1]);
  var wSheets = reportSheets_('Weekly', wRep), mSheets = reportSheets_('Monthly', mRep);
  var mParts = xlsxParts_(mSheets);
  ok('S14', wSheets.length === 4 && mSheets.length === 8 && mParts.length === 5 + 8 && mParts[5].xml.indexOf('<v>' + mRep.summary.invoiceValue + '</v>') !== -1 &&
    eq(wRep.summary.invoiceValue, wRep.daily.reduce(function (a, x) { return a + x.total; }, 0)),
    'Reports: this week (' + wk.from + ' to ' + wk.to + ') invoice value Rs ' + wRep.summary.invoiceValue + '; this month Rs ' + mRep.summary.invoiceValue +
    ' with Rs ' + mRep.summary.cancelledValue + ' cancelled shown separately; Excel workbooks have 4 and 8 sheets');

  /* ---------- Extra: validation, rounding, numbering, access ---------- */
  var n1 = rows(), rejected = 0, msgs = [];
  [['bad mobile', C('X', '12345'), [['SRV013', 1, 100]], 'Cash'],
    ['bad email', {id: '', name: 'Test X', mobile: '9876500099', email: 'abc@', emailDeclined: false, state: 'Punjab'}, [['SRV013', 1, 100]], 'Cash'],
    ['quantity 0', C('X', '9876500099'), [['SRV013', 0, 100]], 'Cash'],
    ['rate 0', C('X', '9876500099'), [['SRV013', 1, 0]], 'Cash'],
    ['discount 120%', C('X', '9876500099'), [['SRV013', 1, 100, 120]], 'Cash'],
    ['unknown payment mode', C('X', '9876500099'), [['SRV013', 1, 100]], 'Crypto'],
    ['inactive service', C('X', '9876500099'), [['SRV028', 1, 100]], 'Cash'],
    ['no address at Rs 60,000', C('X', '9876500099'), [['SRV022', 1, 60000]], 'Cash'],
    ['no services', C('X', '9876500099'), [], 'Cash']].forEach(function (t) {
    try { bill(t[1], t[2], t[3]); msgs.push(t[0] + ': NOT rejected'); } catch (e) { rejected++; }
  });
  ok('X1', rejected === 9 && rows() === n1, 'Validation: all 9 bad bills rejected before saving (bad mobile, bad email, qty 0, rate 0, discount 120%, bad payment mode, inactive service, no address at Rs 60,000+, no services); no rows added ' + msgs.join('; '));

  var es = engineSettings_();
  var rt = function (rate) { return computeDocs_({lines: [{serviceId: 'SRV013', qty: 1, rate: rate, discPct: 0}]}, es)[0]; };
  var a = rt(1020), b = rt(1019.8), c = rt(1019.6);
  ok('X2', a.cgst === 26 && b.cgst === 25 && c.cgst === 25 && a.total === 1072 && b.total === 1070,
    'Section 170 rounding on the exact tax: 25.50 -> 26, 25.495 -> 25 (was wrongly 26 before this stage\'s fix), 25.49 -> 25; totals 1,072 and 1,070');

  var gaps = [];
  var series = {};
  reg().forEach(function (r) { var m = String(r['Document no.']).match(/^(TI|BS)\/(\d\d-\d\d)\/(\d+)$/); if (m) (series[m[1] + '/' + m[2]] = series[m[1] + '/' + m[2]] || []).push(Number(m[3])); });
  Object.keys(series).forEach(function (k) {
    var ns = series[k].sort(function (x, y) { return x - y; });
    ns.forEach(function (n, i) { if (n !== i + 1) gaps.push(k + ' expected ' + (i + 1) + ' found ' + n); });
  });
  ok('X3', gaps.length === 0 && nextDocNo_('TI', '27-28', 4) === 'TI/27-28/0001' && nextDocNo_('BS', '27-28', 4) === 'BS/27-28/0001',
    'Numbering: ' + Object.keys(series).map(function (k) { return k + ' 1-' + series[k].length; }).join(', ') + ' with no gaps or repeats; new financial year 27-28 starts again at 0001 ' + gaps.join('; '));

  var noLogin = ''; try { getReport(p.fy[0], p.fy[1], 'not-a-real-session-token'); } catch (e) { noLogin = e.message; }
  ok('X4', /LOGIN_REQUIRED/.test(noLogin), 'Access: a request without a valid login session is refused (full login tests: testAuthStage12)');

  /* ---------- Reconciliation of EVERY document ---------- */
  var all = reg(), lines = readRecords_(SHEETS.INVOICE_LINES), gstRows = readRecords_(SHEETS.GST_REGISTER), pays = readRecords_(SHEETS.PAYMENT_REGISTER);
  var by = function (list) { var o = {}; list.forEach(function (x) { (o[x['Document no.']] = o[x['Document no.']] || []).push(x); }); return o; };
  var L = by(lines), G = by(gstRows), P = by(pays), bad = [];
  var sum = function (arr, k) { return r2_((arr || []).reduce(function (s, x) { return s + (Number(x[k]) || 0); }, 0)); };
  all.forEach(function (d) {
    var no = d['Document no.'], l = L[no] || [], g = G[no] || [], py = P[no] || [], why = [];
    var value = r2_(Number(d['Taxable value']) + Number(d['Exempt value']));
    if (!eq(d['Total payable'], r2_(value + Number(d['CGST']) + Number(d['SGST']) + Number(d['IGST']) + Number(d['Round off'])))) why.push('total != value + tax + round off');
    if (Math.abs(Number(d['Round off'])) > 0.5) why.push('round off > 0.50');
    if (!eq(sum(l, 'Taxable value'), value) || !eq(sum(l, 'CGST'), d['CGST']) || !eq(sum(l, 'SGST'), d['SGST'])) why.push('lines do not add up');
    if (!eq(r2_(sum(l, 'Line total') + Number(d['Round off'])), d['Total payable'])) why.push('line totals + round off != total');
    if (!eq(r2_(sum(g, 'Taxable value') + sum(g, 'Exempt value')), value) || !eq(sum(g, 'CGST'), d['CGST']) || !eq(sum(g, 'SGST'), d['SGST'])) why.push('GST register does not match');
    if (py.length !== 1 || !eq(py[0]['Amount'], d['Total payable'])) why.push('payment register does not match');
    if (!eq(d['Amount received'], d['Total payable']) || !eq(d['Balance due'], 0)) why.push('not collected in full');
    if (Number(d['IGST'])) why.push('IGST charged');
    if (d['Document type'] === 'Tax Invoice' ? (!/^TI\//.test(no) || Number(d['Exempt value'])) : (!/^BS\//.test(no) || Number(d['Taxable value']) || Number(d['CGST']))) why.push('type / series mismatch');
    var st = d['Document status'];
    if (l.concat(g).some(function (x) { return x['Document status'] !== st; }) || (st === 'Cancelled') !== (py[0] && py[0]['Payment status'] === 'Cancelled')) why.push('status differs across registers');
    if (!d['PDF file ID']) why.push('no PDF in Drive');
    if (why.length) bad.push(no + ': ' + why.join(', '));
  });
  ok('R1', bad.length === 0, 'Every document (' + all.length + ') reconciles: totals = value + tax + round off, Line Items, GST Sales Register and Payment Register all agree, statuses match, PDF filed ' + bad.join(' | '));

  var custBad = [];
  readRecords_(SHEETS.CUSTOMER_MASTER).forEach(function (c) {
    var mine = all.filter(function (d) { return d['Customer ID'] === c['Customer ID'] && d['Document status'] === 'Issued'; });
    if (Number(c['No. of documents']) !== mine.length || !eq(c['Total billed'], sum(mine, 'Total payable'))) custBad.push(c['Customer ID'] + ' (' + c['No. of documents'] + '/' + c['Total billed'] + ' vs ' + mine.length + '/' + sum(mine, 'Total payable') + ')');
  });
  ok('R2', custBad.length === 0, 'Customer Master: every customer\'s document count and total billed match their issued bills ' + custBad.join('; '));

  var fyR = buildReport_(p.fy[0], p.fy[1]), fs = fyR.summary, issued = all.filter(function (d) { return d['Document status'] === 'Issued'; });
  var cancelledAll = all.filter(function (d) { return d['Document status'] === 'Cancelled'; });
  ok('R3', eq(fs.invoiceValue, sum(issued, 'Total payable')) && eq(fs.taxable, sum(issued, 'Taxable value')) && eq(fs.exempt, sum(issued, 'Exempt value')) &&
    eq(fs.cgst, sum(issued, 'CGST')) && eq(fs.sgst, sum(issued, 'SGST')) && eq(fs.cgst, fyR.gst.reduce(function (s, x) { return s + x.cgst; }, 0)) &&
    eq(fs.collected, fyR.payments.reduce(function (s, x) { return s + x.amount; }, 0)) && eq(fs.cancelledValue, sum(cancelledAll, 'Total payable')) && fs.documents === issued.length,
    'FY report = registers: ' + issued.length + ' issued, invoice value Rs ' + fs.invoiceValue + ' (taxable ' + fs.taxable + ', exempt ' + fs.exempt + ', CGST ' + fs.cgst +
    ', SGST ' + fs.sgst + '), collected Rs ' + fs.collected + ', cancelled ' + cancelledAll.length + ' worth Rs ' + fs.cancelledValue);

  out.unshift('STAGE 11 RESULT: ' + (out.length - fails) + ' of ' + out.length + ' passed' + (fails ? ' - ' + fails + ' FAILED' : ''));
  audit_('STAGE11_TEST', 'System', 'runStage11Tests', out[0], fails ? 'FAIL' : 'OK');
  Logger.log(out.join('\n'));
  return out;
}
