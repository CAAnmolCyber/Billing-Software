/**
 * Yavira Billing System - Services.gs
 * Stage 12B: the Services tab, for the Developer login only.
 *
 *  - Add a service, change its name, category, SAC, tax classification, GST rate or default price,
 *    switch it on or off, or delete it if it has never been billed.
 *  - Bills already issued never change: every line item keeps its own copy of the service, SAC and GST.
 *  - Exempt services go on a Bill of Supply (GST 0); taxable services go on a Tax Invoice
 *    (CGST and SGST are each half the GST rate, IGST the full rate).
 *  - Staff see changes the next time they open or refresh the billing page.
 */

var GST_RATES_ = [0.05, 0.18, 0.40];   // GST rates in force for services; the developer can add others if the law changes

function checkDeveloper_(token) {
  var u = checkAccess_(token);
  if (u.role !== 'Developer' && !u.system) throw new Error('Only the developer can change services.');
  return u;
}

function serviceRows_() {
  var sh = getDb_().getSheetByName(SHEETS.SERVICE_MASTER), last = sh.getLastRow();
  if (last < 2) return [];
  var map = getHeaderMap_(SHEETS.SERVICE_MASTER);
  return sh.getRange(2, 1, last - 1, sh.getLastColumn()).getValues().map(function (r, i) {
    var o = {_row: i + 2};
    Object.keys(map).forEach(function (h) { o[h] = r[map[h] - 1]; });
    return o;
  }).filter(function (o) { return String(o['Service ID']).trim(); });
}

/** Number of bill lines that used each service (a used service can be switched off, never deleted). */
function serviceUsage_() {
  var used = {};
  readRecords_(SHEETS.INVOICE_LINES).forEach(function (l) { var id = String(l['Service ID']); used[id] = (used[id] || 0) + 1; });
  return used;
}

function listServicesAdmin(token) {
  checkDeveloper_(token);
  var used = serviceUsage_();
  return {
    rates: GST_RATES_,
    services: serviceRows_().map(function (s) {
      return {
        id: String(s['Service ID']), category: String(s['Category']), name: String(s['Service name']),
        applicableTo: String(s['Applicable to']), sac: String(s['SAC']), taxClass: String(s['Tax classification']),
        gstRate: Number(s['GST rate']) || 0, price: Number(s['Default price']) || 0, status: String(s['Status']),
        approved: String(s['CA approved']), notes: String(s['Source / notes']), used: used[String(s['Service ID'])] || 0
      };
    })
  };
}

/**
 * Adds (no id) or updates (id) a service. s = {id, category, name, applicableTo, taxClass: 'Exempt'|'Taxable',
 * gstRate (e.g. 0.05), sac, price, status: 'Active'|'Inactive'}.
 */
function saveService(token, s) {
  var dev = checkDeveloper_(token);
  var lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    var name = String(s.name || '').trim(), category = String(s.category || '').trim();
    var taxClass = s.taxClass === 'Taxable' ? 'Taxable' : s.taxClass === 'Exempt' ? 'Exempt' : '';
    var sac = String(s.sac || '').replace(/\D/g, ''), status = s.status === 'Inactive' ? 'Inactive' : 'Active';
    var rate = taxClass === 'Taxable' ? Number(s.gstRate) : 0, price = s.price === '' || s.price == null ? '' : Number(s.price);
    if (!name) throw new Error('Enter the service name.');
    if (!category) throw new Error('Enter a category (for example Skin, Hair, Laser, Medispa, Aesthetics).');
    if (!taxClass) throw new Error('Choose Exempt (medical) or Taxable (cosmetic).');
    if (!/^\d{6}$/.test(sac)) throw new Error('SAC must be 6 digits (999312 for medical, 999722 for cosmetic services).');
    if (taxClass === 'Taxable' && !(rate > 0 && rate <= 0.4)) throw new Error('Choose the GST rate for a taxable service.');
    if (price !== '' && !(price >= 0 && price < 10000000)) throw new Error('Default price must be a number (or leave it empty).');

    var rows = serviceRows_(), id = String(s.id || '').trim();
    var clash = rows.filter(function (r) { return String(r['Service name']).trim().toLowerCase() === name.toLowerCase() && String(r['Service ID']) !== id; })[0];
    if (clash) throw new Error('Another service (' + clash['Service ID'] + ') already has this name.');
    var stamp = Utilities.formatDate(new Date(), TZ, 'dd/MM/yyyy');
    var fields = {
      'Category': category, 'Service name': name, 'Applicable to': String(s.applicableTo || '').trim(), 'SAC': sac,
      'Tax classification': taxClass, 'Document type': taxClass === 'Taxable' ? 'Tax Invoice' : 'Bill of Supply',
      'GST rate': rate, 'CGST rate': rate / 2, 'SGST rate': rate / 2, 'IGST rate': rate, 'Status': status, 'Default price': price
    };
    var sh = getDb_().getSheetByName(SHEETS.SERVICE_MASTER), map = getHeaderMap_(SHEETS.SERVICE_MASTER), row, before = null;
    if (id) {
      var ex = rows.filter(function (r) { return String(r['Service ID']) === id; })[0];
      if (!ex) throw new Error('Service ' + id + ' not found.');
      before = {name: ex['Service name'], taxClass: ex['Tax classification'], gstRate: ex['GST rate'], sac: ex['SAC'], status: ex['Status'], price: ex['Default price']};
      fields['Source / notes'] = String(ex['Source / notes'] || '').replace(/\s*\|\s*Edited by developer.*$/, '') + ' | Edited by developer ' + stamp;
      if (String(ex['CA approved']) === 'PENDING' && status === 'Active') fields['CA approved'] = 'DEVELOPER';
      row = ex._row;
      Object.keys(fields).forEach(function (k) { if (map[k]) sh.getRange(row, map[k]).setValue(fields[k]); });
    } else {
      var max = rows.reduce(function (m, r) { var n = Number(String(r['Service ID']).replace(/\D/g, '')) || 0; return Math.max(m, n); }, 0);
      id = 'SRV' + ('000' + (max + 1)).slice(-3);
      fields['Service ID'] = id; fields['CA approved'] = 'DEVELOPER'; fields['Source / notes'] = 'Added by developer ' + stamp;
      row = appendRecord_(SHEETS.SERVICE_MASTER, fields);
    }
    ['GST rate', 'CGST rate', 'SGST rate', 'IGST rate'].forEach(function (k) { sh.getRange(row, map[k]).setNumberFormat('0.0%'); });
    if (map['Default price']) sh.getRange(row, map['Default price']).setNumberFormat('#,##0.00');
    audit_(before ? 'SERVICE_UPDATED' : 'SERVICE_CREATED', 'Service', id,
      {by: dev.id, before: before, after: {name: name, taxClass: taxClass, gstRate: rate, sac: sac, status: status, price: price}}, 'OK');
    return listServicesAdmin(token);
  } finally {
    lock.releaseLock();
  }
}

/** Deletes a service that has never appeared on any bill. Used services can only be switched off. */
function deleteService(token, id) {
  var dev = checkDeveloper_(token);
  var lock = LockService.getScriptLock();
  lock.waitLock(10000);
  try {
    var ex = serviceRows_().filter(function (r) { return String(r['Service ID']) === String(id); })[0];
    if (!ex) throw new Error('Service ' + id + ' not found.');
    var n = serviceUsage_()[String(id)] || 0;
    if (n) throw new Error('This service is on ' + n + ' bill line(s), so it cannot be deleted. Switch it off (Inactive) instead.');
    getDb_().getSheetByName(SHEETS.SERVICE_MASTER).deleteRow(ex._row);
    audit_('SERVICE_DELETED', 'Service', id, {by: dev.id, name: ex['Service name']}, 'OK');
    return listServicesAdmin(token);
  } finally {
    lock.releaseLock();
  }
}

/** Stage 12B test (TEST only): developer-only access, add, edit, switch off, delete rules, billing dropdown. */
function testServicesStage12B() {
  if (getSetting('ENVIRONMENT') !== 'TEST') throw new Error('Tests run only in the TEST environment.');
  var out = [], ok = function (c, m) { out.push((c ? 'PASS ' : 'FAIL ') + m); };
  var err = function (fn) { try { fn(); return ''; } catch (e) { return e.message; } };
  var st = String(Date.now()).slice(-6), aId = 'sadmin' + st, dId = 'sdev' + st, newId = '';
  asSystem_();
  [[aId, 'Admin', 'Admin1234'], [dId, 'Developer', 'Devel1234']].forEach(function (x) {
    var salt = newSalt_();
    appendRecord_(SHEETS.USERS, {'User ID': x[0], 'Name': 'Test ' + x[1], 'Role': x[1], 'Active': true, 'Password hash': hashPassword_(x[2], salt), 'Salt': salt,
      'Must change password': false, 'Failed attempts': 0, 'Created at': new Date(), 'Created by': 'testServicesStage12B'});
  });
  try {
    APP_USER_ = null; var a = login(aId, 'Admin1234');
    APP_USER_ = null; var d = login(dId, 'Devel1234');
    ok(/Only the developer/.test(err(function () { listServicesAdmin(a.token); })) && /Only the developer/.test(err(function () { saveService(a.token, {name: 'X'}); })),
      'A clinic admin cannot open or change services; only the developer can');
    var list = listServicesAdmin(d.token);
    ok(list.services.length > 20 && list.services.some(function (s) { return s.used > 0; }), 'Developer sees every service (' + list.services.length + ') with how often each was billed');
    var name = 'Test peel ' + st;
    ok(/6 digits/.test(err(function () { saveService(d.token, {name: name, category: 'Skin', taxClass: 'Taxable', gstRate: 0.05, sac: '12'}); })) &&
       /GST rate/.test(err(function () { saveService(d.token, {name: name, category: 'Skin', taxClass: 'Taxable', gstRate: 0, sac: '999722'}); })),
      'Wrong SAC or a missing GST rate for a taxable service is refused');
    list = saveService(d.token, {name: name, category: 'Skin', applicableTo: 'Test only', taxClass: 'Taxable', gstRate: 0.05, sac: '999722', price: 2500, status: 'Active'});
    var s = list.services.filter(function (x) { return x.name === name; })[0]; newId = s ? s.id : '';
    ok(s && /^SRV\d{3}$/.test(s.id) && s.gstRate === 0.05 && s.price === 2500, 'Developer adds a taxable service (' + newId + ', 5% GST, default price 2,500)');
    var row = serviceRows_().filter(function (r) { return r['Service ID'] === newId; })[0];
    ok(row && row['Document type'] === 'Tax Invoice' && Math.abs(row['CGST rate'] - 0.025) < 1e-9 && Math.abs(row['IGST rate'] - 0.05) < 1e-9,
      'It goes on a Tax Invoice with CGST 2.5% + SGST 2.5% (IGST 5%) worked out automatically');
    var dd = getAppData(d.token).services.filter(function (x) { return x.id === newId; })[0];
    ok(dd && dd.price === 2500, 'It appears in the billing dropdown with its default price');
    ok(/already has this name/.test(err(function () { saveService(d.token, {name: name.toUpperCase(), category: 'Skin', taxClass: 'Exempt', sac: '999312'}); })), 'Two services cannot have the same name');
    saveService(d.token, {id: newId, name: name, category: 'Skin', taxClass: 'Exempt', sac: '999312', price: '', status: 'Active'});
    row = serviceRows_().filter(function (r) { return r['Service ID'] === newId; })[0];
    ok(row['Tax classification'] === 'Exempt' && row['Document type'] === 'Bill of Supply' && Number(row['GST rate']) === 0, 'Changing it to Exempt moves it to Bill of Supply with 0% GST');
    saveService(d.token, {id: newId, name: name, category: 'Skin', taxClass: 'Exempt', sac: '999312', status: 'Inactive'});
    ok(!getActiveServices().some(function (x) { return x.id === newId; }), 'A service switched off disappears from the billing dropdown');
    var usedId = list.services.filter(function (x) { return x.used > 0; })[0].id;
    ok(/cannot be deleted/.test(err(function () { deleteService(d.token, usedId); })), 'A service already on a bill cannot be deleted (' + usedId + ')');
    deleteService(d.token, newId);
    ok(!serviceRows_().some(function (r) { return r['Service ID'] === newId; }), 'An unused service can be deleted');
    newId = '';
  } catch (e) {
    ok(false, 'Unexpected error: ' + e.message);
  } finally {
    asSystem_();
    if (newId) { var r = serviceRows_().filter(function (x) { return x['Service ID'] === newId; })[0]; if (r) getDb_().getSheetByName(SHEETS.SERVICE_MASTER).deleteRow(r._row); }
    [aId, dId].forEach(function (id) { var r = findUser_(id); if (r) usersSheet_().deleteRow(r._row); });
  }
  Logger.log(out.join('\n'));
  return out;
}
