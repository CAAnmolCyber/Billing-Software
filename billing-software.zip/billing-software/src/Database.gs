/**
 * Yavira Billing System - Database.gs
 * Stage 4: database layer. All reads/writes to the Sheet go through here,
 * using column names (not positions), so adding a column later never breaks the app.
 */

var SCHEMA = {
  'Service Master': ['Service ID', 'Category', 'Service name', 'Applicable to', 'SAC', 'Tax classification',
    'Document type', 'GST rate', 'CGST rate', 'SGST rate', 'IGST rate', 'Status', 'CA approved', 'Source / notes', 'Default price'],
  'Customer Master': ['Customer ID', 'Customer name', 'Mobile', 'Email', 'Email preference', 'Address', 'State',
    'GSTIN', 'First visit date', 'Last visit date', 'No. of documents', 'Total billed', 'Created at', 'Notes'],
  'Invoice Register': ['Document no.', 'Document type', 'Document date', 'Financial year', 'Month', 'Visit ID',
    'Customer ID', 'Customer name', 'Mobile', 'Email', 'Customer GSTIN', 'Place of supply', 'Gross amount',
    'Discount', 'Taxable value', 'Exempt value', 'CGST', 'SGST', 'IGST', 'Total tax', 'Round off',
    'Total payable', 'Amount received', 'Balance due', 'Payment mode', 'Payment status', 'Document status',
    'Cancellation reason', 'Cancelled at', 'PDF file ID', 'PDF link', 'Email status', 'Created by',
    'Created at', 'Request ID'],
  'Invoice Line Items': ['Line ID', 'Document no.', 'Line no.', 'Document date', 'Service ID', 'Service name',
    'SAC', 'Tax classification', 'Quantity', 'Rate', 'Gross amount', 'Discount', 'Taxable value', 'GST rate',
    'CGST', 'SGST', 'IGST', 'Line total', 'Document status', 'Discount %'],
  'Payment Register': ['Payment ID', 'Document no.', 'Payment date', 'Amount', 'Payment mode',
    'Reference (UPI / card / cheque no.)', 'Recorded by', 'Recorded at', 'Payment status', 'Notes'],
  'GST Sales Register': ['Document no.', 'Document date', 'Document type', 'Financial year', 'Month',
    'Customer name', 'Customer GSTIN', 'Place of supply', 'SAC', 'Tax classification', 'GST rate',
    'Taxable value', 'Exempt value', 'CGST', 'SGST', 'IGST', 'Total value', 'Document status'],
  'Audit Log': ['Timestamp', 'User', 'Action', 'Record type', 'Reference', 'Details', 'Result'],
  'Users': ['User ID', 'Name', 'Role', 'Active', 'Password hash', 'Salt', 'Must change password', 'Failed attempts',
    'Locked until', 'Last login', 'Created at', 'Created by', 'Email'],
  'Email Delivery Log': ['Email ID', 'Queued at', 'Email type', 'Document no. / report', 'Recipient',
    'Redirected (test mode)', 'Status', 'Attempts', 'Last attempt at', 'Last error', 'Notes']
};

/** Returns {header: columnIndex(1-based)} for a tab, and checks it against SCHEMA. */
function getHeaderMap_(sheetName) {
  var sh = getDb_().getSheetByName(sheetName);
  if (!sh) throw new Error('Tab not found: ' + sheetName);
  var headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0];
  var map = {};
  headers.forEach(function (h, i) { if (h !== '') map[String(h).trim()] = i + 1; });
  return map;
}

/** Appends one record (an object keyed by header name). Unknown keys throw, so typos surface immediately. */
function appendRecord_(sheetName, record) {
  var sh = getDb_().getSheetByName(sheetName);
  var map = getHeaderMap_(sheetName);
  var row = new Array(sh.getLastColumn()).fill('');
  Object.keys(record).forEach(function (k) {
    if (!map[k]) throw new Error('Unknown column "' + k + '" in ' + sheetName);
    row[map[k] - 1] = record[k];
  });
  sh.appendRow(row);
  return sh.getLastRow();
}

/** Appends several records in one write (used for invoice line items). */
function appendRecords_(sheetName, records) {
  if (!records.length) return;
  var sh = getDb_().getSheetByName(sheetName);
  var map = getHeaderMap_(sheetName);
  var width = sh.getLastColumn();
  var rows = records.map(function (record) {
    var row = new Array(width).fill('');
    Object.keys(record).forEach(function (k) {
      if (!map[k]) throw new Error('Unknown column "' + k + '" in ' + sheetName);
      row[map[k] - 1] = record[k];
    });
    return row;
  });
  sh.getRange(sh.getLastRow() + 1, 1, rows.length, width).setValues(rows);
}

/** Reads a tab into an array of objects keyed by header name. */
function readRecords_(sheetName) {
  var sh = getDb_().getSheetByName(sheetName);
  var values = sh.getDataRange().getValues();
  var headers = values.shift().map(function (h) { return String(h).trim(); });
  return values.filter(function (r) { return r.join('') !== ''; }).map(function (r) {
    var o = {};
    headers.forEach(function (h, i) { if (h) o[h] = r[i]; });
    return o;
  });
}

/** Active, CA-approved services for the billing dropdown. Inactive or unclassified ones never appear. */
function getActiveServices() {
  return readRecords_(SHEETS.SERVICE_MASTER).filter(function (s) {
    return s['Status'] === 'Active' && s['Tax classification'] !== 'UNCLASSIFIED' && s['Document type'] !== '';
  }).map(function (s) {
    return {
      id: s['Service ID'], name: s['Service name'], category: s['Category'], applicableTo: s['Applicable to'],
      sac: String(s['SAC']), taxClass: s['Tax classification'], docType: s['Document type'],
      gstRate: Number(s['GST rate']) || 0, caApproved: s['CA approved'], price: Number(s['Default price']) || 0
    };
  });
}

/** Writes one line to the Audit Log. Never throws: logging must not break billing. */
function audit_(action, recordType, reference, details, result) {
  try {
    appendRecord_(SHEETS.AUDIT_LOG, {
      'Timestamp': new Date(),
      'User': currentUser_(),
      'Action': action, 'Record type': recordType, 'Reference': reference || '',
      'Details': typeof details === 'string' ? details : JSON.stringify(details || ''),
      'Result': result || 'OK'
    });
  } catch (e) {
    console.error('Audit log failed: ' + e.message);
  }
}

/**
 * Stage 4 check: every tab has exactly the expected columns in the expected order,
 * the service list loads, and a test line can be written to the Audit Log. Sends NO email.
 */
function verifySchema() {
  var out = [];
  var ok = true;
  Object.keys(SCHEMA).forEach(function (tab) {
    var sh = getDb_().getSheetByName(tab);
    var actual = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(String);
    var expected = SCHEMA[tab];
    var match = actual.length === expected.length && expected.every(function (h, i) { return actual[i] === h; });
    if (!match) ok = false;
    out.push((match ? 'OK   ' : 'FAIL ') + tab + ' (' + actual.length + ' columns)');
  });
  var services = getActiveServices();
  var taxable = services.filter(function (s) { return s.taxClass === 'Taxable'; }).length;
  out.push('Active services for dropdown: ' + services.length + ' (' + taxable + ' taxable, ' +
    (services.length - taxable) + ' exempt)');
  audit_('SCHEMA_CHECK', 'System', 'Stage 4', out.join(' | '), ok ? 'OK' : 'FAIL');
  out.push('Audit Log test line written');
  out.push(ok ? 'RESULT: PASS' : 'RESULT: FAIL');
  Logger.log(out.join('\n'));
  return out;
}
