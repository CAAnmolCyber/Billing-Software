/**
 * Yavira Billing System - Reports.gs
 * Stage 9: customer history, sales / GST / payment reports, and bill cancellation.
 *
 * Rules
 *  - Sales totals count only Issued documents. Cancelled documents are shown separately, with their value,
 *    so invoice value, amount collected, outstanding and cancelled value are never mixed up.
 *  - Reports and cancellation are for Admin users only (Auth.gs). Customer search and history are for every authorised user.
 *  - A cancelled bill is never deleted: its number stays used, every register row is marked "Cancelled",
 *    the original PDF stays in Drive, and a second PDF with a CANCELLED banner is filed by the background job.
 */

function inList_(listSetting, email) {
  var list = String(listSetting || '').toLowerCase().split(',').map(function (s) { return s.trim(); }).filter(String);
  return list.indexOf(String(email || '').toLowerCase()) !== -1;
}

/* currentUser_, isAdmin_, checkAccess_ and checkAdmin_ live in Auth.gs (app login). */

function istDate_(d) { return Utilities.formatDate(new Date(d), TZ, 'yyyy-MM-dd'); }

/* ---------------- Customers ---------------- */

/** Profile and every document for one customer (newest first). */
function getCustomerHistory(customerId, token) {
  checkAccess_(token);
  var c = readRecords_(SHEETS.CUSTOMER_MASTER).filter(function (r) { return r['Customer ID'] === customerId; })[0];
  if (!c) throw new Error('Customer not found: ' + customerId);
  var docs = readRecords_(SHEETS.INVOICE_REGISTER).filter(function (r) { return r['Customer ID'] === customerId; })
    .map(function (r) {
      return {
        docNo: r['Document no.'], type: r['Document type'], date: Utilities.formatDate(new Date(r['Document date']), TZ, 'dd-MM-yyyy'),
        sortKey: new Date(r['Document date']).getTime(), total: Number(r['Total payable']) || 0,
        paymentMode: r['Payment mode'], status: r['Document status'], reason: r['Cancellation reason'] || '',
        emailStatus: r['Email status'], pdfLink: r['PDF link'] || ''
      };
    }).sort(function (a, b) { return b.sortKey - a.sortKey; });
  var issued = docs.filter(function (d) { return d.status === 'Issued'; });
  return {
    customer: {
      id: c['Customer ID'], name: c['Customer name'], mobile: String(c['Mobile']), email: c['Email'] || '',
      emailPref: c['Email preference'], address: c['Address'] || '', state: c['State'] || '',
      firstVisit: c['First visit date'] ? Utilities.formatDate(new Date(c['First visit date']), TZ, 'dd-MM-yyyy') : '',
      lastVisit: c['Last visit date'] ? Utilities.formatDate(new Date(c['Last visit date']), TZ, 'dd-MM-yyyy') : ''
    },
    docs: docs,
    totals: {
      issuedCount: issued.length, cancelledCount: docs.length - issued.length,
      totalBilled: r2_(issued.reduce(function (a, d) { return a + d.total; }, 0))
    },
    isAdmin: isAdmin_()
  };
}

/** Recomputes a customer's document count and total from the register (used after a cancellation). */
function refreshCustomerTotals_(customerId) {
  var issued = readRecords_(SHEETS.INVOICE_REGISTER).filter(function (r) {
    return r['Customer ID'] === customerId && r['Document status'] === 'Issued';
  });
  var sh = getDb_().getSheetByName(SHEETS.CUSTOMER_MASTER), map = getHeaderMap_(SHEETS.CUSTOMER_MASTER);
  var ids = sh.getRange(2, map['Customer ID'], Math.max(sh.getLastRow() - 1, 1), 1).getValues();
  for (var i = 0; i < ids.length; i++) {
    if (ids[i][0] === customerId) {
      sh.getRange(i + 2, map['No. of documents']).setValue(issued.length);
      sh.getRange(i + 2, map['Total billed']).setValue(r2_(issued.reduce(function (a, r) { return a + Number(r['Total payable']); }, 0)));
      return;
    }
  }
}

/* ---------------- Cancellation ---------------- */

/** Sets one column to a value on every row of a tab whose 'Document no.' matches. */
function markRows_(tab, docNo, updates) {
  var sh = getDb_().getSheetByName(tab), map = getHeaderMap_(tab), last = sh.getLastRow();
  if (last < 2) return 0;
  var nos = sh.getRange(2, map['Document no.'], last - 1, 1).getValues(), n = 0;
  nos.forEach(function (r, i) {
    if (String(r[0]) !== docNo) return;
    Object.keys(updates).forEach(function (k) { sh.getRange(i + 2, map[k]).setValue(updates[k]); });
    n++;
  });
  return n;
}

/**
 * Cancels an issued document. Admin only. The number is never reused and nothing is deleted.
 * GST note shown in the app: cancel only bills not yet reported in GSTR-1; for a reported bill, ask the CA.
 */
function cancelDocument(docNo, reason, token) {
  checkAdmin_(token);
  docNo = String(docNo || '').trim();
  reason = String(reason || '').trim();
  if (reason.length < 5) throw new Error('Please enter a reason for cancelling (at least 5 characters).');
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(30000)) throw new Error('The system is busy. Please try again in a few seconds.');
  try {
    var head = readRecords_(SHEETS.INVOICE_REGISTER).filter(function (r) { return r['Document no.'] === docNo; })[0];
    if (!head) throw new Error('Document not found: ' + docNo);
    if (head['Document status'] === 'Cancelled') throw new Error(docNo + ' is already cancelled.');
    var now = new Date(), user = currentUser_();
    var reg = {'Document status': 'Cancelled', 'Cancellation reason': reason, 'Cancelled at': now,
      'PDF file ID': '', 'PDF link': ''};                       // the background job files the CANCELLED copy
    if (head['Email status'] === 'Queued') reg['Email status'] = 'Not applicable';
    markRows_(SHEETS.INVOICE_REGISTER, docNo, reg);
    var lines = markRows_(SHEETS.INVOICE_LINES, docNo, {'Document status': 'Cancelled'});
    var gst = markRows_(SHEETS.GST_REGISTER, docNo, {'Document status': 'Cancelled'});
    markRows_(SHEETS.PAYMENT_REGISTER, docNo, {'Payment status': 'Cancelled',
      'Notes': 'Bill cancelled ' + Utilities.formatDate(now, TZ, 'dd-MM-yyyy') + ' by ' + user + '. Any refund is handled outside the app.'});
    refreshCustomerTotals_(head['Customer ID']);
    SpreadsheetApp.flush();
    audit_('DOC_CANCELLED', head['Document type'], docNo, {reason: reason, value: Number(head['Total payable']),
      originalPdf: head['PDF link'] || '', lines: lines, gstRows: gst}, 'OK');
    return {docNo: docNo, cancelledAt: Utilities.formatDate(now, TZ, 'dd-MM-yyyy HH:mm'), value: Number(head['Total payable'])};
  } finally {
    lock.releaseLock();
  }
}

/* ---------------- Reports ---------------- */

function add_(o, k, v) { o[k] = r2_((o[k] || 0) + (Number(v) || 0)); }

/**
 * Builds every report for an IST date range (inclusive). from / to: 'yyyy-MM-dd'.
 * Pure read-only: safe to run any time.
 */
function buildReport_(from, to) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to)) throw new Error('Choose a valid From and To date.');
  if (from > to) throw new Error('The From date is after the To date.');
  var inRange = function (d) { var s = istDate_(d); return s >= from && s <= to; };

  var regAll = readRecords_(SHEETS.INVOICE_REGISTER).filter(function (r) { return r['Document no.'] && inRange(r['Document date']); });
  var issued = regAll.filter(function (r) { return r['Document status'] === 'Issued'; });
  var cancelled = regAll.filter(function (r) { return r['Document status'] === 'Cancelled'; });
  var issuedNos = {};
  issued.forEach(function (r) { issuedNos[r['Document no.']] = true; });

  var s = {taxInvoices: 0, billsOfSupply: 0, cancelledCount: cancelled.length};
  issued.forEach(function (r) {
    if (r['Document type'] === 'Tax Invoice') s.taxInvoices++; else s.billsOfSupply++;
    add_(s, 'gross', r['Gross amount']); add_(s, 'discount', r['Discount']);
    add_(s, 'taxable', r['Taxable value']); add_(s, 'exempt', r['Exempt value']);
    add_(s, 'cgst', r['CGST']); add_(s, 'sgst', r['SGST']); add_(s, 'igst', r['IGST']);
    add_(s, 'roundOff', r['Round off']); add_(s, 'invoiceValue', r['Total payable']);
    add_(s, 'collected', r['Amount received']); add_(s, 'outstanding', r['Balance due']);
  });
  ['gross', 'discount', 'taxable', 'exempt', 'cgst', 'sgst', 'igst', 'roundOff', 'invoiceValue', 'collected', 'outstanding']
    .forEach(function (k) { s[k] = s[k] || 0; });
  s.totalTax = r2_(s.cgst + s.sgst + s.igst);
  s.documents = issued.length;
  s.cancelledValue = r2_(cancelled.reduce(function (a, r) { return a + Number(r['Total payable']); }, 0));

  var daily = {};
  issued.forEach(function (r) {
    var k = istDate_(r['Document date']), d = daily[k] = daily[k] || {date: k, documents: 0};
    d.documents++;
    add_(d, 'taxable', r['Taxable value']); add_(d, 'exempt', r['Exempt value']);
    add_(d, 'cgst', r['CGST']); add_(d, 'sgst', r['SGST']); add_(d, 'total', r['Total payable']); add_(d, 'collected', r['Amount received']);
  });

  var svc = {};
  readRecords_(SHEETS.INVOICE_LINES).filter(function (l) { return issuedNos[l['Document no.']]; }).forEach(function (l) {
    var k = l['Service ID'] + '|' + l['Service name'];
    var o = svc[k] = svc[k] || {service: l['Service name'], sac: String(l['SAC']), classification: l['Tax classification'], lines: 0};
    o.lines++; add_(o, 'quantity', l['Quantity']); add_(o, 'gross', l['Gross amount']); add_(o, 'discount', l['Discount']);
    add_(o, 'value', l['Taxable value']); add_(o, 'gst', Number(l['CGST']) + Number(l['SGST']) + Number(l['IGST'])); add_(o, 'total', l['Line total']);
  });

  var cust = {};
  issued.forEach(function (r) {
    var k = r['Customer ID'], o = cust[k] = cust[k] || {customerId: k, name: r['Customer name'], mobile: String(r['Mobile']), documents: 0};
    o.documents++; add_(o, 'total', r['Total payable']);
  });

  var gst = {};
  readRecords_(SHEETS.GST_REGISTER).filter(function (g) { return issuedNos[g['Document no.']]; }).forEach(function (g) {
    var k = g['SAC'] + '|' + g['GST rate'];
    var o = gst[k] = gst[k] || {sac: String(g['SAC']), classification: g['Tax classification'], rate: Number(g['GST rate']) || 0, documents: 0};
    o.documents++; add_(o, 'taxable', g['Taxable value']); add_(o, 'exempt', g['Exempt value']);
    add_(o, 'cgst', g['CGST']); add_(o, 'sgst', g['SGST']); add_(o, 'igst', g['IGST']); add_(o, 'total', g['Total value']);
  });

  var pay = {};
  readRecords_(SHEETS.PAYMENT_REGISTER).filter(function (p) { return issuedNos[p['Document no.']]; }).forEach(function (p) {
    var k = p['Payment mode'] || 'Not recorded', o = pay[k] = pay[k] || {mode: k, payments: 0};
    o.payments++; add_(o, 'amount', p['Amount']);
  });

  var vals = function (o) { return Object.keys(o).map(function (k) { return o[k]; }); };
  var byTotal = function (a, b) { return (b.total || b.amount || 0) - (a.total || a.amount || 0); };
  return {
    from: from, to: to, generatedAt: Utilities.formatDate(new Date(), TZ, 'dd-MM-yyyy HH:mm'),
    business: getBusinessProfile_()['Trade name'], gstin: getBusinessProfile_()['GSTIN'],
    summary: s,
    daily: vals(daily).sort(function (a, b) { return a.date < b.date ? -1 : 1; }),
    services: vals(svc).sort(byTotal),
    customers: vals(cust).sort(byTotal),
    gst: vals(gst).sort(function (a, b) { return a.rate - b.rate || (a.sac < b.sac ? -1 : 1); }),
    payments: vals(pay).sort(byTotal),
    register: regAll.map(function (r) {
      return {
        docNo: r['Document no.'], date: Utilities.formatDate(new Date(r['Document date']), TZ, 'dd-MM-yyyy'), type: r['Document type'],
        customer: r['Customer name'], mobile: String(r['Mobile']), taxable: Number(r['Taxable value']) || 0, exempt: Number(r['Exempt value']) || 0,
        cgst: Number(r['CGST']) || 0, sgst: Number(r['SGST']) || 0, igst: Number(r['IGST']) || 0, roundOff: Number(r['Round off']) || 0,
        total: Number(r['Total payable']) || 0, received: Number(r['Amount received']) || 0, balance: Number(r['Balance due']) || 0,
        paymentMode: r['Payment mode'], status: r['Document status'], pdfLink: r['PDF link'] || ''
      };
    }).sort(function (a, b) { return a.docNo < b.docNo ? -1 : 1; }),
    cancelled: cancelled.map(function (r) {
      return {
        docNo: r['Document no.'], date: Utilities.formatDate(new Date(r['Document date']), TZ, 'dd-MM-yyyy'), type: r['Document type'],
        customer: r['Customer name'], value: Number(r['Total payable']) || 0, reason: r['Cancellation reason'] || '',
        cancelledAt: r['Cancelled at'] ? Utilities.formatDate(new Date(r['Cancelled at']), TZ, 'dd-MM-yyyy HH:mm') : ''
      };
    })
  };
}

/** Called by the Reports screen. Admin only. */
function getReport(from, to, token) {
  checkAdmin_(token);
  var rep = buildReport_(from, to);
  audit_('REPORT_VIEWED', 'Report', from + ' to ' + to, 'Documents: ' + rep.register.length, 'OK');
  return rep;
}

/** Date presets for the Reports screen (IST): today, this week (Mon-Sun), this month, last month, this FY. */
function reportPresets_() {
  var now = new Date(), f = function (d) { return Utilities.formatDate(d, TZ, 'yyyy-MM-dd'); };
  var y = Number(Utilities.formatDate(now, TZ, 'yyyy')), m = Number(Utilities.formatDate(now, TZ, 'M')),
    day = Number(Utilities.formatDate(now, TZ, 'd')), dow = Number(Utilities.formatDate(now, TZ, 'u'));   // 1 = Monday
  var D = function (yy, mm, dd) { return new Date(yy, mm, dd, 12); };   // midday, so any script time zone gives the right IST date
  var fyStart = Number(optionalSetting_('FY_START_MONTH', 4)) || 4, fyY = m >= fyStart ? y : y - 1;
  return {
    today: [f(D(y, m - 1, day)), f(D(y, m - 1, day))],
    week: [f(D(y, m - 1, day - (dow - 1))), f(D(y, m - 1, day - (dow - 1) + 6))],
    month: [f(D(y, m - 1, 1)), f(D(y, m, 0))],
    lastMonth: [f(D(y, m - 2, 1)), f(D(y, m - 1, 0))],
    fy: [f(D(fyY, fyStart - 1, 1)), f(D(fyY + 1, fyStart - 1, 0))]
  };
}

/* ---------------- Stage 9 test ---------------- */

/**
 * Stage 9 test (TEST environment only, sends NO email):
 *  1. Access rules for admin lists.  2. FY report reconciles across all registers.
 *  3. Issues one test bill, cancels it, and checks every register, the report, the customer history,
 *     numbering, the cancelled PDF copy and that the original PDF is kept.  4. Bad inputs are rejected.
 */
function testReportsStage9() {
  if (getSetting('ENVIRONMENT') !== 'TEST') throw new Error('Tests run only in the TEST environment.');
  refreshSettings();
  asSystem_();
  var out = [], ok = function (c, msg) { out.push((c ? 'PASS ' : 'FAIL ') + msg); return c; };
  var eq = function (a, b) { return Math.abs(Number(a) - Number(b)) < 0.005; };

  ok(inList_('a@x.com, B@y.com', 'b@y.com') && !inList_('a@x.com', 'c@z.com') && !inList_('', 'a@x.com'),
    'Admin list check (case-insensitive; empty list allows no one)');
  ok(isAdmin_(), 'Editor-run tests use the system admin identity');

  var p = reportPresets_();
  var rep = buildReport_(p.fy[0], p.fy[1]), s = rep.summary;
  var sum = function (arr, k) { return r2_(arr.reduce(function (a, x) { return a + (Number(x[k]) || 0); }, 0)); };
  var regIssued = rep.register.filter(function (r) { return r.status === 'Issued'; });
  ok(eq(s.invoiceValue, sum(regIssued, 'total')) && eq(s.invoiceValue, sum(rep.daily, 'total')) &&
    eq(s.invoiceValue, sum(rep.customers, 'total')) && eq(s.invoiceValue, sum(rep.payments, 'amount')),
    'FY ' + p.fy[0] + ' to ' + p.fy[1] + ': invoice value ' + s.invoiceValue + ' matches register, daily, customer-wise and payment-mode totals');
  ok(eq(s.cgst, sum(rep.gst, 'cgst')) && eq(s.sgst, sum(rep.gst, 'sgst')) && eq(s.taxable, sum(rep.gst, 'taxable')) && eq(s.exempt, sum(rep.gst, 'exempt')),
    'GST summary matches: taxable ' + s.taxable + ', exempt ' + s.exempt + ', CGST ' + s.cgst + ', SGST ' + s.sgst);
  ok(eq(r2_(s.taxable + s.exempt), sum(rep.services, 'value')), 'Service-wise value ' + sum(rep.services, 'value') + ' = taxable + exempt');
  ok(eq(s.invoiceValue, r2_(s.taxable + s.exempt + s.totalTax + s.roundOff)) && eq(s.collected, s.invoiceValue) && eq(s.outstanding, 0),
    'Invoice value = taxable + exempt + tax + round off; collected = invoice value; outstanding 0');

  // Issue a fresh test bill (no email) and cancel it.
  var taxable = getActiveServices().filter(function (x) { return x.taxClass === 'Taxable'; })[0];
  var res = generateInvoice({
    requestId: 'T9-' + Date.now(), paymentMode: 'Cash', paymentRef: '',
    customer: {id: '', name: 'Test Patient C', mobile: '9876500003', email: '', emailDeclined: true, address: '', state: 'Punjab'},
    lines: [{serviceId: taxable.id, qty: 1, rate: 1000, discPct: 0}]
  });
  var docNo = res.docs[0].docNo, value = res.docs[0].total;
  out.push('     Issued test bill ' + docNo + ' for Rs ' + value);
  processPdfQueue();                                   // file its original PDF first, as the 5-minute job would
  var before = buildReport_(p.fy[0], p.fy[1]).summary;

  var c = cancelDocument(docNo, 'Test cancellation - wrong service selected');
  var head = readRecords_(SHEETS.INVOICE_REGISTER).filter(function (r) { return r['Document no.'] === docNo; })[0];
  var lineSt = readRecords_(SHEETS.INVOICE_LINES).filter(function (r) { return r['Document no.'] === docNo; }).map(function (r) { return r['Document status']; });
  var gstSt = readRecords_(SHEETS.GST_REGISTER).filter(function (r) { return r['Document no.'] === docNo; }).map(function (r) { return r['Document status']; });
  var paySt = readRecords_(SHEETS.PAYMENT_REGISTER).filter(function (r) { return r['Document no.'] === docNo; }).map(function (r) { return r['Payment status']; });
  ok(head['Document status'] === 'Cancelled' && head['Cancellation reason'] && head['Cancelled at'] &&
    lineSt.length && lineSt.every(function (x) { return x === 'Cancelled'; }) &&
    gstSt.length && gstSt.every(function (x) { return x === 'Cancelled'; }) && paySt.every(function (x) { return x === 'Cancelled'; }),
    'Cancelled ' + docNo + ': marked in Invoice Register, ' + lineSt.length + ' line(s), ' + gstSt.length + ' GST row(s) and the payment; nothing deleted');

  var after = buildReport_(p.fy[0], p.fy[1]).summary;
  ok(eq(after.invoiceValue, r2_(before.invoiceValue - value)) && after.cancelledCount === before.cancelledCount + 1 &&
    eq(after.cancelledValue, r2_(before.cancelledValue + value)),
    'Report: sales drop by ' + value + ', cancelled count +1, cancelled value +' + value);

  var hist = getCustomerHistory(head['Customer ID']);
  var cm = readRecords_(SHEETS.CUSTOMER_MASTER).filter(function (r) { return r['Customer ID'] === head['Customer ID']; })[0];
  ok(hist.docs.some(function (d) { return d.docNo === docNo && d.status === 'Cancelled'; }) &&
    hist.totals.totalBilled === 0 && Number(cm['Total billed']) === 0 && Number(cm['No. of documents']) === 0,
    'Customer history shows ' + docNo + ' as Cancelled; Customer Master total recalculated to 0');

  var again = '', empty = '', bad = '';
  try { cancelDocument(docNo, 'second try'); } catch (e) { again = e.message; }
  try { cancelDocument('TI/26-27/0001', ' '); } catch (e) { empty = e.message; }
  try { buildReport_('2026-12-01', '2026-11-01'); } catch (e) { bad = e.message; }
  ok(/already cancelled/.test(again) && /reason/.test(empty) && /after/.test(bad), 'Rejected: cancelling twice, cancelling without a reason, From date after To date');

  var empty2 = buildReport_('2026-05-01', '2026-05-01').summary;
  ok(empty2.documents === 0 && empty2.invoiceValue === 0, 'Report for a day with no bills shows zero');

  var pdf = processPdfQueue(), fresh = readRecords_(SHEETS.INVOICE_REGISTER).filter(function (r) { return r['Document no.'] === docNo; })[0];
  var cf = fresh['PDF file ID'] ? DriveApp.getFileById(String(fresh['PDF file ID'])) : null;
  ok(cf && /CANCELLED\.pdf$/.test(cf.getName()), 'Cancelled PDF filed by the background job: ' + (cf ? cf.getName() : 'none'));
  var originals = cf ? cf.getParents().next().getFilesByName(pdfFileName_(docNo)) : null;
  ok(originals && originals.hasNext(), 'Original PDF ' + pdfFileName_(docNo) + ' kept in Drive (not deleted)');

  Logger.log(out.join('\n'));
  return out;
}
