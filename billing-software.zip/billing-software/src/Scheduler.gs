/**
 * Yavira Billing System - Scheduler.gs
 * Stage 10: weekly and monthly reports emailed to the CA as Excel (.xlsx) files, with a copy saved in Drive.
 *
 * How it works
 *  - runScheduledReports() runs every day at about 7 AM IST, as the app owner (installReportSchedule installs it).
 *  - Weekly report: the last complete Monday-to-Sunday week, sent on WEEKLY_REPORT_DAY (or the next run after, if missed).
 *  - Monthly report: the last complete calendar month, sent on MONTHLY_REPORT_DAY (or the next run after, if missed).
 *  - Each report is sent once: the Email Delivery Log is checked first, so a re-run never sends a second copy.
 *  - Periods that ended before the schedule was switched on are never back-filled.
 *  - TEST_MODE = TRUE: reports go to TEST_EMAIL_REDIRECT instead of CA_REPORT_EMAIL.
 *  - The Excel file is built inside Apps Script (no extra Google permissions needed) and saved in
 *    Reports / FY 2026-27 / Weekly (or Monthly).
 */

/* ---------------- Dates (pure functions on 'yyyy-MM-dd' strings, so time zones can never shift a day) ---------------- */

function ymdToUtc_(s) { var p = s.split('-'); return Date.UTC(+p[0], +p[1] - 1, +p[2]); }
function utcToYmd_(t) { return new Date(t).toISOString().slice(0, 10); }
function addDays_(s, n) { return utcToYmd_(ymdToUtc_(s) + n * 86400000); }
function isoWeekday_(s) { var d = new Date(ymdToUtc_(s)).getUTCDay(); return d === 0 ? 7 : d; }   // 1 = Monday ... 7 = Sunday

/** Last complete Monday-Sunday week before the given day. */
function lastCompleteWeek_(today) {
  var end = addDays_(today, -isoWeekday_(today));
  return {from: addDays_(end, -6), to: end};
}

/** Last complete calendar month before the given day. */
function lastCompleteMonth_(today) {
  var p = today.split('-'), y = +p[0], m = +p[1];
  var first = utcToYmd_(Date.UTC(y, m - 2, 1)), last = utcToYmd_(Date.UTC(y, m - 1, 0));
  return {from: first, to: last};
}

var WEEKDAYS_ = {MONDAY: 1, TUESDAY: 2, WEDNESDAY: 3, THURSDAY: 4, FRIDAY: 5, SATURDAY: 6, SUNDAY: 7};

/** Which reports are due today. Pure: settings, today and start date are passed in. */
function dueReports_(today, weeklyDay, monthlyDay, startDate) {
  var due = [];
  var w = lastCompleteWeek_(today);
  if (isoWeekday_(today) >= (WEEKDAYS_[String(weeklyDay).toUpperCase()] || 1) && w.to >= startDate) due.push({kind: 'Weekly', from: w.from, to: w.to});
  var m = lastCompleteMonth_(today);
  if (Number(today.split('-')[2]) >= (Number(monthlyDay) || 1) && m.to >= startDate) due.push({kind: 'Monthly', from: m.from, to: m.to});
  return due;
}

/* ---------------- Excel (.xlsx) writer: plain Office Open XML, zipped with Utilities.zip ---------------- */

function xmlEsc_(v) {
  return String(v == null ? '' : v).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '')
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function colName_(i) { var s = ''; i++; while (i > 0) { var r = (i - 1) % 26; s = String.fromCharCode(65 + r) + s; i = Math.floor((i - 1) / 26); } return s; }

/**
 * sheets: [{name, rows: [[...]], header: rowIndex (bold), boldRows, intCols: [colIndex...], intRows: [rowIndex...], widths: [...]}]
 * Numbers become real numbers (#,##0.00, or whole numbers in intCols). Returns [{path, xml}].
 */
function xlsxParts_(sheets) {
  var NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
  var RNS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
  var PNS = 'http://schemas.openxmlformats.org/package/2006/relationships';
  var head = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n';
  var parts = [];
  parts.push({path: '[Content_Types].xml', xml: head + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
    '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
    '<Default Extension="xml" ContentType="application/xml"/>' +
    '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>' +
    '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>' +
    sheets.map(function (s, i) { return '<Override PartName="/xl/worksheets/sheet' + (i + 1) + '.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'; }).join('') +
    '</Types>'});
  parts.push({path: '_rels/.rels', xml: head + '<Relationships xmlns="' + PNS + '"><Relationship Id="rId1" Type="' + RNS + '/officeDocument" Target="xl/workbook.xml"/></Relationships>'});
  var used = {};
  parts.push({path: 'xl/workbook.xml', xml: head + '<workbook xmlns="' + NS + '" xmlns:r="' + RNS + '"><sheets>' +
    sheets.map(function (s, i) {
      var n = String(s.name).replace(/[\[\]\*\?\/\\:]/g, ' ').slice(0, 31), base = n, k = 2;
      while (used[n]) n = base.slice(0, 28) + ' ' + (k++);
      used[n] = true;
      return '<sheet name="' + xmlEsc_(n) + '" sheetId="' + (i + 1) + '" r:id="rId' + (i + 1) + '"/>';
    }).join('') + '</sheets></workbook>'});
  parts.push({path: 'xl/_rels/workbook.xml.rels', xml: head + '<Relationships xmlns="' + PNS + '">' +
    sheets.map(function (s, i) { return '<Relationship Id="rId' + (i + 1) + '" Type="' + RNS + '/worksheet" Target="worksheets/sheet' + (i + 1) + '.xml"/>'; }).join('') +
    '<Relationship Id="rId' + (sheets.length + 1) + '" Type="' + RNS + '/styles" Target="styles.xml"/></Relationships>'});
  // Styles: 0 normal, 1 bold, 2 money, 3 bold money, 4 whole number, 5 bold whole number
  parts.push({path: 'xl/styles.xml', xml: head + '<styleSheet xmlns="' + NS + '">' +
    '<numFmts count="1"><numFmt numFmtId="164" formatCode="#,##0.00"/></numFmts>' +
    '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><sz val="11"/><name val="Calibri"/></font></fonts>' +
    '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>' +
    '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>' +
    '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>' +
    '<cellXfs count="6"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>' +
    '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/>' +
    '<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>' +
    '<xf numFmtId="164" fontId="1" fillId="0" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1"/>' +
    '<xf numFmtId="1" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>' +
    '<xf numFmtId="1" fontId="1" fillId="0" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1"/></cellXfs>' +
    '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>'});
  sheets.forEach(function (s, i) {
    var ints = {}; (s.intCols || []).forEach(function (c) { ints[c] = true; });
    var bold = {}; [].concat(s.boldRows || []).forEach(function (r) { bold[r] = true; });
    var intRow = {}; (s.intRows || []).forEach(function (r) { intRow[r] = true; });
    if (s.header != null) bold[s.header] = true;
    var width = s.rows.reduce(function (a, r) { return Math.max(a, r.length); }, 1);
    var cols = '<cols>' + Array.apply(null, Array(width)).map(function (_, c) {
      var w = (s.widths && s.widths[c]) || (c === 0 ? 26 : 15);
      return '<col min="' + (c + 1) + '" max="' + (c + 1) + '" width="' + w + '" customWidth="1"/>';
    }).join('') + '</cols>';
    var data = s.rows.map(function (row, r) {
      return '<row r="' + (r + 1) + '">' + row.map(function (v, c) {
        if (v === '' || v == null) return '';
        var ref = colName_(c) + (r + 1), b = bold[r];
        if (typeof v === 'number' && isFinite(v)) return '<c r="' + ref + '" s="' + ((ints[c] || intRow[r]) ? (b ? 5 : 4) : (b ? 3 : 2)) + '"><v>' + v + '</v></c>';
        return '<c r="' + ref + '" t="inlineStr"' + (b ? ' s="1"' : '') + '><is><t xml:space="preserve">' + xmlEsc_(v) + '</t></is></c>';
      }).join('') + '</row>';
    }).join('');
    parts.push({path: 'xl/worksheets/sheet' + (i + 1) + '.xml', xml: head + '<worksheet xmlns="' + NS + '">' + cols + '<sheetData>' + data + '</sheetData></worksheet>'});
  });
  return parts;
}

function buildXlsxBlob_(sheets, fileName) {
  var blobs = xlsxParts_(sheets).map(function (p) { return Utilities.newBlob(p.xml, 'application/xml', p.path); });
  return Utilities.zip(blobs, fileName).setContentType('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
}

/* ---------------- Report workbook content ---------------- */

function dmy_(s) { var p = s.split('-'); return p[2] + '-' + p[1] + '-' + p[0]; }

/** Turns a buildReport_ result into the sheets for the weekly or monthly workbook. */
function reportSheets_(kind, r) {
  var s = r.summary;
  var title = [[r.business + ' - ' + kind + ' report'], ['GSTIN', r.gstin], ['Period', dmy_(r.from) + ' to ' + dmy_(r.to)], ['Generated', r.generatedAt], []];
  var table = function (name, cols, rows, intCols, totalsFrom) {
    var out = [cols.map(function (c) { return c[0]; })].concat(rows.map(function (x) { return cols.map(function (c) { return typeof c[1] === 'function' ? c[1](x) : x[c[1]]; }); }));
    var bolds = [];
    if (rows.length && totalsFrom != null) {
      out.push(cols.map(function (c, i) {
        if (i === 0) return 'Total';
        if (i < totalsFrom || typeof c[1] !== 'string') return '';
        return r2_(rows.reduce(function (a, x) { return a + (Number(x[c[1]]) || 0); }, 0));
      }));
      bolds.push(out.length - 1);
    }
    if (!rows.length) out.push(['Nothing in this period']);
    return {name: name, rows: out, header: 0, boldRows: bolds, intCols: intCols || []};
  };
  var summary = {name: 'Summary', header: 5, boldRows: [0, 6, 7, 8, 9], intCols: [], rows: title.concat([
    ['Item', 'Amount (Rs)'],
    ['Invoice value (issued documents)', s.invoiceValue], ['Amount collected', s.collected], ['Outstanding', s.outstanding],
    ['Cancelled invoice value', s.cancelledValue], ['Cancelled documents (count)', s.cancelledCount],
    ['Tax Invoices issued (count)', s.taxInvoices], ['Bills of Supply issued (count)', s.billsOfSupply],
    ['Gross amount', s.gross], ['Discount', s.discount], ['Taxable value', s.taxable], ['Exempt value', s.exempt],
    ['CGST', s.cgst], ['SGST', s.sgst], ['IGST', s.igst], ['Total tax', s.totalTax], ['Round off', s.roundOff], [],
    ['Notes'], ['Sales figures count issued documents only; cancelled documents are listed separately.'],
    ['All bills are collected in full at the time of billing, so outstanding is normally zero.']])};
  summary.intRows = summary.rows.map(function (row, i) { return /\(count\)$/.test(String(row[0])) ? i : -1; }).filter(function (i) { return i >= 0; });

  var register = table(kind === 'Monthly' ? 'Sales register' : 'Invoice register',
    [['Document no.', 'docNo'], ['Date', 'date'], ['Type', 'type'], ['Customer', 'customer'], ['Mobile', 'mobile'], ['Taxable', 'taxable'], ['Exempt', 'exempt'],
      ['CGST', 'cgst'], ['SGST', 'sgst'], ['IGST', 'igst'], ['Round off', 'roundOff'], ['Total', 'total'], ['Received', 'received'], ['Balance', 'balance'],
      ['Payment mode', 'paymentMode'], ['Status', 'status']], r.register, [], null);
  var payments = table(kind === 'Monthly' ? 'Payment-mode analysis' : 'Payment collection',
    [['Payment mode', 'mode'], ['Payments', 'payments'], ['Amount', 'amount']], r.payments, [1], 1);
  if (kind === 'Weekly') {
    return [summary,
      table('Daily sales', [['Date', function (x) { return dmy_(x.date); }], ['Documents', 'documents'], ['Taxable', 'taxable'], ['Exempt', 'exempt'], ['CGST', 'cgst'], ['SGST', 'sgst'], ['Total', 'total'], ['Collected', 'collected']], r.daily, [1], 1),
      register, payments];
  }
  var outstanding = r.register.filter(function (x) { return x.status === 'Issued' && x.balance > 0; });
  return [summary, register,
    table('GST summary', [['SAC', 'sac'], ['Classification', 'classification'], ['GST rate %', function (x) { return x.rate * 100; }], ['Documents', 'documents'], ['Taxable', 'taxable'], ['Exempt', 'exempt'], ['CGST', 'cgst'], ['SGST', 'sgst'], ['IGST', 'igst'], ['Total', 'total']], r.gst, [2, 3], 3),
    payments,
    outstanding.length ? table('Outstanding balances', [['Document no.', 'docNo'], ['Date', 'date'], ['Customer', 'customer'], ['Total', 'total'], ['Received', 'received'], ['Balance', 'balance']], outstanding, [], 3)
      : {name: 'Outstanding balances', header: 0, rows: [['Outstanding balances'], ['None: every bill in this period was collected in full at billing.']]},
    table('Customer-wise sales', [['Customer ID', 'customerId'], ['Customer', 'name'], ['Mobile', 'mobile'], ['Documents', 'documents'], ['Total', 'total']], r.customers, [3], 3),
    table('Service-wise sales', [['Service', 'service'], ['SAC', 'sac'], ['Classification', 'classification'], ['Quantity', 'quantity'], ['Gross', 'gross'], ['Discount', 'discount'], ['Value', 'value'], ['GST', 'gst'], ['Total', 'total']], r.services, [3], 3),
    table('Cancelled documents', [['Document no.', 'docNo'], ['Date', 'date'], ['Type', 'type'], ['Customer', 'customer'], ['Value', 'value'], ['Reason', 'reason'], ['Cancelled at', 'cancelledAt']], r.cancelled, [], null)];
}

/* ---------------- Sending ---------------- */

function reportRef_(kind, from, to) { return kind + ' report ' + from + ' to ' + to; }

function reportAlreadySent_(ref) {
  return readRecords_(SHEETS.EMAIL_LOG).some(function (r) { return r['Document no. / report'] === ref && r['Status'] === 'Sent'; });
}

function reportFolder_(kind, to) {
  var root = DriveApp.getFolderById(String(getSetting('REPORTS_FOLDER_ID')));
  var fy = financialYearLabel_(new Date(ymdToUtc_(to) + 12 * 3600000));
  return getOrCreateFolder_(getOrCreateFolder_(root, 'FY 20' + fy.split('-')[0] + '-' + fy.split('-')[1]), kind);
}

/**
 * Builds, saves and emails one report. opts.force sends again even if already sent (a regenerated copy is saved).
 * Returns {ref, sent, skipped, to, file, summary}.
 */
function sendReport_(kind, from, to, opts) {
  opts = opts || {};
  refreshSettings();
  var ref = reportRef_(kind, from, to);
  if (!opts.force && reportAlreadySent_(ref)) return {ref: ref, skipped: 'already sent'};
  var r = buildReport_(from, to);
  var name = 'Yavira ' + kind + ' Report ' + from + ' to ' + to + '.xlsx';
  var folder = reportFolder_(kind, to);
  if (folder.getFilesByName(name).hasNext()) name = name.replace('.xlsx', ' (regenerated ' + Utilities.formatDate(new Date(), TZ, 'dd-MM-yyyy HHmm') + ').xlsx');
  var file = folder.createFile(buildXlsxBlob_(reportSheets_(kind, r), name));

  var s = getSettings_(), es = emailSettings_();
  var test = isTrue_(s.TEST_MODE), ca = String(s.CA_REPORT_EMAIL || '').trim();
  var recipient = test ? String(s.TEST_EMAIL_REDIRECT || '').trim() : ca;
  var result = {ref: ref, file: file.getName(), fileUrl: file.getUrl(), to: recipient, summary: r.summary, sent: false};
  if (!recipient) { audit_('REPORT_SAVED', 'Report', ref, 'Saved to Drive; no recipient set (CA_REPORT_EMAIL)', 'OK'); return result; }

  var sm = r.summary, period = dmy_(from) + ' to ' + dmy_(to);
  var subject = (test ? '[TEST] ' : '') + r.business + ' - ' + kind + ' sales report - ' + period;
  var row = function (k, v) { return '<tr><td style="padding:4px 10px;border-bottom:1px solid #eee;">' + k + '</td><td style="padding:4px 10px;border-bottom:1px solid #eee;text-align:right;">' + v + '</td></tr>'; };
  var html = '<div style="font-family:Arial,sans-serif;font-size:14px;color:#2b2b2b;max-width:600px;">' +
    (test ? '<div style="background:#fff3cd;border:1px solid #e0c36a;padding:8px 12px;margin-bottom:12px;font-size:13px;">TEST MODE - redirected. Intended recipient: <b>' + esc_(ca || '(CA_REPORT_EMAIL not set)') + '</b></div>' : '') +
    '<p>Dear Sir / Madam,</p><p>Please find attached the ' + kind.toLowerCase() + ' sales report of ' + esc_(r.business) + ' (GSTIN ' + esc_(r.gstin) + ') for <b>' + period + '</b>.</p>' +
    '<table style="border-collapse:collapse;min-width:360px;">' +
    row('Invoice value (issued)', '&#8377; ' + money_(sm.invoiceValue)) + row('Amount collected', '&#8377; ' + money_(sm.collected)) +
    row('Outstanding', '&#8377; ' + money_(sm.outstanding)) + row('Cancelled value (' + sm.cancelledCount + ')', '&#8377; ' + money_(sm.cancelledValue)) +
    row('Tax Invoices / Bills of Supply', sm.taxInvoices + ' / ' + sm.billsOfSupply) + row('Taxable value', '&#8377; ' + money_(sm.taxable)) +
    row('Exempt value', '&#8377; ' + money_(sm.exempt)) + row('CGST', '&#8377; ' + money_(sm.cgst)) + row('SGST', '&#8377; ' + money_(sm.sgst)) +
    row('IGST', '&#8377; ' + money_(sm.igst)) + '</table>' +
    '<p>The attached Excel file contains: ' + reportSheets_(kind, r).map(function (x) { return x.name; }).join(', ') + '.</p>' +
    '<p>A copy is saved in Google Drive: ' + esc_(file.getName()) + '.</p>' +
    '<p>Regards,<br>' + esc_(r.business) + '</p><p style="color:#999;font-size:11px;">This report was generated automatically by the Yavira billing system.</p></div>';
  var text = (test ? 'TEST MODE - intended recipient: ' + ca + '\n\n' : '') + kind + ' sales report ' + period + '\nInvoice value: Rs ' + money_(sm.invoiceValue) +
    '\nCollected: Rs ' + money_(sm.collected) + '\nCancelled: Rs ' + money_(sm.cancelledValue) + '\nTaxable: Rs ' + money_(sm.taxable) + '  Exempt: Rs ' + money_(sm.exempt) +
    '\nCGST: Rs ' + money_(sm.cgst) + '  SGST: Rs ' + money_(sm.sgst) + '\n\nThe Excel file is attached.';
  var now = new Date(), err = '';
  try {
    if (opts.forceError) throw new Error('Simulated Gmail failure (test) - nothing was sent');
    var options = {htmlBody: html, attachments: [file.getBlob()], name: es.senderName};
    if (es.replyTo) options.replyTo = es.replyTo;
    if (es.fromAlias) options.from = es.fromAlias;
    GmailApp.sendEmail(recipient, subject, text, options);
    result.sent = true;
  } catch (e) { err = e.message; }
  appendRecord_(SHEETS.EMAIL_LOG, {
    'Email ID': 'EML-' + Utilities.formatDate(now, TZ, 'yyyyMMddHHmmss') + '-' + Math.floor(Math.random() * 900 + 100),
    'Queued at': now, 'Email type': kind + ' report', 'Document no. / report': ref, 'Recipient': recipient,
    'Redirected (test mode)': test ? 'Yes' : 'No', 'Status': err ? 'Failed' : 'Sent',
    'Attempts': readRecords_(SHEETS.EMAIL_LOG).filter(function (x) { return x['Document no. / report'] === ref; }).length + 1,
    'Last attempt at': now, 'Last error': err, 'Notes': (test ? 'Intended for ' + ca + '. ' : '') + 'Saved as ' + file.getName()
  });
  audit_('REPORT_SENT', 'Report', ref, err ? 'Failed (will retry tomorrow): ' + err : 'Sent to ' + recipient + '; saved ' + file.getName(), err ? 'FAIL' : 'OK');
  result.error = err;
  return result;
}

/** The daily job: sends whichever reports are due and not yet sent. A failed report is retried on the next day's run. */
function runScheduledReports() {
  var lock = LockService.getScriptLock();
  if (!lock.tryLock(30000)) return;
  try {
    refreshSettings();
    var start = PropertiesService.getScriptProperties().getProperty('REPORTS_START_DATE') || istDate_(new Date());
    var due = dueReports_(istDate_(new Date()), optionalSetting_('WEEKLY_REPORT_DAY', 'MONDAY'), optionalSetting_('MONTHLY_REPORT_DAY', 1), start);
    due.forEach(function (d) {
      try { sendReport_(d.kind, d.from, d.to); } catch (e) {
        audit_('REPORT_SENT', 'Report', reportRef_(d.kind, d.from, d.to), e.message, 'FAIL');
        sendAlert_('REPORT_' + d.kind + '_' + d.from, d.kind + ' report could not be sent', [reportRef_(d.kind, d.from, d.to) + ': ' + e.message,
          'It will be tried again tomorrow morning. To send it now: sendReportNow(\'' + d.kind + '\',\'' + d.from + '\',\'' + d.to + '\').']);
      }
    });
    try { runHealthCheck_(); } catch (e) { console.error('Health check failed: ' + e.message); }   // Alerts.gs
  } finally {
    lock.releaseLock();
  }
}

/** Installs the daily 7 AM IST report job (run once as the owner). Earlier periods are not back-filled. */
function installReportSchedule() {
  ScriptApp.getProjectTriggers().forEach(function (t) { if (t.getHandlerFunction() === 'runScheduledReports') ScriptApp.deleteTrigger(t); });
  ScriptApp.newTrigger('runScheduledReports').timeBased().everyDays(1).atHour(7).inTimezone(TZ).create();
  var props = PropertiesService.getScriptProperties();
  if (!props.getProperty('REPORTS_START_DATE')) props.setProperty('REPORTS_START_DATE', istDate_(new Date()));
  var today = istDate_(new Date()), w = lastCompleteWeek_(addDays_(today, 7 - isoWeekday_(today) + 1)), m = lastCompleteMonth_(utcToYmd_(Date.UTC(+today.slice(0, 4), +today.slice(5, 7), 1)));
  var msg = 'Report schedule installed: daily check at about 7 AM IST, runs as ' + Session.getEffectiveUser().getEmail() +
    '. Next weekly report: ' + w.from + ' to ' + w.to + '. Next monthly report: ' + m.from + ' to ' + m.to + '.';
  audit_('TRIGGER_INSTALLED', 'System', 'runScheduledReports', msg, 'OK');
  Logger.log(msg);
}

/** Manual send from the editor, e.g. sendReportNow('Monthly', '2026-11-01', '2026-11-30'). Always sends (to the test inbox in TEST_MODE). */
function sendReportNow(kind, from, to) {
  var r = sendReport_(kind || 'Weekly', from, to, {force: true});
  Logger.log(JSON.stringify(r));
  return r;
}

/* ---------------- Stage 10 test ---------------- */

/**
 * Stage 10 test (TEST environment only; reports go ONLY to TEST_EMAIL_REDIRECT):
 *  1. Date ranges and due days for edge cases (month ends, year end, FY end, leap years, missed days).
 *  2. Weekly report for last week and monthly report for this month: saved in Drive, emailed, figures match.
 *  3. The Excel file opens as a valid workbook with the right sheets and totals.
 *  4. A re-run does not send a second copy; a Gmail failure is logged and retried.
 */
function testScheduledStage10() {
  if (getSetting('ENVIRONMENT') !== 'TEST') throw new Error('Tests run only in the TEST environment.');
  refreshSettings();
  if (!isTrue_(getSetting('TEST_MODE'))) throw new Error('Stop: TEST_MODE must be TRUE to run this test.');
  var out = [], ok = function (c, msg) { out.push((c ? 'PASS ' : 'FAIL ') + msg); return c; };
  var same = function (a, b) { return JSON.stringify(a) === JSON.stringify(b); };

  ok(same(lastCompleteWeek_('2026-11-23'), {from: '2026-11-16', to: '2026-11-22'}) && same(lastCompleteWeek_('2026-11-22'), {from: '2026-11-09', to: '2026-11-15'}) &&
    same(lastCompleteWeek_('2026-12-07'), {from: '2026-11-30', to: '2026-12-06'}) && same(lastCompleteWeek_('2027-01-04'), {from: '2026-12-28', to: '2027-01-03'}),
    'Weekly periods: always the last complete Monday-Sunday week (incl. across month and year ends)');
  ok(same(lastCompleteMonth_('2026-12-01'), {from: '2026-11-01', to: '2026-11-30'}) && same(lastCompleteMonth_('2027-01-01'), {from: '2026-12-01', to: '2026-12-31'}) &&
    same(lastCompleteMonth_('2027-03-01'), {from: '2027-02-01', to: '2027-02-28'}) && same(lastCompleteMonth_('2028-03-05'), {from: '2028-02-01', to: '2028-02-29'}) &&
    same(lastCompleteMonth_('2027-04-01'), {from: '2027-03-01', to: '2027-03-31'}),
    'Monthly periods: previous calendar month (30/31 days, February, leap year, year end, March before FY end)');
  ok(financialYearLabel_(new Date(ymdToUtc_('2027-03-31') + 43200000)) === '26-27' && financialYearLabel_(new Date(ymdToUtc_('2027-04-01') + 43200000)) === '27-28',
    'Financial year: 31-03-2027 is FY 2026-27, 01-04-2027 is FY 2027-28');
  var kinds = function (d) { return d.map(function (x) { return x.kind + ' ' + x.from; }).join(', '); };
  ok(kinds(dueReports_('2026-11-23', 'MONDAY', 1, '2026-11-22')) === 'Weekly 2026-11-16' &&
    kinds(dueReports_('2026-11-22', 'MONDAY', 1, '2026-11-22')) === '' &&
    kinds(dueReports_('2026-12-01', 'MONDAY', 1, '2026-11-22')) === 'Weekly 2026-11-23, Monthly 2026-11-01' &&
    kinds(dueReports_('2026-12-02', 'MONDAY', 1, '2026-11-22')) === 'Weekly 2026-11-23, Monthly 2026-11-01' &&
    kinds(dueReports_('2026-11-30', 'WEDNESDAY', 5, '2026-11-22')) === '',
    'Due days: Monday sends last week; 1st sends last month; a missed day catches up; nothing from before the switch-on date');

  var week = lastCompleteWeek_(istDate_(new Date()));
  var p = reportPresets_(), month = {from: p.month[0], to: p.month[1]};
  var failed = sendReport_('Weekly', week.from, week.to, {force: true, forceError: true});
  var failRow = readRecords_(SHEETS.EMAIL_LOG).filter(function (r) { return r['Document no. / report'] === failed.ref; }).pop() || {};
  ok(!failed.sent && /Simulated/.test(failed.error) && failRow['Status'] === 'Failed' && /Simulated/.test(failRow['Last error']),
    'Gmail failure: nothing sent; logged as Failed with the error, and a Failed entry never counts as sent (next run retries)');

  [['Weekly', week], ['Monthly', month]].forEach(function (k) {
    var res = sendReport_(k[0], k[1].from, k[1].to, {force: true});
    var rep = buildReport_(k[1].from, k[1].to).summary;
    ok(res.sent && res.to === String(getSetting('TEST_EMAIL_REDIRECT')) && res.summary.invoiceValue === rep.invoiceValue,
      k[0] + ' ' + k[1].from + ' to ' + k[1].to + ': sent only to ' + res.to + ', invoice value Rs ' + rep.invoiceValue + ', cancelled Rs ' + rep.cancelledValue);
    var f = reportFolder_(k[0], k[1].to).getFilesByName(res.file);
    var file = f.hasNext() ? f.next() : null;
    var parts = file ? Utilities.unzip(file.getBlob().setContentType('application/zip')) : [];
    var names = parts.map(function (b) { return b.getName(); });
    var sheetCount = names.filter(function (n) { return /^xl\/worksheets\/sheet\d+\.xml$/.test(n); }).length;
    var summaryXml = parts.filter(function (b) { return b.getName() === 'xl/worksheets/sheet1.xml'; }).map(function (b) { return b.getDataAsString(); })[0] || '';
    ok(file && names.indexOf('[Content_Types].xml') !== -1 && sheetCount === (k[0] === 'Weekly' ? 4 : 8) && summaryXml.indexOf('<v>' + rep.invoiceValue + '</v>') !== -1,
      k[0] + ' Excel saved in Reports / ' + (file ? file.getParents().next().getParents().next().getName() + ' / ' + file.getParents().next().getName() + ' / ' + file.getName() : '-') +
      ' (' + sheetCount + ' sheets; invoice value inside matches)');
  });

  var again = sendReport_('Weekly', week.from, week.to);
  ok(again.skipped === 'already sent', 'Re-run of the same weekly report is skipped (no second email)');

  Utilities.sleep(3000);
  var mails = GmailApp.search('subject:"[TEST]" subject:"sales report" has:attachment newer_than:1d').length;
  ok(mails >= 2, 'Test inbox has ' + mails + ' [TEST] report email(s) with the Excel file attached');
  Logger.log(out.join('\n'));
  return out;
}
