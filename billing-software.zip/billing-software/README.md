# Billing Software: Yavira Skin & Aesthetics Clinic

A cloud GST billing app for a skin and aesthetics clinic in Mohali (Punjab), built on free Google tools:
**Google Apps Script** (the code), **Google Sheets** (the database), **Google Drive** (bill PDFs, reports, backups)
and **Gmail** (bill emails, reports, alerts). Staff use it from a browser on a laptop or phone.

Private repository. Built by Anmol Chopra, November 2026.

## What it does

**Billing**
- Makes GST-correct bills: **Tax Invoice** (TI/26-27/0001) for cosmetic services at 5% GST (CGST 2.5% + SGST 2.5%),
  and **Bill of Supply** (BS/26-27/0001) for exempt medical services. A visit with both gets both documents automatically.
- Separate running numbers per financial year; never reused, never duplicated (even on a double click).
- Discount as a percentage, tax rounded per Section 170 CGST Act, total rounded to the rupee.
- Customer address asked for only when a Tax Invoice's taxable value is Rs 50,000 or more.
- Preview before issuing; **Print** and **Download PDF** after; a PDF of every bill is filed in Drive (FY / month folders).
- Customer history and reprint of any past bill. Admins can cancel a bill with a reason; it is kept and marked CANCELLED.

**Logins and access**
- The app's own login (user ID or email + password). Roles: **Staff** (billing, customers), **Admin** (also reports,
  cancellations, users), **Developer** (everything, plus the Services tab; protected from clinic admins).
- First login forces a new password; 5 wrong tries lock the ID for 15 minutes; passwords stored only as salted hashes.
- "Forgot password?" emails a 6-digit code (15 minutes, 5 tries, 3 codes an hour).
- Staff never get access to the Sheet or Drive.

**Services**
- 40 services, each with SAC, Exempt/Taxable and GST rate; the developer adds, edits or switches off services in the app,
  with an optional default price. Issued bills never change.

**Reports**
- On-screen reports for any period (summary, daily sales, GST by SAC and rate, payment modes, service-wise, customer-wise,
  invoice register, cancelled bills) with Excel download.
- Weekly report every Monday and monthly report on the 1st, emailed with an Excel file.

**Reliability**
- Jobs run on Google's servers: PDFs and emails every 5 minutes, reports daily about 7 AM, backup nightly about 11 PM.
- Nightly full copy of the database in Drive, plus a weekly Excel copy emailed to a second Google account.
- Failure alerts by email and a morning health check (backup, jobs, Gmail limit, failures in the log).
- TEST and LIVE are separate systems; test mode redirects every email to the developer.
- Works on phones (iPhone and Android) as well as laptops.

## Repository layout

| Path | What it is |
|---|---|
| `src/Config.gs` | Sheet names and the one-time database ID (everything else is read from the Application Settings tab) |
| `src/Database.gs` | Database layer: schema of every tab, reads and writes by column name, audit log |
| `src/WebApp.gs` | Serves the page; loads business profile, settings and services for the screen |
| `src/Invoice.gs` | GST engine, numbering, saving a bill, bill HTML/PDF, reprint |
| `src/Drive.gs` | Files PDFs into Drive (FY / month folders) |
| `src/Email.gs` | Customer bill emails (test-mode redirect, retries, delivery log); the 5-minute background job |
| `src/Reports.gs` | Customer history, cancellation, on-screen reports |
| `src/Scheduler.gs` | Weekly / monthly reports and the Excel builder |
| `src/Auth.gs` | Login, sessions, roles, forgot password, user management |
| `src/Services.gs` | Developer-only service management |
| `src/Alerts.gs` | Failure alerts and the morning health check |
| `src/Backup.gs` | Nightly backup, off-site Excel copy, one-click setup |
| `src/Tests.gs` | End-to-end test runner (TEST environment only) |
| `src/Index.html` | Billing screen (and page layout, including phone layout) |
| `src/ReportsUi.html` | Customers and Reports tabs |
| `src/AuthUi.html` | Login, forgot password, password change, Users tab |
| `src/ServicesUi.html` | Services tab |
| `docs/PROJECT_LOG.md` | What was built, stage by stage, with test results and decisions |
| `docs/SETUP.md` | How to install a fresh copy and how to update the live app |
| `samples/` | A sample monthly report (TEST data) |

## Where it runs

| | LIVE (real bills) | TEST (practice) |
|---|---|---|
| Apps Script project | Yavira Billing App (LIVE) | Yavira Billing App (TEST) |
| Database | Yavira Billing Database (LIVE) | Yavira Billing Database (TEST) |
| Drive folder | Yavira Billing System (LIVE) | Yavira Billing System (TEST) |
| Owner account | c.anmol1997@gmail.com | c.anmol1997@gmail.com |

The code in `src/` is a copy. The running code lives in the Apps Script projects; after changing a file here, paste it into
the project and publish a new version (see `docs/SETUP.md`).

No passwords are stored in this repository.
