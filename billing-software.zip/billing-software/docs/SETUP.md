# Setup and updates

## Updating the live app after a code change

1. Make and test the change in the **TEST** project first (script.google.com, *Yavira Billing App (TEST)*).
2. Paste the same file into the **LIVE** project and save.
3. **Deploy > Manage deployments >** edit (pencil) **> Version: New version >** add a short description **> Deploy**.
   The link stays the same.
4. If something breaks: same screen, choose the previous version and Deploy. That rolls back in seconds.
5. Copy the changed file into `src/` here and commit, so this repository stays the record.

## Installing a fresh copy (new Google account or a rebuild)

1. In the new account, create a Google Sheet for the database and a Drive folder with subfolders Invoices, Reports, Backups;
   upload the logo.
2. Create an Apps Script project and add every file in `src/` (same names; `.gs` as Script, `.html` as HTML).
3. In `Config.gs`, set `INITIAL_SPREADSHEET_ID` to the new Sheet's ID. Run `setupProject` once and approve Google's permissions.
4. Fill the **Application Settings** tab: folder IDs, logo file ID, ENVIRONMENT (TEST or PRODUCTION), TEST_MODE,
   email settings. Fill **Business Profile** and **Service Master**.
5. Run `setupNewInstallation`: installs the scheduled jobs, creates the first admin (temporary password in the log),
   makes the first backup and checks everything. Then run `setupDeveloperAccount` for the developer login.
6. **Deploy > New deployment > Web app**, Execute as *Me*, Who has access *Anyone with Google account*. Share the link.

## Useful editor functions

| Function | Use |
|---|---|
| `verifySchema` | Checks every tab and column |
| `testConnection` | Checks folders and logo |
| `listScheduledJobs` | Lists the scheduled jobs and the account they run as |
| `healthCheckNow` | Runs the morning health check now |
| `pdfQueueStatus` / `processPdfQueue` | PDFs waiting / file them now |
| `emailSetupStatus` | Which account and name emails go from |
| `sendReportNow('Monthly','2026-11-01','2026-11-30')` | Re-send a report |
| `offsiteBackupNow` | Email the off-site Excel copy now |
| `ownerResetAdmin` / `setupDeveloperAccount` | Recover the admin / developer login |
| `runStage11Tests`, `testAuthStage12`, `testStage12A`, `testServicesStage12B`, `testAlertsStage12B` | Test suites (TEST only) |

## Restoring from the off-site Excel copy

Upload the Excel file from the "Yavira Billing - database backup" email to Drive, open it with Google Sheets, then follow
"Installing a fresh copy" from step 3 using that sheet. Passwords are not in the copy: run `ownerResetAdmin` afterwards.
