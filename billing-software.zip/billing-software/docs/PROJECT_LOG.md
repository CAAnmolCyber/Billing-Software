# Project log

What was built, in order, with the tests that proved it. Dates are 2026.

| Stage | What | Result |
|---|---|---|
| 1-3 | Requirements, GST rules with the CA, Google project setup, central configuration (no hard-coded emails or folder IDs) | Done |
| 4 | Database: 11 tabs (business profile, services, customers, invoice register, line items, payments, GST register, settings, audit log, email log, users) | Schema check PASS |
| 5 | Billing screen: customer search, service lines, live GST summary, preview | Done |
| 6 | GST engine, numbering, saving, duplicate-click protection | Scenario tests PASS |
| 7 | PDFs filed in Drive by financial year and month, with retries | 8/8 PASS |
| 8 | Customer emails: one email per visit with all PDFs, test-mode redirect, retries, delivery log | 6/6 PASS |
| 9 | Customers tab, purchase history, reprint, cancellation with reason; Reports with Excel download | 13/13 PASS |
| 10 | Weekly (Monday) and monthly (1st) reports emailed with Excel; sent once each | 11/11 PASS |
| 11 | Full end-to-end testing; found and fixed a Section 170 double-rounding bug (Rs 1 extra on taxes ending .495 to .499) | 20/20 PASS |
| 12 | LIVE system separate from TEST; app login with roles, lockout, hashed passwords; nightly backup; staff and owner guides | 14/14 PASS |
| 12A | Email per user, login with email, "Forgot password" by 6-digit code, protected Developer role | 20/20 PASS |
| 12B | Developer Services tab with default prices; failure alerts and morning health check; weekly off-site Excel backup | 11/11, 6/6, backup PASS |
| 12C | All 40 services classified and active; phone layout (no sideways scrolling, stacked service lines, iPhone-friendly inputs); clinic and test admin logins | Every screen checked at iPhone size |

## Decisions (owner and CA)

- Exempt medical services go on a Bill of Supply (SAC 999312); cosmetic services on a Tax Invoice at 5% (SAC 999722).
  Beauty and cosmetic services are 5% without input tax credit from 22 Sept 2025.
- Customer GSTIN and the reverse-charge line are not printed. Email is optional. Discount is a percentage. Every bill is paid in full.
- No credit notes (service-only billing). The app's bill series is independent of the paper bill book.
- Consultation fee: medical and exempt. GFC therapy and laser pigmentation each have a medical (exempt, keep records) and a cosmetic (5%) entry.
- Services and GST rates are changed only by the developer; clinic admins manage users and cancellations.
- The developer account (c.anmol1997) keeps the code; the clinic will own its data (Drive and Sheet) after handover.

## Pending

- The email address that will send bills to customers (then switch on CUSTOMER_EMAIL_ENABLED). Reply-to and CA report email.
- Stage 13: transfer ownership of the LIVE data to the clinic's Google account (developer keeps edit access and the code).
- Turn on 2-Step Verification for the owner account.
- Optional later: WhatsApp sharing, split payments with a day-end report, packages and partial payments, GSTR-1 export, owner dashboard.
